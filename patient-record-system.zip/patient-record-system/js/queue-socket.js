/* ============================================================
   queue-socket.js — "Call Next Patient" over WebSocket + SweetAlert2

   Doctor side : callNextPatient(consultation)  -> asks the server to alert the Frontdesk
   Staff side  : startFrontdeskListener(user)   -> pops a SweetAlert when a doctor calls

   The WebSocket server lives in /ws-server (run it with `npm start`).
   ============================================================ */

const WS_PORT = 8080;
// Uses the same host the page was opened from, so it also works across PCs on one network
const WS_URL = `ws://${location.hostname || "localhost"}:${WS_PORT}`;
const baseApiUrl = sessionStorage.getItem("baseAPIUrl") || "http://localhost/patient-record-system/api";

// ── Make the SweetAlert pop-ups sit ON TOP of any open Bootstrap modal ───────
// SweetAlert2's default z-index (1060) is lower than the consultation / records windows, so the
// "Call the next patient?" box (doctor) and the "send in the next patient" alert (Frontdesk) used to
// open behind them. These two bits put the alerts above every modal and let them take the keyboard focus.
(() => {
  if (document.getElementById("swal-on-top-style")) return;
  const st = document.createElement("style");
  st.id = "swal-on-top-style";
  st.textContent = ".swal2-container { z-index: 3000 !important; }";
  document.head.appendChild(st);
  // Bootstrap's modal pulls keyboard focus back into itself; let it go while an alert is showing
  window.addEventListener("focusin", (e) => {
    if (e.target && e.target.closest && e.target.closest(".swal2-container")) e.stopImmediatePropagation();
  }, true);
})();

// ── SweetAlert2 (loaded on demand from the CDN) ─────────────────────────────
let swalPromise = null;
const loadSwal = () => {
  if (window.Swal) return Promise.resolve(window.Swal);
  if (!swalPromise) {
    swalPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/sweetalert2@11";
      s.onload = () => resolve(window.Swal);
      s.onerror = () => reject(new Error("Could not load SweetAlert2"));
      document.head.appendChild(s);
    });
  }
  return swalPromise;
};

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const fmtTime = (t) => {
  if (!t) return "";
  const [h, m] = String(t).split(":");
  const hh = Number(h);
  return `${hh % 12 || 12}:${m} ${hh >= 12 ? "PM" : "AM"}`;
};

// ── One shared socket per page, auto-reconnecting ───────────────────────────
let socket = null;
let currentUser = null;
let reconnectTimer = null;
const listeners = new Set();
const pending = new Map(); // reqId -> resolve

const connect = (user) => {
  currentUser = user;
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;

  socket = new WebSocket(WS_URL);

  socket.addEventListener("open", () => {
    socket.send(JSON.stringify({
      type: "register",
      userId: user.UserID,
      role: user.RoleName,
      name: `${user.FirstName} ${user.LastName}`,
    }));
  });

  socket.addEventListener("message", (e) => {
    let msg;
    try { msg = JSON.parse(e.data); } catch { return; }
    if ((msg.type === "call-sent" || msg.type === "error") && pending.has(msg.reqId)) {
      pending.get(msg.reqId)(msg);
      pending.delete(msg.reqId);
    }
    listeners.forEach((fn) => fn(msg));
  });

  socket.addEventListener("close", () => {
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => connect(currentUser), 3000);
  });
  socket.addEventListener("error", () => socket.close());
};

const waitUntilOpen = (ms = 3000) =>
  new Promise((resolve) => {
    const start = Date.now();
    const tick = () => {
      if (socket && socket.readyState === WebSocket.OPEN) return resolve(true);
      if (Date.now() - start > ms) return resolve(false);
      setTimeout(tick, 100);
    };
    tick();
  });

// ── STAFF / FRONTDESK: show a SweetAlert whenever a doctor calls ────────────
let alertChain = Promise.resolve(); // several calls in a row show one after another

const beep = () => {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.value = 880; g.gain.value = 0.08;
    o.start(); o.stop(ctx.currentTime + 0.25);
  } catch { /* browsers may block sound until the page has been clicked */ }
};

const showNextPatientAlert = async (msg) => {
  const Swal = await loadSwal();
  beep();
  const n = msg.next;
  const html = n
    ? `<div style="text-align:left;line-height:1.7">
         <div style="font-size:1.35rem;font-weight:700;text-align:center;margin-bottom:.5rem">${esc(n.patientName)}</div>
         <div><b>Queue:</b> ${n.queueNumber ? "#" + esc(n.queueNumber) : "—"}</div>
         <div><b>Queue time:</b> ${esc(fmtTime(n.time))}</div>
         <div><b>Reason:</b> ${esc(n.reason || "—")}</div>
         <div><b>Doctor:</b> ${esc(msg.doctorName)}</div>
       </div>`
    : `<div>Dr. ${esc(msg.doctorName)} has finished and has <b>no more waiting patients</b> today.</div>`;

  await Swal.fire({
    icon: n ? "info" : "success",
    title: n ? "Next patient, please send in" : "Doctor is free",
    html,
    confirmButtonText: "Got it",
    confirmButtonColor: "#1e7e34",
    allowOutsideClick: false,
  });
};

export const startFrontdeskListener = (user) => {
  if (!user || user.RoleName !== "Staff") return;
  listeners.add((msg) => {
    if (msg.type === "next-patient") {
      alertChain = alertChain.then(() => showNextPatientAlert(msg)).catch(() => {});
    }
  });
  connect(user);
};

// ── DOCTOR: "Call Next Patient" button ──────────────────────────────────────
export const callNextPatient = async (consultation) => {
  const user = JSON.parse(sessionStorage.getItem("currentUser") ?? "null");
  if (!user || user.RoleName !== "Doctor") return;
  const Swal = await loadSwal();

  // 1 + 2. Who is next in this doctor's queue? Ask the doctor to confirm.
  const fetchNext = async () => {
    const res = await axios.get(`${baseApiUrl}/appointments.php`, {
      params: {
        operation: "getNextPatient",
        json: JSON.stringify(consultation?.AppointmentID
          ? { appointmentId: consultation.AppointmentID }
          : { userId: user.UserID }),   // nothing finished yet: use this doctor's queue for today
      },
    });
    return res.data || null;
  };

  let next = null;
  while (true) {
    try { next = await fetchNext(); }
    catch { return Swal.fire({ icon: "error", title: "Could not load the queue", text: "Please try again." }); }

    const confirmHtml = next
      ? `<div style="text-align:left;line-height:1.7">
           <div style="font-size:1.25rem;font-weight:700;text-align:center;margin-bottom:.5rem">${esc(next.PatientName)}</div>
           <div><b>Queue:</b> ${next.QueueNumber ? "#" + esc(next.QueueNumber) : "—"}</div>
           <div><b>Queue time:</b> ${esc(fmtTime(next.AppointmentTime))}</div>
           <div><b>Reason:</b> ${esc(next.Reason || "—")}</div>
         </div>`
      : `No more patients are waiting for you today. Let the Frontdesk know you're free?`;

    const ok = await Swal.fire({
      icon: "question",
      title: next ? "Call the next patient?" : "Queue is empty",
      html: confirmHtml,
      showCancelButton: true,
      confirmButtonText: next ? "Notify Frontdesk" : "Tell Frontdesk",
      cancelButtonText: "Not yet",
      confirmButtonColor: "#1e7e34",
    });
    if (!ok.isConfirmed) return;
    break;
  }

  // 3. Send over the WebSocket and wait for the server's reply
  connect(user);
  if (!(await waitUntilOpen())) {
    return Swal.fire({
      icon: "error",
      title: "Queue server not reachable",
      text: "Start it with `npm start` inside the ws-server folder, then try again.",
    });
  }

  const reqId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const reply = await new Promise((resolve) => {
    pending.set(reqId, resolve);
    setTimeout(() => { if (pending.delete(reqId)) resolve(null); }, 5000);
    socket.send(JSON.stringify({
      type: "call-next",
      reqId,
      doctorName: `${user.FirstName} ${user.LastName}`,
      finishedPatient: consultation?.PatientName ?? null,
      next: next && {
        appointmentId: next.AppointmentID,
        patientName: next.PatientName,
        queueNumber: next.QueueNumber,
        time: next.AppointmentTime,
        reason: next.Reason,
      },
    }));
  });

  if (!reply || reply.type === "error") {
    return Swal.fire({ icon: "error", title: "Not sent", text: reply?.message || "No response from the queue server." });
  }
  if (reply.delivered === 0) {
    return Swal.fire({
      icon: "warning",
      title: "No Frontdesk screen is online",
      text: "Nobody on the Staff side is signed in right now, so nobody saw the alert.",
    });
  }
  Swal.fire({
    toast: true, position: "top-end", icon: "success", timer: 2500, showConfirmButton: false,
    title: next ? `Frontdesk notified: ${next.PatientName}` : "Frontdesk notified",
  });
};
