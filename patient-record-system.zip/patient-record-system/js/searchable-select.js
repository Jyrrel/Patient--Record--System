// Turns a normal <select> into a type-to-search dropdown.
// The <select> stays in the page (hidden) and remains the real form field, so existing code that reads
// select.value, sets select.value = "", or relies on data-v validation keeps working unchanged.
export const makeSearchable = (select, { placeholder = "Search...", noMatch = "No matches found." } = {}) => {
  if (!select || select._searchable) return;
  select._searchable = true;

  const wrap = document.createElement("div");
  wrap.className = "position-relative";
  const input = document.createElement("input");
  input.type = "text";
  input.className = "form-control";
  input.autocomplete = "off";
  input.placeholder = placeholder;
  const list = document.createElement("div");
  list.className = "list-group position-absolute w-100 shadow-sm";
  list.style.cssText = "z-index:1060; max-height:240px; overflow-y:auto; display:none;";
  wrap.append(input, list);
  // Before the select, so validation messages (inserted after the select) appear under the search box
  select.insertAdjacentElement("beforebegin", wrap);
  select.classList.add("d-none");

  const items = () => [...select.options].filter((o) => o.value !== "");
  const selectedText = () => (select.value ? select.selectedOptions[0]?.textContent ?? "" : "");
  const sync = () => { input.value = selectedText(); };

  // Make `select.value = ...` in code update the search box too
  const proto = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value");
  Object.defineProperty(select, "value", {
    get() { return proto.get.call(this); },
    set(v) { proto.set.call(this, v); sync(); },
  });
  select.addEventListener("change", sync);

  // Mirror the red "invalid" outline onto the visible box
  new MutationObserver(() => input.classList.toggle("is-invalid", select.classList.contains("is-invalid")))
    .observe(select, { attributes: true, attributeFilter: ["class"] });

  let active = -1;
  const rows = () => [...list.querySelectorAll("button")];
  const setActive = (i) => {
    const r = rows();
    if (!r.length) { active = -1; return; }
    active = (i + r.length) % r.length;
    r.forEach((b, n) => b.classList.toggle("active", n === active));
    r[active].scrollIntoView?.({ block: "nearest" });
  };
  const close = () => { list.style.display = "none"; active = -1; };
  const choose = (opt) => {
    select.value = opt.value;
    select.dispatchEvent(new Event("change", { bubbles: true }));
    close();
  };
  const render = (query) => {
    const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
    const found = items().filter((o) => { const t = o.textContent.toLowerCase(); return terms.every((w) => t.includes(w)); });
    list.innerHTML = "";
    if (!found.length) {
      const none = document.createElement("div");
      none.className = "list-group-item text-muted";
      none.textContent = noMatch;
      list.appendChild(none);
    }
    found.forEach((o) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "list-group-item list-group-item-action" + (o.value === select.value ? " fw-bold" : "");
      b.textContent = o.textContent;   // textContent-safe
      b.addEventListener("mousedown", (e) => e.preventDefault());   // keep focus so blur doesn't fire first
      b.addEventListener("click", () => choose(o));
      list.appendChild(b);
    });
    list.style.display = "block";
    setActive(found.length ? 0 : -1);
  };

  input.addEventListener("focus", () => { input.select(); render(""); });
  input.addEventListener("input", () => render(input.value));
  input.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); if (list.style.display === "none") render(input.value); else setActive(active + 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActive(active - 1); }
    else if (e.key === "Enter") { e.preventDefault(); rows()[active]?.click(); }
    else if (e.key === "Escape" && list.style.display !== "none") { e.stopPropagation(); close(); sync(); }
  });
  input.addEventListener("blur", () => {
    close();
    sync();   // typed text that wasn't picked goes back to the real selection
    select.dispatchEvent(new Event("blur"));   // lets data-v validation run, as it would on the select
  });

  sync();
};
