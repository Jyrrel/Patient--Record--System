// My Earnings (Doctor): the professional fees the signed-in doctor earned on one day.
// Day = the consultation date. Bills that are Cancelled are not counted.
const baseApiUrl = "http://localhost/patient-record-system/api";
const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");

const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const peso = (n) => "₱" + Number(n || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const card = (label, value, cls) => `
  <div class="col-md-4"><div class="card p-3 h-100">
    <div class="text-muted small fw-bold text-uppercase">${label}</div>
    <div class="fs-3 fw-bold ${cls}">${value}</div>
  </div></div>`;

async function load() {
  const date = document.getElementById("earn-date").value || todayStr();
  const summary = document.getElementById("earn-summary");
  const table = document.getElementById("earn-table");
  table.innerHTML = `<p class="text-muted mb-0">Loading...</p>`;
  try {
    const res = await axios.get(`${baseApiUrl}/billing.php`, {
      params: { operation: "getDoctorEarnings", json: JSON.stringify({ actingUserId: currentUser.UserID, date }) },
    });
    const d = res.data;
    if (!d || d.error) {
      summary.innerHTML = "";
      table.innerHTML = `<p class="text-danger mb-0">Could not load your earnings.</p>`;
      return;
    }
    summary.innerHTML =
      card("Total for the day", peso(d.total), "") +
      card("Paid", peso(d.paid), "text-success") +
      card("Pending payment", peso(d.pending), "text-warning");

    const note = d.unbilled > 0
      ? `<div class="alert alert-secondary py-2 small mt-3 mb-0">${d.unbilled} consultation${d.unbilled > 1 ? "s" : ""} on this day ${d.unbilled > 1 ? "have" : "has"} not been billed yet, so ${d.unbilled > 1 ? "they are" : "it is"} not counted.</div>`
      : "";
    if (!d.items.length) {
      table.innerHTML = `<p class="text-muted mb-0">No billed consultations on this day.</p>${note}`;
      return;
    }
    table.innerHTML = `
      <div class="table-responsive"><table class="table table-sm align-middle mb-0">
        <thead><tr><th>#</th><th>Patient</th><th>Description</th><th>Bill</th><th class="text-end">Fee</th></tr></thead>
        <tbody>${d.items.map((r, i) => `<tr>
          <td>${i + 1}</td><td>${esc(r.PatientName)}</td><td>${esc(r.Description || "Professional fee")}</td>
          <td><span class="badge ${r.BillStatus === "Paid" ? "bg-success" : "bg-warning text-dark"}">${esc(r.BillStatus)}</span></td>
          <td class="text-end">${peso(r.FeeAmount)}</td></tr>`).join("")}</tbody>
        <tfoot><tr><th colspan="4" class="text-end">Total</th><th class="text-end">${peso(d.total)}</th></tr></tfoot>
      </table></div>${note}`;
  } catch (e) {
    summary.innerHTML = "";
    table.innerHTML = `<p class="text-danger mb-0">Could not load your earnings. Please check that the server is running.</p>`;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  if (!currentUser || currentUser.RoleName !== "Doctor") return;
  const input = document.getElementById("earn-date");
  input.value = todayStr();
  input.addEventListener("change", load);
  document.getElementById("btn-today").addEventListener("click", () => { input.value = todayStr(); load(); });
  load();
});
