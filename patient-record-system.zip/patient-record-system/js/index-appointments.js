import { makeSearchable } from "./searchable-select.js?v=20261225";
const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const CAN_UPDATE_CANCEL = ["Admin", "Staff"]; // only these roles see Update/Cancel
let currentUser = null;

document.addEventListener("DOMContentLoaded", async () => {
  currentUser = JSON.parse(sessionStorage.getItem("currentUser"));
  if (!currentUser) return;

  // Changing the sort or a filter goes back to page 1
  const firstPage = () => { pagerState.page = 1; renderSorted(); };
  document.getElementById("sort-by").addEventListener("change", firstPage);
  wireStatusTabs();

  // Doctors can't book appointments — hide the form entirely
  if (currentUser.RoleName === "Doctor") {
    document.getElementById("main-div")?.remove();
    displayAppointments();
    // The doctor sets their own daily limit and sees their queue for the chosen day
    const dateIn = document.getElementById("limit-date"), limitIn = document.getElementById("limit-input");
    document.getElementById("my-limit").classList.remove("d-none");
    dateIn.value = todayStr();
    const showMine = async () => {
      const d = await DoctorLoad.load(document.getElementById("doctor-load"), {
        baseApiUrl, userId: currentUser.UserID, date: dateIn.value || todayStr(), actingUserId: currentUser.UserID, showNames: true,
        canAct: true, onChange: () => { showMine(); displayAppointments(); },
      });
      if (d && document.activeElement !== limitIn) limitIn.value = d.limit;
    };
    dateIn.addEventListener("change", showMine);
    document.getElementById("btn-save-limit").addEventListener("click", async () => {
      const fd = new FormData();
      fd.append("operation", "setDailyLimit");
      fd.append("json", JSON.stringify({ actingUserId: currentUser.UserID, userId: currentUser.UserID, limit: limitIn.value }));
      const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });
      if (res.data == 1) { alert("Daily limit saved."); showMine(); }
      else if (res.data?.error !== "validation") alert("Could not save the limit.");
    });
    showMine();
    return;
  }

  await loadDropdowns();
  displayAppointments();

  document.getElementById("btn-submit").addEventListener("click", insertAppointment);
  // Show how full the doctor's day is whenever the doctor or the date changes
  document.getElementById("appt-doctor").addEventListener("change", refreshLoad);
  document.getElementById("appt-at").addEventListener("change", refreshLoad);
});

// ── Doctor's day: "7 of 20 booked" + queue; Book is blocked when the day is full ──
let dayFull = false;
const refreshLoad = async () => {
  const userId = document.getElementById("appt-doctor")?.value;
  const at = document.getElementById("appt-at").value;
  const data = await DoctorLoad.load(document.getElementById("doctor-load"), {
    baseApiUrl, userId, date: at ? at.slice(0, 10) : "", actingUserId: currentUser.UserID, showNames: true,
    canAct: true, onChange: () => { refreshLoad(); displayAppointments(); },
  });
  dayFull = !!(data && data.full);
  const btn = document.getElementById("btn-submit");
  btn.disabled = dayFull;
  btn.textContent = dayFull ? "Doctor is fully booked" : "Add to Queue";
};

// ── Dropdowns ───────────────────────────────────────────────────────────────
const loadDropdowns = async () => {
  // Patients
  const pRes = await axios.get(`${baseApiUrl}/patients.php`, {
    params: { operation: "getActivePatients" },
  });
  const patientSel = document.getElementById("appt-patient");
  patientSel.innerHTML = `<option value="" disabled selected>Select Patient</option>`;
  pRes.data.forEach((p) => {
    patientSel.innerHTML += `<option value="${p.PatientID}">${p.LastName}, ${p.FirstName}</option>`;
  });
  makeSearchable(patientSel, { placeholder: "Search patient by name...", noMatch: "No patients found." });

  // Block past date/times in the picker
  document.getElementById("appt-at").min = todayStr();   // date only: the time is recorded automatically
  setDefaultDateTime();

  // Doctors
  const dRes = await axios.get(`${baseApiUrl}/appointments.php`, {
    params: { operation: "getActiveDoctors" },
  });
  const doctorSel = document.getElementById("appt-doctor");
  const doctorWrap = document.getElementById("doctor-field-wrap");

  if (currentUser.RoleName === "Doctor") {
    // Doctor is booking for themselves — lock the field to their own account
    doctorWrap.innerHTML = `
      <label class="form-label">Doctor</label>
      <input type="text" class="form-control" value="${currentUser.LastName}, ${currentUser.FirstName}" disabled />
      <input type="hidden" id="appt-doctor" value="${currentUser.UserID}" />
    `;
  } else {
    doctorSel.innerHTML = `<option value="" disabled selected>Select Doctor</option>`;
    dRes.data.forEach((d) => {
      doctorSel.innerHTML += `<option value="${d.UserID}">${doctorLabel(d)}</option>`;
    });
  }
};

// ── Fetch & render table ────────────────────────────────────────────────────
const displayAppointments = async () => {
  let response;
  if (currentUser.RoleName === "Doctor") {
    response = await axios.get(`${baseApiUrl}/appointments.php`, {
      params: {
        operation: "getAppointmentsByDoctor",
        json: JSON.stringify({ userId: currentUser.UserID }),
      },
    });
  } else {
    response = await axios.get(`${baseApiUrl}/appointments.php`, {
      params: { operation: "getAllAppointments" },
    });
  }

  if (response.status === 200) {
    appointmentRows = response.data;
    if (CAN_UPDATE_CANCEL.includes(currentUser.RoleName)) await loadChangeRequests();
    renderSorted();
  } else alert("Error loading queue entries.");
};

// ── Sorting ─────────────────────────────────────────────────────────────────
let appointmentRows = [];
const pagerState = { page: 1, size: 10 };

const cmpRaw = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
const dateTimeKey = (r) => `${r.AppointmentDate}`;   // sorted by day, then queue number (who booked first)
// Same time slot: whoever submitted first (smaller queue number) comes first
const byQueue = (a, b) => (Number(a.QueueNumber) || 0) - (Number(b.QueueNumber) || 0) || a.AppointmentID - b.AppointmentID;

const APPT_SORTS = {
  // Next up: appointments still waiting (Scheduled) first, soonest date & time at the top so
  // staff can see who is next; finished / cancelled ones after, newest first.
  "next":         (a, b) => {
    const pa = a.Status === "Scheduled" ? 0 : 1, pb = b.Status === "Scheduled" ? 0 : 1;
    if (pa !== pb) return pa - pb;
    const c = cmpRaw(dateTimeKey(a), dateTimeKey(b));
    if (pa === 0) return c || byQueue(a, b);
    return -c || byQueue(a, b);
  },
  "date-desc":    (a, b) => cmpRaw(dateTimeKey(b), dateTimeKey(a)) || byQueue(a, b),
  "date-asc":     (a, b) => cmpRaw(dateTimeKey(a), dateTimeKey(b)) || byQueue(a, b),
};

// ── Status tabs: Scheduled / Completed / Cancelled are shown as separate lists ──
const KNOWN_STATUSES = ["Scheduled", "Completed", "Cancelled"];
let activeStatus = "Scheduled";
const statusGroup = (r) => (KNOWN_STATUSES.includes(r.Status) ? r.Status : "Other");

const wireStatusTabs = () => {
  document.querySelectorAll("#status-tabs [data-status]").forEach((btn) =>
    btn.addEventListener("click", () => {
      activeStatus = btn.dataset.status;
      pagerState.page = 1;
      renderSorted();
    })
  );
};

const updateStatusTabs = () => {
  const counts = { Scheduled: 0, Completed: 0, Cancelled: 0, Other: 0 };
  appointmentRows.forEach((r) => counts[statusGroup(r)]++);
  if (activeStatus === "Other" && counts.Other === 0) activeStatus = "Scheduled";
  Object.keys(counts).forEach((k) => (document.getElementById(`count-${k}`).textContent = counts[k]));
  document.getElementById("tab-other").style.display = counts.Other > 0 ? "" : "none";
  document.querySelectorAll("#status-tabs [data-status]").forEach((btn) =>
    btn.classList.toggle("active", btn.dataset.status === activeStatus)
  );
};

const renderSorted = () => {
  const sortKey = document.getElementById("sort-by").value;
  updateStatusTabs();
  const rows = appointmentRows.filter((r) => statusGroup(r) === activeStatus);
  const sorted = rows.sort(APPT_SORTS[sortKey]);
  renderTable(Pager.paginate(pagerState, sorted));
  Pager.controls(document.getElementById("pager"), pagerState, sorted.length, renderSorted);
};

const renderTable = (rows) => {
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  if (!rows || rows.length === 0) {
    tableDiv.innerHTML = `<p class="text-muted">No queue entries found.</p>`;
    return;
  }

  const canModify = CAN_UPDATE_CANCEL.includes(currentUser.RoleName);
  const isAdmin = currentUser.RoleName === "Admin";
  const isStaff = currentUser.RoleName === "Staff"; // Staff take the vital signs

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `
    <thead>
      <tr>
        <th class="text-nowrap">REQUESTED</th>
        <th>DATE</th>
        <th>TIME BOOKED</th>
        <th class="text-nowrap" title="Place in the doctor\'s line-up for that day, by queue time (same minute: who requested first)">QUEUE</th>
        <th>PATIENT</th>
        <th>DOCTOR</th>
        <th>REASON</th>
        <th>STATUS</th>
        <th>ACTION</th>
      </tr>
    </thead>
  `;

  const tbody = document.createElement("tbody");
  rows.forEach((row) => {
    const badge = badgeColor(row.Status);
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="text-nowrap small">${row.CreatedAt ? row.CreatedAt.slice(0, 16).replace("T", " ") : "—"}</td>
      <td>${row.AppointmentDate}</td>
      <td>${formatTime(row.AppointmentTime)}</td>
      <td>${row.QueueNumber ? `<span class="badge bg-primary">#${row.QueueNumber}</span>` : "—"}</td>
      <td>${row.PatientName}</td>
      <td>${row.DoctorName}</td>
      <td>${row.Reason ?? "—"}</td>
      <td><span class="badge ${badge}">${row.Status}</span>${crBadge(row)}</td>
      <td>
        <button class="btn btn-primary btn-sm btn-view me-1">View</button>
        ${isStaff && row.Status !== "Cancelled"
          ? (Number(row.HasVitals) > 0
              ? `<button class="btn btn-info btn-sm btn-vitals me-1">Edit Vital Signs</button>`
              : `<button class="btn btn-warning btn-sm btn-vitals me-1">Record Vital Signs</button>`)
          : ""}
        ${canModify && row.Status === "Scheduled"
          ? `<button class="btn btn-success btn-sm btn-update me-1">Edit</button>
             <button class="btn btn-danger btn-sm btn-cancel">${isAdmin ? "Deactivate" : "Cancel"}</button>`
          : ""}
        ${canModify && row.Status === "Scheduled" ? crButtons(row) : ""}
        ${isAdmin && row.Status === "Cancelled"
          ? `<button class="btn btn-warning btn-sm btn-restore">Restore</button>`
          : ""}
      </td>
    `;
    tbody.appendChild(tr);

    tr.querySelector(".btn-view").addEventListener("click", () => viewAppointment(row));
    tr.querySelector(".btn-vitals")?.addEventListener("click", () => openVitals(row));
    if (canModify && row.Status === "Scheduled") {
      tr.querySelector(".btn-update").addEventListener("click", () => showUpdateModal(row));
      tr.querySelector(".btn-cancel").addEventListener("click", () => cancelAppointment(row));
    }
    tr.querySelector(".btn-restore")?.addEventListener("click", () => restoreAppointment(row));
    tr.querySelector(".btn-request")?.addEventListener("click", () => openRequestModal(row));
    tr.querySelector(".btn-withdraw")?.addEventListener("click", () => withdrawRequest(row));
  });

  table.appendChild(tbody);
  NameList.apply(table, { nameHeader: "PATIENT", hideButtons: [".btn-view"] });  // the popup already is the details view  // names only; click a name for the full details
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

// ── Vital signs (Staff) ──────────────────────────────────────────────────────
const openVitals = async (row) => {
  let existing = null;
  if (Number(row.HasVitals) > 0) {
    const res = await axios.get(`${baseApiUrl}/vital-signs.php`, {
      params: { operation: "getVitalSignByAppointment", json: JSON.stringify({ appointmentId: row.AppointmentID }) },
    });
    existing = res.data?.[0] ?? null;
  }
  showIntakeModal({
    appointmentId: row.AppointmentID,
    patientName:   row.PatientName,
    dateLabel:     `${row.AppointmentDate} ${formatTime(row.AppointmentTime)}`,
    intake:        { reason: row.Reason },
    vitals:        existing,
    onSaved:       displayAppointments,
  });
};

// ── View modal ──────────────────────────────────────────────────────────────
const viewAppointment = (row) => {
  document.getElementById("blank-modal-title").innerText = "Queuing Details";
  document.getElementById("blank-main-div").innerHTML = `
    <table class="table table-sm">
      <tr><td><strong>Patient</strong></td><td>${row.PatientName}</td></tr>
      <tr><td><strong>Doctor</strong></td><td>${row.DoctorName}</td></tr>
      <tr><td><strong>Requested</strong></td><td>${row.CreatedAt ?? "—"}</td></tr>
      <tr><td><strong>Date</strong></td><td>${row.AppointmentDate}</td></tr>
      <tr><td><strong>Time</strong></td><td>${formatTime(row.AppointmentTime)}</td></tr>
      <tr><td><strong>Queue number</strong></td><td>${row.QueueNumber ? `#${row.QueueNumber} (place in this doctor\'s line-up for the day)` : "—"}</td></tr>
      <tr><td><strong>Reason</strong></td><td>${row.Reason ?? "—"}</td></tr>
      <tr><td><strong>Notes</strong></td><td>${row.Notes ?? "—"}</td></tr>
      <tr><td><strong>Status</strong></td><td><span class="badge ${badgeColor(row.Status)}">${row.Status}</span></td></tr>
    </table>
  `;
  document.getElementById("blank-modal-footer").innerHTML = `
    <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
  `;
  new bootstrap.Modal(document.getElementById("blank-modal"), { backdrop: "static" }).show();
};

// ── Update modal (Admin/Staff only) ────────────────────────────────────────
const showUpdateModal = async (row) => {
  // Load fresh doctor list for the dropdown
  const dRes = await axios.get(`${baseApiUrl}/appointments.php`, {
    params: { operation: "getActiveDoctors" },
  });
  const pRes = await axios.get(`${baseApiUrl}/patients.php`, {
    params: { operation: "getActivePatients" },
  });

  const doctorOptions = dRes.data.map((d) =>
    `<option value="${d.UserID}" ${d.UserID == row.UserID ? "selected" : ""}>${doctorLabel(d)}</option>`
  ).join("");
  const patientOptions = pRes.data.map((p) =>
    `<option value="${p.PatientID}" ${p.PatientID == row.PatientID ? "selected" : ""}>${p.LastName}, ${p.FirstName}</option>`
  ).join("");

  const rowTime = String(row.AppointmentTime ?? "").slice(0, 5);   // time recorded when it was booked (kept)
  const rowAt = `${row.AppointmentDate}T${rowTime}`;
  const statusOptions = ["Scheduled", "Completed", "Cancelled", "No-Show"].map((s) =>
    `<option value="${s}" ${s === row.Status ? "selected" : ""}>${s}</option>`
  ).join("");

  document.getElementById("update-modal-body").innerHTML = `
    <div class="row g-2">
      <div class="col-md-6">
        <label class="form-label">Patient <span class="text-danger">*</span></label>
        <select class="form-select" id="upd-patient" data-v="appointment.patientId">${patientOptions}</select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Doctor <span class="text-danger">*</span></label>
        <select class="form-select" id="upd-doctor" data-v="appointment.userId">${doctorOptions}</select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Date <span class="text-danger">*</span></label>
        <input type="date" class="form-control" id="upd-at" min="${todayStr()}" value="${row.AppointmentDate}" />
        <div class="form-text">Booked at ${formatTime(row.AppointmentTime)} (recorded automatically).</div>
      </div>
      <div class="col-md-6">
        <label class="form-label">Status</label>
        <select class="form-select" id="upd-status" data-v="appointment.status">${statusOptions}</select>
      </div>
      <div class="col-12">
        <label class="form-label">Reason</label>
        <input type="text" class="form-control" id="upd-reason" data-v="appointment.reason" value="${row.Reason ?? ""}" />
      </div>
      <div class="col-12">
        <label class="form-label">Notes</label>
        <textarea class="form-control" id="upd-notes" data-v="appointment.notes" rows="2">${row.Notes ?? ""}</textarea>
      </div>
    </div>
  `;

  document.getElementById("update-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-update">Save Changes</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("update-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-update").addEventListener("click", async () => {
    const data = {
      appointmentId:   row.AppointmentID,
      patientId:       document.getElementById("upd-patient").value,
      userId:          document.getElementById("upd-doctor").value,
      appointmentAt:   `${document.getElementById("upd-at").value}T${rowTime}`,
      status:          document.getElementById("upd-status").value,
      reason:          document.getElementById("upd-reason").value,
      notes:           document.getElementById("upd-notes").value,
    };

    // "Not in the past" is judged on the date only, and only when the date was actually changed,
    // so an old appointment can still be marked Completed / No-Show.
    const relax = data.appointmentAt === rowAt ? ["notPast"] : [];
    if (!Validate.ok("appointment", data, { relax })) return;

    const fd = new FormData();
    fd.append("operation", "updateAppointment");
    fd.append("json", JSON.stringify(data));
    const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });

    if (res.data == 1) {
      modal.hide();
      displayAppointments();
      alert("Queue updated!");
    } else {
      alert(res.data?.error === "date_in_past" ? "Queue date cannot be in the past." : "ERROR updating queue.");
    }
  });
};

// ── Cancel (Admin/Staff only) ───────────────────────────────────────────────
const cancelAppointment = async (row) => {
  const adminUser = currentUser.RoleName === "Admin";
  if (!(await showConfirm(
    adminUser
      ? `Deactivate queue for ${row.PatientName} on ${row.AppointmentDate}? It will be marked Cancelled and can be restored later.`
      : `Cancel queue for ${row.PatientName} on ${row.AppointmentDate}?`,
    {
      type: "danger",
      title: adminUser ? "Deactivate queue" : "Cancel queue",
      confirmText: adminUser ? "Deactivate" : "Yes, cancel",
      cancelText: "Keep",
    }
  ))) return;
  const fd = new FormData();
  fd.append("operation", "cancelAppointment");
  fd.append("json", JSON.stringify({ appointmentId: row.AppointmentID }));
  const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });
  if (res.data == 1) {
    displayAppointments();
    alert("Queue cancelled.");
  } else {
    alert("ERROR cancelling queue.");
  }
};

// ── Restore (Admin only) ────────────────────────────────────────────────────
const restoreAppointment = async (row) => {
  const fd = new FormData();
  fd.append("operation", "restoreAppointment");
  fd.append("json", JSON.stringify({ appointmentId: row.AppointmentID }));
  const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });
  if (res.data == 1) {
    displayAppointments();
    alert("Queue restored (set back to Scheduled).");
  } else {
    alert("ERROR restoring queue.");
  }
};

// ── Insert (all roles) ──────────────────────────────────────────────────────
const insertAppointment = async () => {
  const patientId = document.getElementById("appt-patient").value;
  const userId    = document.getElementById("appt-doctor").value;
  const date      = document.getElementById("appt-at").value;      // YYYY-MM-DD (only the date is chosen)
  const at        = date ? `${date}T${nowTimeStr()}` : "";         // + the current time = when the queue is booked
  const time      = at.slice(11, 16);

  const isStaff = currentUser.RoleName === "Staff";
  const patientName = document.getElementById("appt-patient").selectedOptions[0]?.textContent ?? "";

  const data = {
    patientId,
    userId,
    appointmentAt: at,
    reason: document.getElementById("appt-reason").value,
    notes:  document.getElementById("appt-notes").value,
    returnId: isStaff, // Staff need the new AppointmentID to record vital signs
  };
  if (!Validate.ok("appointment", data)) return;
  if (dayFull) { alert("This doctor is fully booked on that day. Please choose another day or another doctor."); return; }

  const fd = new FormData();
  fd.append("operation", "insertAppointment");
  fd.append("json", JSON.stringify(data));
  const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });

  if (res.data == 1) {
    clearForm();
    displayAppointments();
    refreshLoad();
    alert("Added to the queue successfully!");
  } else if (res.data?.appointmentId) {
    // Staff: booking is done — go straight to the patient's vital signs (no extra question)
    clearForm();
    displayAppointments();
    refreshLoad();
    alert("Added to the queue successfully!");
    showIntakeModal({
      appointmentId: res.data.appointmentId,
      patientName,
      dateLabel: `${date} ${formatTime(time)}`,
      intake: { reason: data.reason },
      vitals: null,
      onSaved: displayAppointments,
    });
  } else if (res.data?.error === "date_in_past") {
    alert("Queue date cannot be in the past.");
  } else if (res.data?.error === "missing_required_fields") {
    alert("Please fill in all required fields.");
  } else {
    alert("ERROR booking queue.");
  }
};

const clearForm = () => {
  document.getElementById("appt-patient").value = "";
  const doctorEl = document.getElementById("appt-doctor");
  if (doctorEl && doctorEl.tagName === "SELECT") doctorEl.value = "";
  setDefaultDateTime();
  dayFull = false;
  const b = document.getElementById("btn-submit"); b.disabled = false; b.textContent = "Add to Queue";
  document.getElementById("doctor-load").classList.add("d-none");
  document.getElementById("appt-reason").value = "";
  document.getElementById("appt-notes").value  = "";
  document.querySelectorAll("#add-form-fields .is-invalid, #main-div .is-invalid").forEach((el) => el.classList.remove("is-invalid"));
  document.querySelectorAll("#main-div .v-msg").forEach((el) => el.remove());
};

// ── Helpers ─────────────────────────────────────────────────────────────────
// Today as YYYY-MM-DD in the user's local time (not UTC)
const todayStr = () => {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
};

// Current time as HH:MM (24h, local) — the format <input type="time"> expects
const nowTimeStr = () => {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};

// Pre-fill the booking form with today's date (the time is recorded automatically when Book is pressed)
const setDefaultDateTime = () => {
  document.getElementById("appt-at").value = todayStr();
};

// "Dela Cruz, Juan — Cardiology" (or "— No specialization")
const doctorLabel = (d) => `${d.DoctorName} — ${d.Specializations || "No specialization"}`;

const formatTime = (t) => {
  if (!t) return "";
  const [h, m] = t.split(":");
  const hr = parseInt(h);
  return `${hr % 12 || 12}:${m} ${hr < 12 ? "AM" : "PM"}`;
};

const badgeColor = (status) => {
  switch (status) {
    case "Completed":  return "bg-success";
    case "Scheduled":  return "bg-primary";
    case "Cancelled":  return "bg-danger";
    case "No-Show":    return "bg-warning text-dark";
    default:           return "bg-secondary";
  }
};


// ════════════════════════════════════════════════════════════════════════════
// Doctor unavailable → Staff ask the patient to change the date or see a similar doctor
// A change request recommends another doctor with a similar specialization and/or a new date.
// The patient answers from "My Appointments"; accepting updates the appointment.
// ════════════════════════════════════════════════════════════════════════════
let crByAppt = {};   // AppointmentID → newest change request

const crEsc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const crDateStr = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const crTomorrow = () => { const d = new Date(); d.setDate(d.getDate() + 1); return crDateStr(d); };

const crPost = async (operation, payload) => {
  const fd = new FormData();
  fd.append("operation", operation);
  fd.append("json", JSON.stringify({ actingUserId: currentUser.UserID, ...payload }));
  const res = await axios({ url: `${baseApiUrl}/change-requests.php`, method: "POST", data: fd });
  return res.data;
};
const crGet = async (operation, payload) => {
  const res = await axios.get(`${baseApiUrl}/change-requests.php`, {
    params: { operation, json: JSON.stringify({ actingUserId: currentUser.UserID, ...payload }) },
  });
  return res.data;
};
// The shared axios interceptor already shows server validation messages; show it ourselves only if it didn't.
const crShowError = (data) => {
  if (data?.error !== "validation") { alert("Something went wrong. Please try again."); return; }
  if (!window.__validationShownAt || Date.now() - window.__validationShownAt > 2500) alert(data.message);
};

const loadChangeRequests = async () => {
  try {
    const list = await crGet("getRequests", {});
    crByAppt = {};
    if (Array.isArray(list)) list.forEach((r) => { if (!crByAppt[r.AppointmentID]) crByAppt[r.AppointmentID] = r; });
  } catch (e) { crByAppt = {}; }
};

const crBadge = (row) => {
  const r = crByAppt[row.AppointmentID];
  if (!r || row.Status !== "Scheduled") return "";
  if (r.Status === "Pending")  return ` <span class="badge bg-warning text-dark" title="Waiting for the patient to answer">Change requested</span>`;
  if (r.Status === "Declined") return ` <span class="badge bg-danger" title="The patient declined the recommendation">Patient declined</span>`;
  if (r.Status === "Accepted") return ` <span class="badge bg-success" title="The patient accepted and the queue was updated">Patient accepted</span>`;
  return "";
};

const crButtons = (row) => {
  const r = crByAppt[row.AppointmentID];
  return r && r.Status === "Pending"
    ? `<button class="btn btn-outline-secondary btn-sm btn-withdraw ms-1">Withdraw Request</button>`
    : `<button class="btn btn-outline-warning btn-sm btn-request ms-1" title="The doctor can't make it: ask the patient to change the date or see a similar doctor">Request Change</button>`;
};

const withdrawRequest = async (row) => {
  const r = crByAppt[row.AppointmentID];
  if (!r) return;
  if (!(await showConfirm("Withdraw this change request? The queue stays as it is.", { confirmText: "Withdraw" }))) return;
  const data = await crPost("withdrawRequest", { requestId: r.RequestID });
  if (data == 1) { await displayAppointments(); } else crShowError(data);
};

// One modal element, filled in each time
const crModalEl = () => {
  let el = document.getElementById("cr-modal");
  if (el) return el;
  el = document.createElement("div");
  el.className = "modal fade";
  el.id = "cr-modal";
  el.tabIndex = -1;
  el.innerHTML = `
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header"><h5 class="modal-title" id="cr-title"></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body" id="cr-body"></div>
        <div class="modal-footer" id="cr-footer"></div>
      </div>
    </div>`;
  document.body.appendChild(el);
  return el;
};

// The two recommendation options (shared by the single and the "doctor unavailable" forms)
const crOptionsHtml = (defaultTime) => `
  <div class="form-check">
    <input class="form-check-input" type="checkbox" id="cr-opt-doc" disabled />
    <label class="form-check-label fw-semibold" for="cr-opt-doc">Recommend another doctor (similar specialization)</label>
  </div>
  <select class="form-select form-select-sm mb-1 mt-1" id="cr-doc" disabled><option value="">Loading doctors…</option></select>
  <div class="form-text mb-3" id="cr-doc-note"></div>

  <div class="form-check">
    <input class="form-check-input" type="checkbox" id="cr-opt-date" />
    <label class="form-check-label fw-semibold" for="cr-opt-date">Suggest a new date</label>
  </div>
  <div class="row g-2 mt-0 mb-2">
    <div class="col-7"><input type="date" class="form-control form-control-sm" id="cr-date" value="${crTomorrow()}" min="${crDateStr(new Date())}" disabled /></div>
    <div class="col-5 form-text align-self-center">Time stays as booked</div>
  </div>
  <div class="form-text">Tick one or both. The patient chooses which one to accept, or declines.</div>`;

const crWireOptions = () => {
  const link = (cb, ...inputs) => {
    const sync = () => inputs.forEach((i) => i && (i.disabled = !cb.checked));
    cb.addEventListener("change", sync); sync();
  };
  link(document.getElementById("cr-opt-date"), document.getElementById("cr-date"), document.getElementById("cr-time"));
};

const crFillDoctors = async (params) => {
  const sel = document.getElementById("cr-doc");
  const cb  = document.getElementById("cr-opt-doc");
  const note = document.getElementById("cr-doc-note");
  let list = [];
  try { list = await crGet("getSimilarDoctors", params); } catch (e) { /* handled below */ }
  if (!Array.isArray(list) || list.length === 0) {
    sel.innerHTML = `<option value="">No similar doctor available</option>`;
    cb.checked = false; cb.disabled = true; sel.disabled = true;
    note.textContent = "No other active doctor shares this specialization, so only a new date can be suggested.";
    return;
  }
  sel.innerHTML = list.map((d) => `<option value="${d.UserID}">${crEsc(d.DoctorName)} — ${crEsc(d.Specializations || "")}</option>`).join("");
  cb.disabled = false;
  const sync = () => { sel.disabled = !cb.checked; };
  cb.addEventListener("change", sync);
  cb.checked = true; sync();   // recommending a similar doctor is the usual choice, so start with it ticked
};

// Reads the options the staff ticked; returns null (after showing a message) if none
const crReadOptions = (withTime) => {
  const useDoc  = document.getElementById("cr-opt-doc").checked;
  const useDate = document.getElementById("cr-opt-date").checked;
  const reason  = document.getElementById("cr-reason").value.trim();
  if (!reason) { alert("Please write a short message for the patient."); return null; }
  if (!useDoc && !useDate) { alert("Tick at least one recommendation: another doctor or a new date."); return null; }
  const out = { reason };
  if (useDoc) out.suggestedUserId = document.getElementById("cr-doc").value;
  if (useDate) {
    out.suggestedDate = document.getElementById("cr-date").value;
    if (!out.suggestedDate) { alert("Please choose the new date."); return null; }
    if (withTime && document.getElementById("cr-time")) out.suggestedTime = document.getElementById("cr-time").value;   // no time box any more: the booked time is kept
  }
  return out;
};

// ── One appointment ─────────────────────────────────────────────────────────
const openRequestModal = (row) => {
  const el = crModalEl();
  document.getElementById("cr-title").textContent = "Request queue change";
  document.getElementById("cr-body").innerHTML = `
    <div class="mb-3 small">
      <div><span class="text-muted">Patient:</span> <strong>${crEsc(row.PatientName)}</strong></div>
      <div><span class="text-muted">Doctor:</span> ${crEsc(row.DoctorName)}</div>
      <div><span class="text-muted">Booked for:</span> ${crEsc(row.AppointmentDate)} ${crEsc(formatTime(row.AppointmentTime))}</div>
    </div>
    <label class="form-label" for="cr-reason">Message to the patient <span class="text-danger">*</span></label>
    <textarea class="form-control mb-3" id="cr-reason" rows="2" maxlength="255">${crEsc(`${row.DoctorName} is unavailable on ${row.AppointmentDate}. Sorry for the inconvenience.`)}</textarea>
    ${crOptionsHtml(String(row.AppointmentTime || "").slice(0, 5))}`;
  document.getElementById("cr-footer").innerHTML = `
    <button type="button" class="btn btn-warning btn-sm" id="cr-send">Send to patient</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>`;
  crWireOptions();
  crFillDoctors({ appointmentId: row.AppointmentID });

  const modal = bootstrap.Modal.getOrCreateInstance(el);
  document.getElementById("cr-send").onclick = async () => {
    const opts = crReadOptions(true);
    if (!opts) return;
    const data = await crPost("createRequest", { appointmentId: row.AppointmentID, ...opts });
    if (data == 1) {
      modal.hide();
      await displayAppointments();
      alert("Request sent. The patient will see it in My Queuing.");
    } else crShowError(data);
  };
  modal.show();
};

// ── "Doctor unavailable" for a whole day ────────────────────────────────────
const openUnavailableModal = async () => {
  const el = crModalEl();
  const res = await axios.get(`${baseApiUrl}/appointments.php`, { params: { operation: "getActiveDoctors" } });
  const doctors = Array.isArray(res.data) ? res.data : [];
  const today = crDateStr(new Date());

  document.getElementById("cr-title").textContent = "Doctor unavailable";
  document.getElementById("cr-body").innerHTML = `
    <div class="row g-2 mb-2">
      <div class="col-7">
        <label class="form-label" for="cr-un-doctor">Doctor</label>
        <select class="form-select form-select-sm" id="cr-un-doctor">
          <option value="">Select doctor</option>
          ${doctors.map((d) => `<option value="${d.UserID}">${crEsc(d.DoctorName)}</option>`).join("")}
        </select>
      </div>
      <div class="col-5">
        <label class="form-label" for="cr-un-date">Unavailable on</label>
        <input type="date" class="form-control form-control-sm" id="cr-un-date" value="${today}" min="${today}" />
      </div>
    </div>
    <div class="small mb-3" id="cr-un-affected"><span class="text-muted">Choose a doctor to see the affected patients.</span></div>
    <label class="form-label" for="cr-reason">Message to the patients <span class="text-danger">*</span></label>
    <textarea class="form-control mb-3" id="cr-reason" rows="2" maxlength="255"></textarea>
    ${crOptionsHtml(null)}`;
  document.getElementById("cr-footer").innerHTML = `
    <button type="button" class="btn btn-warning btn-sm" id="cr-send" disabled>Send to affected patients</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>`;
  crWireOptions();
  // Until a doctor is chosen there is nothing to recommend yet
  document.getElementById("cr-doc").innerHTML = `<option value="">Select a doctor first</option>`;
  document.getElementById("cr-opt-doc").disabled = true;

  const docSel = document.getElementById("cr-un-doctor");
  const dateIn = document.getElementById("cr-un-date");
  const sendBtn = document.getElementById("cr-send");
  const affectedBox = document.getElementById("cr-un-affected");
  const msg = document.getElementById("cr-reason");

  const affectedRows = () => appointmentRows.filter((r) =>
    String(r.UserID) === docSel.value && r.AppointmentDate === dateIn.value && r.Status === "Scheduled" &&
    !(crByAppt[r.AppointmentID] && crByAppt[r.AppointmentID].Status === "Pending"));

  const refresh = () => {
    const name = docSel.selectedOptions[0]?.textContent || "";
    if (!docSel.value) {
      affectedBox.innerHTML = `<span class="text-muted">Choose a doctor to see the affected patients.</span>`;
      sendBtn.disabled = true; return;
    }
    msg.value = `${name} is unavailable on ${dateIn.value}. Sorry for the inconvenience.`;
    const rows = affectedRows();
    affectedBox.innerHTML = rows.length
      ? `<strong>${rows.length}</strong> scheduled queue${rows.length > 1 ? "s" : ""} will get this request:<ul class="mb-0 mt-1">${
          rows.map((r) => `<li>${crEsc(r.PatientName)} — ${crEsc(formatTime(r.AppointmentTime))}</li>`).join("")}</ul>`
      : `<span class="text-muted">No scheduled queue entries without a pending request for this doctor on that date.</span>`;
    sendBtn.disabled = rows.length === 0;
  };

  docSel.addEventListener("change", async () => {
    // reset the similar-doctor option for the newly chosen doctor
    const cb = document.getElementById("cr-opt-doc");
    const clone = cb.cloneNode(true); cb.replaceWith(clone);   // drop the old change listener
    document.getElementById("cr-doc-note").textContent = "";
    if (docSel.value) await crFillDoctors({ doctorId: docSel.value });
    refresh();
  });
  dateIn.addEventListener("change", refresh);

  const modal = bootstrap.Modal.getOrCreateInstance(el);
  sendBtn.onclick = async () => {
    const opts = crReadOptions(false);
    if (!opts) return;
    const data = await crPost("createBulkRequests", { doctorId: docSel.value, date: dateIn.value, ...opts });
    if (data && data.created !== undefined) {
      modal.hide();
      await displayAppointments();
      const skipped = (data.skipped || []).map((s) => `• ${s.patient}: ${s.why}`).join("\n");
      alert(`Sent ${data.created} request${data.created === 1 ? "" : "s"}.` + (skipped ? `\n\nNot sent:\n${skipped}` : ""));
    } else crShowError(data);
  };
  modal.show();
};

document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("btn-unavailable");
  const u = JSON.parse(sessionStorage.getItem("currentUser") || "null");
  if (btn && u && CAN_UPDATE_CANCEL.includes(u.RoleName)) {
    btn.classList.remove("d-none");
    btn.addEventListener("click", openUnavailableModal);
  }
});
