// Medical history shown as ONE table: a row per consultation, newest first (descending).
// Each row has a Details button that opens the vitals, lab results, prescriptions and print buttons.
// Shared by the Medical History page, the Patient Details popup, the consultation page's
// Patient History tab and the "View Medical History" window, so they always look the same.
const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const dash = (v) => (v === null || v === undefined || String(v).trim() === "" ? "—" : esc(v));

// Newest first: consultation date, then appointment date, time, and finally ID.
const cmpDesc = (a, b) => (a < b ? 1 : a > b ? -1 : 0);
export const sortNewestFirst = (list) =>
  [...list].sort((a, b) =>
    cmpDesc(a.ConsultationDate ?? "", b.ConsultationDate ?? "") ||
    cmpDesc(a.AppointmentDate ?? "", b.AppointmentDate ?? "") ||
    cmpDesc(a.AppointmentTime ?? "", b.AppointmentTime ?? "") ||
    cmpDesc(Number(a.ConsultationID), Number(b.ConsultationID)));

// Visit numbers count from the first visit: the oldest is #1, so the newest has the highest number.
export const visitNumbers = (list) => {
  const sorted = sortNewestFirst(list);
  return new Map(sorted.map((c, i) => [c, sorted.length - i]));
};

const label = (t) => `<div class="text-muted" style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;">${t}</div>`;

const vitalsHtml = (c) => {
  const v = (c.vitals || [])[0];
  if (!v) return `<span class="text-muted small">None recorded</span>`;
  const items = [
    v.Temperature && `<i data-icon='thermometer'></i> ${esc(v.Temperature)}°C`,
    v.BloodPressure && `<i data-icon='droplet'></i> ${esc(v.BloodPressure)} mmHg`,
    v.HeartRate && `<i data-icon='activity'></i> ${esc(v.HeartRate)} bpm`,
    v.OxygenSaturation && `<i data-icon='wind'></i> SpO₂ ${esc(v.OxygenSaturation)}%`,
    v.Weight && `<i data-icon='scale'></i> ${esc(v.Weight)} kg`,
    v.Height && `<i data-icon='ruler'></i> ${esc(v.Height)} cm`,
  ].filter(Boolean);
  return items.length
    ? items.map((x) => `<span class="badge bg-light text-dark border me-1">${x}</span>`).join("")
    : `<span class="text-muted small">None recorded</span>`;
};

const labsHtml = (c) => (c.labs || []).length
  ? `<table class="table table-sm mb-0" style="font-size:.8rem;"><thead><tr><th>Test</th><th>Date</th><th>Result</th><th>Reference</th></tr></thead><tbody>${c.labs.map((l) => `<tr><td>${esc(l.TestName)}</td><td>${esc(l.TestDate)}</td><td>${dash(l.Result)}</td><td class="text-muted">${dash(l.ReferenceRange)}</td></tr>`).join("")}</tbody></table>`
  : `<span class="text-muted small">None recorded</span>`;

const rxHtml = (c) => (c.prescriptions || []).length
  ? `<table class="table table-sm mb-0" style="font-size:.8rem;"><thead><tr><th>Medicine</th><th>Dosage</th><th>Frequency</th><th>Duration</th></tr></thead><tbody>${c.prescriptions.map((r) => `<tr><td>${esc(r.MedicineName)} <span class="text-muted">(${esc(r.GenericName)})</span></td><td>${dash(r.Dosage)}</td><td>${dash(r.Frequency)}</td><td>${dash(r.Duration)}</td></tr>`).join("")}</tbody></table>`
  : `<span class="text-muted small">None recorded</span>`;

// Doctors, Staff and Admin may print documents. Patients may not.
const PRINT_ROLES = ["Doctor", "Staff", "Admin"];
export const canPrintDocuments = () => {
  try { return PRINT_ROLES.includes(JSON.parse(sessionStorage.getItem("currentUser") || "null")?.RoleName); } catch (e) { return false; }
};

const printLinks = (c) => {
  if (!canPrintDocuments()) return "";
  const id = encodeURIComponent(c.ConsultationID);
  const link = (type, text) =>
    `<a class="link-secondary text-decoration-none small text-nowrap" href="print-record.html?type=${type}&id=${id}"><i data-icon='printer'></i> ${text}</a>`;
  const links = [
    link("medical-certificate", "Medical Certificate"),
    (c.prescriptions || []).length ? link("prescription", "Prescription") : "",
  ].filter(Boolean);
  return `<div class="border-top mt-3 pt-2 d-flex flex-wrap align-items-center gap-3">
    ${label("Documents")}${links.join("")}
  </div>`;
};

const COLS = 7;

const rowHtml = (c, n) => {
  const dx = (c.diagnoses || []).length
    ? c.diagnoses.map((d) => `<span class="badge bg-light text-dark border me-1 mb-1" title="${esc(d.DiagnosisName)}">${esc(d.ICD10Code)} — ${esc(d.DiagnosisName)}</span>`).join("")
    : `<span class="text-muted small">None recorded</span>`;
  return `
    <tr data-con="${esc(c.ConsultationID)}">
      <td class="text-nowrap"><span class="badge bg-secondary">#${n}</span></td>
      <td class="text-nowrap">${esc(c.ConsultationDate)}</td>
      <td>${dash(c.DoctorName)}</td>
      <td>${dash(c.Reason)}${c.ChiefComplaint ? `<div class="text-muted small">${esc(c.ChiefComplaint)}</div>` : ""}</td>
      <td>${dx}</td>
      <td style="white-space:pre-wrap;">${dash([c.Treatment, c.Notes].map((x) => String(x ?? "").trim()).filter(Boolean).join("\n\n"))}</td>
      <td class="text-end text-nowrap"><button type="button" class="btn btn-outline-secondary btn-sm" data-details="${esc(c.ConsultationID)}" aria-expanded="false">Details</button></td>
    </tr>
    <tr class="d-none" data-detail-for="${esc(c.ConsultationID)}">
      <td colspan="${COLS}" class="bg-body-tertiary">
        <div class="p-2">
          ${c.Symptoms ? `<div class="mb-2">${label("Symptoms")}<div style="font-size:.82rem;">${esc(c.Symptoms)}</div></div>` : ""}
          <div class="mb-2">${label("<i data-icon='stethoscope'></i> Vital Signs")}${vitalsHtml(c)}</div>
          <div class="mb-2">${label("<i data-icon='flask'></i> Laboratory Results")}${labsHtml(c)}</div>
          <div>${label("<i data-icon='pill'></i> Prescriptions")}${rxHtml(c)}</div>
          ${printLinks(c)}
        </div>
      </td>
    </tr>`;
};

// The table for a list of consultations (already filtered if you like).
// `numbers` (from visitNumbers on the FULL list) keeps visit numbers steady while a search is active.
export const historyTableHtml = (list, numbers = visitNumbers(list)) => {
  const rows = sortNewestFirst(list);
  return `
    <div class="table-responsive">
      <table class="table table-sm table-hover align-middle mb-0" style="font-size:.85rem;">
        <thead class="table-light">
          <tr><th>Visit</th><th>Date</th><th>Doctor</th><th>Reason / Complaint</th><th>Diagnoses</th><th>Treatment Notes</th><th></th></tr>
        </thead>
        <tbody>${rows.map((c) => rowHtml(c, numbers.get(c) ?? "")).join("")}</tbody>
      </table>
    </div>`;
};

// Makes the Details buttons inside `pane` open / close their row. Safe to call on every redraw.
export const wireHistoryTable = (pane) => {
  if (pane._historyWired) return;
  pane._historyWired = true;
  pane.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-details]");
    if (!btn || !pane.contains(btn)) return;
    const detail = [...pane.querySelectorAll("tr[data-detail-for]")].find((r) => r.dataset.detailFor === btn.dataset.details);
    if (!detail) return;
    const open = detail.classList.toggle("d-none") === false;
    btn.textContent = open ? "Hide" : "Details";
    btn.setAttribute("aria-expanded", String(open));
  });
};
