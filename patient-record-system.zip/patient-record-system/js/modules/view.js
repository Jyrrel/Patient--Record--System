import { historyTableHtml, wireHistoryTable } from "../history-table.js?v=20261223";
const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const actingUserId = () => JSON.parse(sessionStorage.getItem("currentUser") || "null")?.UserID;

export const viewModal = async (patientId) => {
  document.getElementById("blank-modal-title").innerText = "Patient Details";

  const patient = await getPatientDetails(patientId);
  const p = patient[0];

  const detailsHtml = `
    <table class="table table-sm mb-0">
      <tr><td>Last Name</td><td>${esc(p.LastName)}</td></tr>
      <tr><td>First Name</td><td>${esc(p.FirstName)}</td></tr>
      <tr><td>Date of Birth</td><td>${esc(p.DateOfBirth)}</td></tr>
      <tr><td>Gender</td><td>${esc(p.Gender)}${p.Gender === "Other" && p.GenderDetails ? ` (${esc(p.GenderDetails)})` : ""}</td></tr>
      <tr><td>Phone</td><td>${esc(p.Phone)}</td></tr>
      <tr><td>Address</td><td>${esc(p.Address)}</td></tr>
      <tr><td>Status</td><td>${esc(p.Status)}</td></tr>
    </table>`;

  // Tabs instead of a "View Medical History" button: the history loads the first time its tab is opened.
  document.getElementById("blank-main-div").innerHTML = `
    <ul class="nav nav-tabs mb-3" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="tab-details-btn" data-bs-toggle="tab" data-bs-target="#tab-details" type="button" role="tab">Details</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="tab-history-btn" data-bs-toggle="tab" data-bs-target="#tab-history" type="button" role="tab"><i data-icon='clipboard'></i> Medical History</button>
      </li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane fade show active" id="tab-details" role="tabpanel">${detailsHtml}</div>
      <div class="tab-pane fade" id="tab-history" role="tabpanel">
        <div class="text-center text-muted py-4">Loading...</div>
      </div>
    </div>
  `;

  let historyLoaded = false;
  document.getElementById("tab-history-btn").addEventListener("shown.bs.tab", async () => {
    if (historyLoaded) return;
    historyLoaded = true;
    await loadHistoryTab(patientId, document.getElementById("tab-history"));
  });

  document.getElementById("blank-modal-footer").innerHTML = `
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
  `;

  // This modal is shared with Update / Delete, so only widen it while the history tab needs room.
  const modalEl = document.getElementById("blank-modal");
  const dialog = modalEl.querySelector(".modal-dialog");
  dialog.classList.add("modal-lg");
  modalEl.addEventListener("hidden.bs.modal", () => dialog.classList.remove("modal-lg"), { once: true });

  const myModal = new bootstrap.Modal(modalEl, {
    keyboard: true,
    backdrop: "static",
  });
  myModal.show();
};

// Fetch a patient's consultations (newest first). Throws if the server refuses or fails.
export const fetchHistory = async (patientId) => {
  const res = await axios.get(`${sessionStorage.baseAPIUrl}/patients.php`, {
    params: { operation: "getPatientMedicalHistory", json: JSON.stringify({ patientId, actingUserId: actingUserId() }) },
  });
  if (!Array.isArray(res.data)) throw new Error(res.data?.error || "bad response");
  return res.data;
};

// Draw a list of consultations (from fetchHistory) into a pane.
export const renderHistory = (pane, list, emptyText = "No consultation records found for this patient.") => {
  if (list.length === 0) {
    pane.innerHTML = `<div class="text-center text-muted py-4">${esc(emptyText)}</div>`;
    return;
  }
  pane.innerHTML = `
    <div class="text-muted mb-2" style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;">
      ${list.length} Consultation${list.length > 1 ? "s" : ""} on Record · newest first
    </div>
    <div style="max-height:55vh;overflow-y:auto;" class="pe-1">${historyTableHtml(list)}</div>`;
  wireHistoryTable(pane);
};

// Fetch + draw. opts.excludeConsultationId leaves out the consultation being viewed;
// opts.previousOnly words the empty state for "previous visits". Returns the list shown.
export const loadHistoryTab = async (patientId, pane, opts = {}) => {
  try {
    let list = await fetchHistory(patientId);
    if (opts.excludeConsultationId) list = list.filter((c) => String(c.ConsultationID) !== String(opts.excludeConsultationId));
    if (list.length === 0 && !opts.previousOnly) {
      const get = (operation) =>
        axios.get(`${sessionStorage.baseAPIUrl}/patients.php`, {
          params: { operation, json: JSON.stringify({ patientId, actingUserId: actingUserId() }) },
        });
      pane.innerHTML = await noConsultationsHtml(get);
      return list;
    }
    renderHistory(pane, list, opts.previousOnly ? "No previous consultations. This is the patient's first visit." : undefined);
    return list;
  } catch (err) {
    console.error("Could not load medical history:", err);
    pane.innerHTML = `<div class="text-center text-muted py-4">Could not load the medical history.</div>`;
    return [];
  }
};

const noConsultationsHtml = async (get) => {
  let appts = [];
  try {
    const r = await get("getPatientAppointments");
    if (Array.isArray(r.data)) appts = r.data;
  } catch (e) { /* fall through to the plain message */ }
  if (appts.length === 0) return `<div class="text-center text-muted py-4">No consultation records found for this patient.</div>`;
  return `
    <div class="text-muted mb-2">No consultation records yet. Queuing on record:</div>
    <table class="table table-sm" style="font-size:.82rem;">
      <thead><tr><th>Date</th><th>Time</th><th>Doctor</th><th>Reason</th><th>Status</th></tr></thead>
      <tbody>${appts.map((a) => `<tr><td>${esc(a.AppointmentDate)}</td><td>${esc(a.AppointmentTime)}</td><td>${esc(a.DoctorName)}</td><td>${esc(a.Reason ?? "—")}</td><td>${esc(a.Status)}</td></tr>`).join("")}</tbody>
    </table>`;
};

const getPatientDetails = async (patientId) => {
  const params = {
    operation: "getPatient",
    json: JSON.stringify({
      patientId: patientId,
      actingUserId: JSON.parse(sessionStorage.getItem("currentUser") || "null")?.UserID,
    }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/patients.php`, {
    params: params,
  });
  return response.data;
};
