// Doctor day load: "7 of 20 patients booked" + the doctor's queue for that day.
// Shared by the staff/admin Appointments page and the patient "My Appointments" page.
//   DoctorLoad.load(box, { baseApiUrl, userId, date, actingUserId, showNames, canAct, onChange }) -> the data (or null)
//   canAct   : show the Skip / Requeue buttons (doctor, staff, admin - only on TODAY's queue)
//   onChange : called after a Skip / Requeue so the page can refresh its other lists
(function () {
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmtTime = (t) => {
    if (!t) return "";
    const [h, m] = t.split(":");
    return `${Number(h) % 12 || 12}:${m} ${Number(h) >= 12 ? "PM" : "AM"}`;
  };
  const prettyDate = (d) => new Date(`${d}T00:00:00`).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });

  // green = plenty of room, amber = last ~20% of slots, red = full
  const level = (d) => (d.full ? "danger" : d.remaining <= Math.max(1, Math.ceil(d.limit * 0.2)) ? "warning" : "success");

  const render = (box, d, showNames, opts) => {
    const lv = level(d);
    const pct = Math.min(100, Math.round((d.booked / d.limit) * 100));
    const label = d.full ? "Fully booked" : d.remaining === 1 ? "1 slot left" : `${d.remaining} slots left`;
    const mine = d.queue.find((q) => q.mine);

    // Skip / Requeue only make sense on today's line, and only for staff/doctor
    const act = !!opts.canAct && showNames && d.date === d.today;
    const lastWaiting = [...d.queue].reverse().find((q) => q.status === "Scheduled");
    const cols = 4 + (showNames ? 1 : 0) + (act ? 1 : 0);

    const rows = d.queue.length
      ? d.queue.map((q) => `
          <tr class="${q.mine ? "table-primary" : ""}">
            <td><span class="badge bg-primary-subtle text-primary-emphasis">#${q.position}</span></td>
            <td class="text-nowrap">${esc(fmtTime(q.time))}</td>
            <td>${showNames ? esc(q.patientName) : q.mine ? "<strong>You</strong>" : "<span class=\"text-muted\">Booked</span>"}</td>
            ${showNames ? `<td>${esc(q.reason ?? "—")}</td>` : ""}
            <td>
              <span class="badge ${q.status === "Completed" ? "bg-success" : "bg-warning text-dark"}">${esc(q.status)}</span>
              ${q.status === "Scheduled" && q.moved ? `<span class="badge bg-info-subtle text-info-emphasis" title="Sent to the back of the line">${q.skips > 0 ? `Skipped${q.skips > 1 ? " ×" + q.skips : ""}` : "Requeued"}</span>` : ""}
            </td>
            ${act ? `<td class="text-end text-nowrap">${
              q.status === "Scheduled" && lastWaiting && q.appointmentId !== lastWaiting.appointmentId
                ? `<button type="button" class="btn btn-sm btn-outline-secondary" data-q-act="skip" data-id="${q.appointmentId}" data-name="${esc(q.patientName)}" title="Not here right now: send to the back of the line (keeps the slot)">Requeue</button>`
                : ""}</td>` : ""}
          </tr>`).join("")
      : `<tr><td colspan="${cols}" class="text-muted text-center">No patients booked yet for this day.</td></tr>`;

    // No-Show patients who came back: put them at the end of the line again
    const noShows = act && d.noShows && d.noShows.length ? `
      <div class="mt-3">
        <div class="small fw-semibold mb-1">Did not show (No-Show)</div>
        <table class="table table-sm mb-0">
          <tbody>${d.noShows.map((n) => `
            <tr>
              <td class="text-nowrap">${esc(fmtTime(n.time))}</td>
              <td>${esc(n.patientName)}</td>
              <td>${esc(n.reason ?? "—")}</td>
              <td class="text-end text-nowrap"><button type="button" class="btn btn-sm btn-outline-primary" data-q-act="requeue" data-id="${n.appointmentId}" data-name="${esc(n.patientName)}" title="The patient is here after all: put them back at the end of the line">Requeue</button></td>
            </tr>`).join("")}
          </tbody>
        </table>
      </div>` : "";

    box.innerHTML = `
      <div class="d-flex flex-wrap justify-content-between align-items-center mb-2">
        <div>
          <h6 class="mb-0">Dr. ${esc(d.doctorName)} — ${esc(prettyDate(d.date))}</h6>
          <small class="text-muted">Daily limit: ${d.limit} patients</small>
        </div>
        <span class="badge bg-${lv} ${lv === "warning" ? "text-dark" : ""} fs-6">${label}</span>
      </div>
      <div class="progress mb-1" style="height: 14px" role="progressbar" aria-valuenow="${d.booked}" aria-valuemin="0" aria-valuemax="${d.limit}">
        <div class="progress-bar bg-${lv}" style="width: ${pct}%"></div>
      </div>
      <div class="small mb-2">${d.booked} of ${d.limit} patients booked${mine ? ` · <strong>you are #${mine.position} in line</strong>` : ""}</div>
      ${d.full ? `<div class="alert alert-danger py-1 px-2 small mb-2">This doctor has reached the daily limit. Please pick another day or another doctor.</div>` : ""}
      <div class="table-responsive" style="max-height: 240px; overflow-y: auto;">
        <table class="table table-sm table-hover mb-0">
          <thead><tr><th>QUEUE</th><th>TIME</th><th>PATIENT</th>${showNames ? "<th>REASON</th>" : ""}<th>STATUS</th>${act ? "<th></th>" : ""}</tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      ${noShows}`;
  };

  // Skip / Requeue buttons (one click handler per panel, re-used after every re-render)
  const wireActions = (box, opts) => {
    box._qOpts = opts;
    if (box._qWired) return;
    box._qWired = true;
    box.addEventListener("click", async (e) => {
      const btn = e.target.closest("[data-q-act]");
      if (!btn || btn.disabled) return;
      const o = box._qOpts, kind = btn.dataset.qAct, name = btn.dataset.name;
      const ask = kind === "skip"
        ? `Requeue ${name}? They keep their slot but go to the back of today's line, and the next patient comes up.`
        : `Requeue ${name}? They go back to Scheduled at the end of today's line.`;
      const ok = window.showConfirm ? await window.showConfirm(ask, { confirmText: "Requeue" }) : window.confirm(ask);
      if (!ok) return;

      btn.disabled = true;
      try {
        const fd = new FormData();
        fd.append("operation", kind === "skip" ? "skipAppointment" : "requeueAppointment");
        fd.append("json", JSON.stringify({ actingUserId: o.actingUserId, appointmentId: Number(btn.dataset.id) }));
        const r = await axios({ url: `${o.baseApiUrl}/appointments.php`, method: "POST", data: fd });
        if (r.data != 1) {
          btn.disabled = false;
          alert(r.data?.message || (kind === "skip" ? "Could not skip this patient." : "Could not requeue this patient."));
          return;
        }
      } catch {
        btn.disabled = false;
        alert("Could not reach the server. Please try again.");
        return;
      }
      if (typeof o.onChange === "function") o.onChange(); else load(box, o);
    });
  };

  const load = async (box, opts) => {
    const { baseApiUrl, userId, date, actingUserId, showNames } = opts;
    if (!box) return null;
    if (!userId || !date) { box.classList.add("d-none"); return null; }
    box.classList.remove("d-none");
    try {
      const res = await axios.get(`${baseApiUrl}/appointments.php`, {
        params: { operation: "getDoctorDayLoad", json: JSON.stringify({ userId, date, actingUserId }) },
      });
      const d = res.data;
      if (!d || d.error) {
        box.innerHTML = `<div class="text-muted small">${esc(d?.message || "Could not load the doctor's schedule.")}</div>`;
        return null;
      }
      render(box, d, showNames, opts);
      wireActions(box, opts);
      return d;
    } catch (e) {
      box.innerHTML = `<div class="text-muted small">Could not load the doctor's schedule.</div>`;
      return null;
    }
  };

  window.DoctorLoad = { load };
})();
