// Printable clinical documents for ONE consultation:
//   print-record.html?type=prescription&id=<ConsultationID>          Prescription
//   print-record.html?type=medical-certificate&id=<ConsultationID>   Medical Certificate
// Only these two documents can be printed. Each type is its own document. Plain text only (no icons or emoji) so it prints professionally.
const baseApiUrl = "http://localhost/patient-record-system/api";

// Printed in the letterhead of every document. Fill in the address / phone to have them printed.
const CLINIC = { name: "Patient Record System", address: "", phone: "" };

const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");

const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const dash = (v) => (v === null || v === undefined || String(v).trim() === "" ? "-" : esc(v));
const fmtDate = (d) => {
  if (!d) return "-";
  const dt = new Date(String(d).slice(0, 10) + "T00:00:00");
  return isNaN(dt) ? esc(d) : dt.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
};
const ageFrom = (dob) => {
  const b = new Date(String(dob).slice(0, 10) + "T00:00:00");
  if (isNaN(b)) return "-";
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  if (now < new Date(now.getFullYear(), b.getMonth(), b.getDate())) age--;
  return `${age} years`;
};

// "Last, First" (how names are stored) -> "First Last" (how a person reads a name in a sentence)
const natural = (n) => {
  const parts = String(n ?? "").split(",").map((x) => x.trim()).filter(Boolean);
  return parts.length === 2 ? `${parts[1]} ${parts[0]}` : String(n ?? "");
};

const TYPES = {
  "prescription": { title: "Prescription",             prefix: "RX",      build: prescription },
  // plain: no patient table (the certificate names the patient in its own sentence)
  "medical-certificate": { title: "Medical Certificate", prefix: "MC", build: medicalCertificate, plain: true, afterRender: wireCertificate },
};

const get = (file, operation, payload) =>
  axios.get(`${baseApiUrl}/${file}`, { params: { operation, json: JSON.stringify(payload) } }).then((r) => r.data);

document.addEventListener("DOMContentLoaded", async () => {
  if (!currentUser) return;
  const root = document.getElementById("doc-root");
  const q = new URLSearchParams(window.location.search);
  const type = TYPES[q.get("type")];
  const id = q.get("id");

  // Patients go back to their medical records; staff go back to the consultation.
  document.getElementById("btn-back").href = currentUser.RoleName === "Patient"
    ? "medical-history.html"
    : id ? `consultation-detail.html?id=${encodeURIComponent(id)}` : "consultations.html";
  if (currentUser.RoleName === "Patient") document.getElementById("btn-back").textContent = "Back to My Records";

  // Go back to exactly where the user came from (same tab and place on the consultation page),
  // instead of reloading the page fresh. If this page was opened directly (new tab, bookmark),
  // there is nothing to go back to, so the link above is followed as usual.
  document.getElementById("btn-back").addEventListener("click", (e) => {
    let cameFromApp = false;
    try { cameFromApp = !!document.referrer && new URL(document.referrer).origin === window.location.origin; } catch (err) {}
    if (cameFromApp && window.history.length > 1) {
      e.preventDefault();
      window.history.back();
    }
  });
  document.getElementById("btn-print").addEventListener("click", () => window.print());

  if (!["Doctor", "Staff", "Admin"].includes(currentUser.RoleName)) return message(root, "Your account can't print documents.");

  if (!type || !id) return message(root, "That document was not found.");

  try {
    const consultation = (await get("consultations.php", "getConsultation", { consultationId: id }))?.[0];
    if (!consultation) return message(root, "That consultation was not found.");

    const patientRes = await get("patients.php", "getPatient", {
      patientId: consultation.PatientID, actingUserId: currentUser.UserID,
    });
    if (patientRes?.error === "forbidden") return message(root, "Your account can't view this document.");
    const patient = patientRes?.[0] || {};

    const body = await type.build(consultation, id, patient);
    if (body === null) return; // build() already showed a message
    const ref = `${type.prefix}-${String(id).padStart(6, "0")}`;
    root.innerHTML = paper(type.title, ref, consultation, patient, body, type.plain);
    if (type.afterRender) type.afterRender(consultation, patient);
    document.title = `${type.title} ${ref}`;
    document.getElementById("btn-print").style.display = "";
  } catch (e) {
    message(root, "Could not load the document. Please check that the server is running.");
  }
});

const message = (root, text) => {
  root.innerHTML = `<div class="doc-paper text-center">${esc(text)}</div>`;
};

// ── Common layout: letterhead, title, patient block, body, footer ────────────
const paper = (title, ref, c, p, body, plain) => {
  const clinicInfo = [CLINIC.address, CLINIC.phone].filter(Boolean).map(esc).join(" | ");
  const sex = p.Gender ? `${esc(p.Gender)}${p.Gender === "Other" && p.GenderDetails ? ` (${esc(p.GenderDetails)})` : ""}` : "-";
  return `
  <div class="doc-paper">
    <div class="doc-head">
      <div class="clinic">${esc(CLINIC.name)}</div>
      ${clinicInfo ? `<div class="clinic-info">${clinicInfo}</div>` : ""}
    </div>
    <div class="doc-title">${esc(title)}</div>
    <div class="doc-ref">Reference No. ${esc(ref)}</div>

    ${plain ? "" : `<table class="info">
      <tr><td class="k">Patient</td><td>${esc(c.PatientName)}</td><td class="k">Date</td><td>${fmtDate(c.ConsultationDate)}</td></tr>
      <tr><td class="k">Age</td><td>${p.DateOfBirth ? ageFrom(p.DateOfBirth) : "-"}</td><td class="k">Sex</td><td>${sex}</td></tr>
      <tr><td class="k">Birth Date</td><td>${fmtDate(p.DateOfBirth)}</td><td class="k">Patient ID</td><td>${dash(c.PatientID)}</td></tr>
      <tr><td class="k">Address</td><td colspan="3">${dash(p.Address)}</td></tr>
    </table>`}

    ${body}

    <div class="doc-foot">Printed on ${fmtDate(new Date().toISOString())}. This document is valid only with the signature of the attending physician.</div>
  </div>`;
};

const physicianSign = (c) => `
  <div class="sign-row">
    <div class="sign-box" style="flex:0 0 55%; margin-left:auto;">
      <div class="line">Dr. ${esc(natural(c.DoctorName))}</div>
      <div class="sub">Attending Physician</div>
      <div class="sub">License No.: ______________________</div>
    </div>
  </div>`;

// ── Prescription ────────────────────────────────────────────────────────────
async function prescription(c, id) {
  const rxs = await get("prescriptions.php", "getPrescriptionsByConsultation", { consultationId: id });
  if (!Array.isArray(rxs) || rxs.length === 0) {
    message(document.getElementById("doc-root"), "No medicines have been prescribed for this consultation.");
    return null;
  }
  return `
    <div class="rx-mark">Rx</div>
    <table class="items">
      <thead><tr><th style="width:5%">No.</th><th style="width:28%">Medicine (Generic Name)</th><th style="width:12%">Form</th><th style="width:15%">Dosage</th><th style="width:15%">Frequency</th><th style="width:12%">Duration</th></tr></thead>
      <tbody>
        ${rxs.map((r, i) => `<tr>
          <td>${i + 1}</td>
          <td><strong>${esc(r.MedicineName)}</strong><br/>${dash(r.GenericName)}${r.Instructions ? `<br/><em>Instructions: ${esc(r.Instructions)}</em>` : ""}</td>
          <td>${dash(r.DosageForm)}</td><td>${dash(r.Dosage)}</td><td>${dash(r.Frequency)}</td><td>${dash(r.Duration)}</td>
        </tr>`).join("")}
      </tbody>
    </table>
    ${physicianSign(c)}`;
}

// ── Medical certificate ─────────────────────────────────────────────────────
// The doctor can add days of rest and remarks on screen (not printed as a form) and choose
// whether the diagnosis appears. The sentence below is rebuilt live as they type.
const PRONOUN = {
  Male:   { subj: "He",  obj: "him", poss: "his" },
  Female: { subj: "She", obj: "her", poss: "her" },
};
const pronouns = (g) => PRONOUN[g] || { subj: "The patient", obj: "the patient", poss: "the patient's" };

async function medicalCertificate(c, id, p) {
  const diagnoses = await get("consultation-diagnosis.php", "getDiagnosesByConsultation", { consultationId: id });
  window.__certDiagnoses = Array.isArray(diagnoses) ? diagnoses : [];
  const hasDx = window.__certDiagnoses.length > 0;
  return `
    <div class="no-print" style="border:1px solid #ced4da;border-radius:6px;padding:.75rem 1rem;margin-bottom:1.25rem;font-family:system-ui,sans-serif;font-size:.85rem;background:#f8f9fa;">
      <div style="font-weight:600;margin-bottom:.5rem;">Certificate details (not printed as a form)</div>
      <div class="row g-2 align-items-end">
        <div class="col-sm-3">
          <label class="form-label mb-1" for="cert-days">Days of rest</label>
          <input type="number" min="0" max="365" class="form-control form-control-sm" id="cert-days" placeholder="Optional" />
        </div>
        <div class="col-sm-9">
          <label class="form-label mb-1" for="cert-remarks">Remarks</label>
          <input type="text" class="form-control form-control-sm" id="cert-remarks" placeholder="Optional, e.g. fit to return to work after the rest period" />
        </div>
        ${hasDx ? `<div class="col-12"><div class="form-check">
          <input class="form-check-input" type="checkbox" id="cert-dx" checked />
          <label class="form-check-label" for="cert-dx">Show diagnosis on the certificate</label>
        </div></div>` : ""}
      </div>
    </div>

    <p style="font-weight:700;margin-top:1.5rem;">TO WHOM IT MAY CONCERN:</p>
    <p id="cert-body" style="text-align:justify;text-indent:2.5rem;"></p>
    <p id="cert-dx-text" style="text-align:justify;text-indent:2.5rem;"></p>
    <p id="cert-rest-text" style="text-align:justify;text-indent:2.5rem;"></p>
    <p id="cert-remarks-text" style="text-align:justify;text-indent:2.5rem;"></p>
    <p style="text-align:justify;text-indent:2.5rem;">This certificate is issued upon the request of the patient for whatever legal purpose it may serve.</p>
    <p>Issued this ${fmtDate(new Date().toISOString())}.</p>
    ${physicianSign(c)}`;
}

function wireCertificate(c, p) {
  const pr = pronouns(p.Gender);
  const name = esc(natural(c.PatientName));
  const age = p.DateOfBirth ? ageFrom(p.DateOfBirth).replace(" years", "-year-old") : "";
  const sex = p.Gender === "Male" ? "male" : p.Gender === "Female" ? "female" : "";
  const who = [age, sex].filter(Boolean).join(" ");
  const reason = c.Reason || c.ChiefComplaint;

  const set = (id, html) => { document.getElementById(id).innerHTML = html; };
  const render = () => {
    set("cert-body",
      `This is to certify that <strong>${name}</strong>${who ? `, ${esc(who)}` : ""}${p.Address ? `, a resident of ${esc(p.Address)}` : ""}, ` +
      `was seen and examined at ${esc(CLINIC.name)} on <strong>${fmtDate(c.ConsultationDate)}</strong>` +
      `${reason ? ` for ${esc(String(reason).replace(/[.\s]+$/, ""))}` : ""}.`);

    const showDx = document.getElementById("cert-dx")?.checked;
    const dx = window.__certDiagnoses || [];
    set("cert-dx-text", showDx && dx.length
      ? `After evaluation, the findings are consistent with <strong>${dx.map((d) => `${esc(d.DiagnosisName)} (${esc(d.ICD10Code)})`).join("; ")}</strong>.`
      : "");

    const days = parseInt(document.getElementById("cert-days").value, 10);
    if (days > 0) {
      const start = new Date(String(c.ConsultationDate).slice(0, 10) + "T00:00:00");
      const end = new Date(start); end.setDate(end.getDate() + days - 1);
      const f = (d) => d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
      set("cert-rest-text",
        `${pr.subj} is advised to rest for <strong>${days} day${days > 1 ? "s" : ""}</strong>` +
        `${days > 1 ? `, from ${f(start)} to ${f(end)}` : `, on ${f(start)}`}.`);
    } else set("cert-rest-text", "");

    const remarks = document.getElementById("cert-remarks").value.trim();
    set("cert-remarks-text", remarks ? `Remarks: ${esc(remarks)}${/[.!?]$/.test(remarks) ? "" : "."}` : "");
  };

  ["cert-days", "cert-remarks", "cert-dx"].forEach((id) => document.getElementById(id)?.addEventListener("input", render));
  document.getElementById("cert-dx")?.addEventListener("change", render);
  render();
}
