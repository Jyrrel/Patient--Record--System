// Shared pagination ("Previous / 1 2 3 / Next") for list pages.
// Plain script (like popup.js): exposes window.Pager.
//
//   const state = { page: 1, size: 10 };
//   const pageRows = Pager.paginate(state, sortedRows);        // rows for the current page
//   Pager.controls(container, state, sortedRows.length, rerender);
(() => {
  const SIZES = [10, 25, 50];

  const paginate = (state, rows) => {
    const pages = Math.max(1, Math.ceil(rows.length / state.size));
    state.page = Math.min(Math.max(1, state.page), pages); // stay valid after filters / refresh
    const start = (state.page - 1) * state.size;
    return rows.slice(start, start + state.size);
  };

  // Page numbers to show: first, last, and the current page with one neighbour each side
  const pageList = (page, pages) => {
    const set = new Set([1, pages, page - 1, page, page + 1]);
    const nums = [...set].filter((n) => n >= 1 && n <= pages).sort((a, b) => a - b);
    const out = [];
    nums.forEach((n, i) => {
      if (i > 0 && n - nums[i - 1] > 1) out.push("…");
      out.push(n);
    });
    return out;
  };

  const controls = (container, state, total, onChange) => {
    if (!container) return;
    if (total === 0) { container.innerHTML = ""; return; }

    const pages = Math.max(1, Math.ceil(total / state.size));
    const from = (state.page - 1) * state.size + 1;
    const to = Math.min(total, state.page * state.size);

    const item = (label, page, { disabled = false, active = false } = {}) => `
      <li class="page-item ${disabled ? "disabled" : ""} ${active ? "active" : ""}">
        <a class="page-link" href="#" data-page="${page}">${label}</a>
      </li>`;

    container.innerHTML = `
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-2">
        <div class="d-flex align-items-center gap-2 small text-muted">
          <span>Showing ${from}–${to} of ${total}</span>
          <select class="form-select form-select-sm w-auto pager-size" aria-label="Rows per page">
            ${SIZES.map((n) => `<option value="${n}" ${n === state.size ? "selected" : ""}>${n} / page</option>`).join("")}
          </select>
        </div>
        <nav aria-label="Pages">
          <ul class="pagination pagination-sm mb-0">
            ${item("Previous", state.page - 1, { disabled: state.page === 1 })}
            ${pageList(state.page, pages).map((n) =>
              n === "…"
                ? `<li class="page-item disabled"><span class="page-link">…</span></li>`
                : item(n, n, { active: n === state.page })).join("")}
            ${item("Next", state.page + 1, { disabled: state.page === pages })}
          </ul>
        </nav>
      </div>`;

    container.querySelectorAll("a.page-link").forEach((a) =>
      a.addEventListener("click", (e) => {
        e.preventDefault();
        if (a.closest(".disabled") || a.closest(".active")) return;
        state.page = Number(a.dataset.page);
        onChange();
      })
    );
    container.querySelector(".pager-size").addEventListener("change", (e) => {
      state.size = Number(e.target.value);
      state.page = 1;
      onChange();
    });
  };

  window.Pager = { paginate, controls };
})();
