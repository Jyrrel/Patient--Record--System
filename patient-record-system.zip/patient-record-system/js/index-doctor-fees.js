import { isAdminRole, esc, postBilling, getBilling, BILLING_ERRORS } from "./modules-billing/common.js?v=20261211";

// Doctor Fees tab on the Billing page (Admin only): each doctor's set consultation fee.
// The fee is copied onto a bill as a professional fee when the bill is created.
const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

let doctors = [];

document.addEventListener("DOMContentLoaded", () => {
  if (!isAdminRole()) return;   // Staff never see the tab (and the API refuses them anyway)
  document.getElementById("billing-tabs").classList.remove("d-none");
  document.getElementById("doctor-fee-show-inactive").addEventListener("change", render);
  load();
});

const load = async () => {
  const data = await getBilling(baseApiUrl, "getDoctorFees");
  if (data?.error) {
    alert(BILLING_ERRORS[data.error] || "ERROR");
    return;
  }
  doctors = Array.isArray(data) ? data : [];
  render();
};

const render = () => {
  const showInactive = document.getElementById("doctor-fee-show-inactive").checked;
  const rows = doctors.filter((d) => showInactive || d.Status === "Active");
  const box = document.getElementById("doctor-fees-table");

  if (rows.length === 0) {
    box.innerHTML = `<p class="text-muted small mb-0">No doctors to show.</p>`;
    return;
  }

  box.innerHTML = `
    <table class="table table-sm table-hover align-middle mb-0">
      <thead><tr><th>Doctor</th><th style="width:170px">Consultation fee (₱)</th><th style="width:1%"></th></tr></thead>
      <tbody>
        ${rows.map((d) => `
          <tr class="${d.Status === "Active" ? "" : "table-secondary"}">
            <td>${esc(d.DoctorName)}${d.Status === "Active" ? "" : ' <span class="badge bg-secondary">Inactive</span>'}</td>
            <td>
              <input type="number" min="0" step="0.01" class="form-control form-control-sm doctor-fee-input"
                     data-orig="${parseFloat(d.FeeAmount) || 0}" value="${(parseFloat(d.FeeAmount) || 0).toFixed(2)}" />
            </td>
            <td><button type="button" class="btn btn-success btn-sm btn-save-doctor-fee" data-id="${esc(d.UserID)}" disabled>Save</button></td>
          </tr>`).join("")}
      </tbody>
    </table>`;

  box.querySelectorAll(".doctor-fee-input").forEach((input) => {
    const btn = input.closest("tr").querySelector(".btn-save-doctor-fee");
    input.addEventListener("input", () => {
      btn.disabled = input.value === "" || (parseFloat(input.value) || 0) === parseFloat(input.dataset.orig);
    });
  });

  box.querySelectorAll(".btn-save-doctor-fee").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const input = btn.closest("tr").querySelector(".doctor-fee-input");
      const n = Number(input.value);
      if (input.value === "" || !isFinite(n) || n < 0 || n > 99999999.99) {
        alert("Please enter a valid amount (0 or more).");
        return;
      }
      const res = await postBilling(baseApiUrl, "updateDoctorFee", { userId: btn.dataset.id, feeAmount: input.value });
      if (res == 1) {
        input.dataset.orig = n;
        input.value = n.toFixed(2);
        btn.disabled = true;
        const row = doctors.find((x) => String(x.UserID) === btn.dataset.id);
        if (row) row.FeeAmount = n.toFixed(2);   // keep toggling "show inactive" from losing the saved value
        btn.textContent = "Saved";
        setTimeout(() => { btn.textContent = "Save"; }, 1200);
      } else {
        alert(BILLING_ERRORS[res?.error] || "ERROR");
      }
    });
  });
};
