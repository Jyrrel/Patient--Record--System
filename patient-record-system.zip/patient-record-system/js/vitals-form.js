// Shared Staff "Vital Signs" modal (opens straight after an appointment is booked).
// Plain script (like popup.js): exposes window.showIntakeModal.
// The doctor sees all of this automatically in the consultation.
//
//   showIntakeModal({ appointmentId, patientName, dateLabel, intake, vitals, onSaved })
//     intake  → { reason } the reason for visit already on the appointment (shown, not asked again)
//     vitals  → existing vital-sign record (edit) or null (record)
//     returns a Promise<boolean> — true if saved, false if cancelled
(() => {
  const API = () => sessionStorage.getItem("baseAPIUrl") || "http://localhost/patient-record-system/api";
  const esc = (t) => String(t ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  const field = (id, label, type, extra, value, placeholder, col = "col-md-6") => `
    <div class="${col}">
      <label class="form-label">${label}</label>
      <input type="${type}" ${extra} class="form-control" id="${id}"
             value="${esc(value)}" placeholder="${placeholder}" />
    </div>`;

  window.showIntakeModal = ({ appointmentId, patientName, dateLabel, intake, vitals, onSaved }) => {
    const hasVitals = !!vitals;
    const v = vitals || {};
    const i = intake || {};
    const isEdit = hasVitals;
    const user = JSON.parse(sessionStorage.getItem("currentUser") ?? "null");

    document.getElementById("intake-modal-shared")?.remove();
    const wrap = document.createElement("div");
    wrap.innerHTML = `
      <div class="modal fade" id="intake-modal-shared" role="dialog">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">${isEdit ? "Edit Vital Signs" : "Record Vital Signs"}</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <p class="text-muted small mb-3">
                Patient: <strong>${esc(patientName)}</strong> &nbsp;|&nbsp;
                Queue: <strong>${esc(dateLabel)}</strong>
                ${i.reason ? `&nbsp;|&nbsp; Reason: <strong>${esc(i.reason)}</strong>` : ""}
              </p>

              <h6 class="mb-2">Vital Signs</h6>
              <div class="row g-3">
                ${field("ik-temperature", "Temperature (°C)", "number", 'step="0.1" min="30" max="45"', v.Temperature, "e.g. 36.8")}
                ${field("ik-blood-pressure", "Blood Pressure (mmHg)", "text", "", v.BloodPressure, "e.g. 120/80")}
                ${field("ik-heart-rate", "Heart Rate (bpm)", "number", 'min="0" max="300"', v.HeartRate, "e.g. 72")}
                ${field("ik-respiratory-rate", "Respiratory Rate (breaths/min)", "number", 'min="0" max="60"', v.RespiratoryRate, "e.g. 16")}
                ${field("ik-oxygen", "O₂ Saturation (%)", "number", 'min="0" max="100"', v.OxygenSaturation, "e.g. 98")}
                ${field("ik-weight", "Weight (kg)", "number", 'step="0.1" min="0" max="500"', v.Weight, "e.g. 65.5", "col-md-3")}
                ${field("ik-height", "Height (cm)", "number", 'step="0.1" min="0" max="300"', v.Height, "e.g. 165.0", "col-md-3")}
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success btn-sm me-2" id="ik-save">
                ${isEdit ? "Save Changes" : "Save Vital Signs"}
              </button>
              <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
            </div>
          </div>
        </div>
      </div>`;
    // Input limits + inline messages (see validators.js)
    Object.entries({
      "ik-temperature": "vitals.temperature", "ik-blood-pressure": "vitals.bloodPressure",
      "ik-heart-rate": "vitals.heartRate", "ik-respiratory-rate": "vitals.respiratoryRate",
      "ik-oxygen": "vitals.oxygenSaturation", "ik-weight": "vitals.weight", "ik-height": "vitals.height",
    }).forEach(([id, key]) => wrap.querySelector("#" + id)?.setAttribute("data-v", key));
    document.body.appendChild(wrap.firstElementChild);

    const el = document.getElementById("intake-modal-shared");
    const modal = new bootstrap.Modal(el, { backdrop: "static" });
    let saved = false;
    const closed = new Promise((resolve) =>
      el.addEventListener("hidden.bs.modal", () => { el.remove(); resolve(saved); }, { once: true })
    );
    modal.show();

    const post = async (url, operation, data) => {
      const fd = new FormData();
      fd.append("operation", operation);
      fd.append("json", JSON.stringify(data));
      return (await axios({ url: `${API()}/${url}`, method: "POST", data: fd })).data;
    };

    document.getElementById("ik-save").addEventListener("click", async () => {
      const val = (id) => document.getElementById(id).value.trim() || null;
      const readings = {
        temperature:      val("ik-temperature"),
        bloodPressure:    val("ik-blood-pressure"),
        heartRate:        val("ik-heart-rate"),
        respiratoryRate:  val("ik-respiratory-rate"),
        oxygenSaturation: val("ik-oxygen"),
        weight:           val("ik-weight"),
        height:           val("ik-height"),
      };
      const hasReadings = Object.values(readings).some((x) => x !== null);

      if (!Validate.ok("vitals", readings)) return;
      if (!hasReadings) { alert("Enter at least one vital sign."); return; }

      const data = { actingUserId: user?.UserID, appointmentId, ...readings };
      if (hasVitals) data.vitalSignId = v.VitalSignID;
      const r = await post("vital-signs.php", hasVitals ? "updateVitalSign" : "insertVitalSign", data);
      if (r != 1) {
        alert(r?.error === "forbidden" ? "Only Staff can record vital signs."
            : r?.error === "validation" && r.message ? r.message
            : "ERROR saving vital signs.");
        return;
      }

      saved = true;
      modal.hide();
      alert("Vital signs saved!");
      if (onSaved) onSaved();
    });

    return closed;
  };
})();
