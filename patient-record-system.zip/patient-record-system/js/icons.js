// icons.js - inline SVG icon set (stroke icons, 24x24, inherit text colour).
// Usage anywhere (HTML or JS template strings):  <i data-icon='calendar'></i>
// Icons are drawn automatically, including markup added to the page later by scripts.
(function () {
  const P = {
    "home": "<path d='M3 11l9-8 9 8'/><path d='M5 10v10h5v-6h4v6h5V10'/>",
    "calendar": "<rect x='3' y='5' width='18' height='16' rx='2'/><path d='M8 3v4M16 3v4M3 10h18'/>",
    "stethoscope": "<path d='M6 3v6a4 4 0 0 0 8 0V3'/><path d='M5 3h2M13 3h2'/><path d='M10 13v3a5 5 0 0 0 10 0v-3'/><circle cx='20' cy='11' r='2'/>",
    "users": "<circle cx='9' cy='8' r='3.5'/><path d='M2.5 20a6.5 6.5 0 0 1 13 0'/><circle cx='17' cy='9' r='2.5'/><path d='M17 14.5a5 5 0 0 1 4.5 5'/>",
    "user": "<circle cx='12' cy='8' r='4'/><path d='M4 21a8 8 0 0 1 16 0'/>",
    "credit-card": "<rect x='2.5' y='5' width='19' height='14' rx='2'/><path d='M2.5 10h19M6 15h4'/>",
    "doctor": "<circle cx='12' cy='7.5' r='3.5'/><path d='M5 21a7 7 0 0 1 14 0'/><path d='M12 14v4M10 16h4'/>",
    "pill": "<rect x='2.5' y='8.5' width='19' height='7' rx='3.5' transform='rotate(-45 12 12)'/><path d='M12 8.5v7' transform='rotate(-45 12 12)'/>",
    "award": "<path d='M2 9l10-5 10 5-10 5z'/><path d='M6 11.5V16c0 1.5 2.7 3 6 3s6-1.5 6-3v-4.5'/><path d='M22 9v6'/>",
    "clipboard": "<rect x='5' y='4' width='14' height='17' rx='2'/><rect x='9' y='2.5' width='6' height='3.5' rx='1'/><path d='M9 11h6M9 15h6'/>",
    "layers": "<path d='M12 3l9 5-9 5-9-5z'/><path d='M3 12.5l9 5 9-5'/><path d='M3 16.5l9 5 9-5'/>",
    "flask": "<path d='M9 3h6M10 3v6L4.5 19a1.5 1.5 0 0 0 1.3 2.2h12.4a1.5 1.5 0 0 0 1.3-2.2L14 9V3'/><path d='M7.5 15h9'/>",
    "key": "<circle cx='8' cy='15' r='4'/><path d='M11 12l9-9M16 7l3 3M14 9l2 2'/>",
    "id-card": "<rect x='2.5' y='5' width='19' height='14' rx='2'/><circle cx='9' cy='11' r='2'/><path d='M5.5 16.5a3.5 3.5 0 0 1 7 0M14.5 10h4M14.5 14h4'/>",
    "folder": "<path d='M3 6.5A1.5 1.5 0 0 1 4.5 5H9l2 2.5h8.5A1.5 1.5 0 0 1 21 9v9.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z'/>",
    "file-text": "<path d='M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z'/><path d='M14 3v5h5M9 13h6M9 17h6'/>",
    "check-circle": "<circle cx='12' cy='12' r='9'/><path d='M8 12.5l2.8 2.8L16 9.5'/>",
    "check": "<path d='M5 12.5l4.5 4.5L19 7.5'/>",
    "alert": "<path d='M12 3.5L2.5 20h19z'/><path d='M12 10v4.5M12 17.5v.01'/>",
    "clock": "<circle cx='12' cy='12' r='9'/><path d='M12 7v5l3.5 2'/>",
    "receipt": "<path d='M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z'/><path d='M9 8h6M9 12h6'/>",
    "banknote": "<rect x='2.5' y='6' width='19' height='12' rx='2'/><circle cx='12' cy='12' r='2.5'/><path d='M6 10v.01M18 14v.01'/>",
    "smartphone": "<rect x='7' y='2.5' width='10' height='19' rx='2'/><path d='M11 18.5h2'/>",
    "landmark": "<path d='M3 9l9-5 9 5z'/><path d='M5 9v9M9.5 9v9M14.5 9v9M19 9v9M3 21h18'/>",
    "thermometer": "<path d='M10 14.5V5a2 2 0 0 1 4 0v9.5a4 4 0 1 1-4 0z'/><path d='M12 9v7'/>",
    "droplet": "<path d='M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z'/>",
    "activity": "<path d='M3 12h4l3-7 4 14 3-7h4'/>",
    "wind": "<path d='M3 8h10a3 3 0 1 0-3-3M3 12h15a3 3 0 1 1-3 3M3 16h7a2.5 2.5 0 1 1-2.5 2.5'/>",
    "scale": "<path d='M12 4v16M6 20h12M5 7h14'/><path d='M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0z'/>",
    "ruler": "<rect x='2.5' y='8' width='19' height='8' rx='1.5'/><path d='M6.5 8v3M10.5 8v4M14.5 8v3M18.5 8v4'/>",
    "printer": "<path d='M7 9V3h10v6'/><rect x='3' y='9' width='18' height='8' rx='2'/><path d='M7 14h10v7H7z'/>",
    "bell": "<path d='M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z'/><path d='M10 21h4'/>",
    "palette": "<path d='M12 3a9 9 0 1 0 0 18c1.4 0 2-1 2-2 0-1.5-1-1.8-1-3 0-1 .8-2 2-2h2.5A3.5 3.5 0 0 0 21 10.5C21 6.4 17 3 12 3z'/><circle cx='7.5' cy='11' r='1'/><circle cx='10' cy='7' r='1'/><circle cx='15' cy='7' r='1'/>",
    "sun": "<circle cx='12' cy='12' r='4'/><path d='M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4'/>",
    "monitor": "<rect x='3' y='4' width='18' height='12' rx='2'/><path d='M8 21h8M12 16v5'/>",
    "moon": "<path d='M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z'/>",
    "arrow-right": "<path d='M4 12h16M14 6l6 6-6 6'/>",
    "arrow-left": "<path d='M20 12H4M10 6l-6 6 6 6'/>",
    "menu": "<path d='M4 7h16M4 12h16M4 17h16'/>",
    "cross-square": "<rect x='3' y='3' width='18' height='18' rx='4'/><path d='M12 8v8M8 12h8'/>",
    "heart": "<path d='M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z'/>",
    "info": "<circle cx='12' cy='12' r='9'/><path d='M12 11v5M12 8v.01'/>",
  };

  const svg = (name) =>
    `<svg class="ico" viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${P[name]}</svg>`;

  const draw = (root) => {
    const nodes = root.querySelectorAll ? root.querySelectorAll("i[data-icon]") : [];
    nodes.forEach((el) => {
      const name = el.getAttribute("data-icon");
      if (!P[name]) return;
      el.insertAdjacentHTML("afterend", svg(name));
      el.remove();
    });
  };

  window.PRSIcons = { svg, draw, names: Object.keys(P) };

  const start = () => {
    draw(document);
    new MutationObserver((muts) => {
      muts.forEach((m) => m.addedNodes.forEach((n) => {
        if (n.nodeType !== 1) return;
        if (n.matches && n.matches("i[data-icon]")) draw({ querySelectorAll: () => [n] });
        else draw(n);
      }));
    }).observe(document.documentElement, { childList: true, subtree: true });
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
