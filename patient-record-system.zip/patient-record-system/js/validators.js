// js/validators.js — shared input validation (plain script, like popup.js).
// GENERATED from the same rule set as api/validation.php, so browser and server agree.
//
//   Validate.check("patient", data, opts) -> first error message, or null when valid
//   Validate.field("patient", "phone", "abc") -> message | null           (single field)
//
// Inputs marked data-v="schema.field" are enhanced automatically (also inside modals that
// are created later): max length, numeric/date limits, digits-only phone, and an inline
// red message when the user leaves an invalid field.
(function () {
  const SCHEMAS = {
 "patient": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "dob": {
   "l": "Date of birth",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 1900
  },
  "gender": {
   "l": "Gender",
   "t": "enum",
   "r": 1,
   "vals": [
    "Male",
    "Female",
    "Other"
   ]
  },
  "genderDetails": {
   "l": "Gender details",
   "t": "text",
   "max": 100,
   "reqIf": [
    "gender",
    "Other"
   ]
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "address": {
   "l": "Address",
   "t": "text",
   "max": 255
  }
 },
 "user_insert": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "username": {
   "l": "Username",
   "t": "username",
   "startLetter": 1,
   "r": 1
  },
  "password": {
   "l": "Password",
   "t": "password",
   "mix": 1,
   "notSameAs": "username",
   "r": 1
  },
  "roleId": {
   "l": "Role",
   "t": "id",
   "r": 1
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "specializationIds": {
   "l": "Specializations",
   "t": "ids"
  }
 },
 "user_update": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "min": 2,
   "max": 100,
   "r": 1
  },
  "username": {
   "l": "Username",
   "t": "username",
   "startLetter": 1,
   "r": 1
  },
  "password": {
   "l": "Password",
   "t": "password",
   "mix": 1,
   "notSameAs": "username"
  },
  "roleId": {
   "l": "Role",
   "t": "id",
   "r": 1
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "specializationIds": {
   "l": "Specializations",
   "t": "ids"
  }
 },
 "login": {
  "username": {
   "l": "Username",
   "t": "text",
   "r": 1,
   "max": 50
  },
  "password": {
   "l": "Password",
   "t": "rawtext",
   "r": 1,
   "max": 255
  }
 },
 "role": {
  "roleName": {
   "l": "Role name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 50,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 255
  }
 },
 "specialization": {
  "name": {
   "l": "Specialization name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 100,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "generic": {
  "genericName": {
   "l": "Generic name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 150,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "medicine": {
  "medicineName": {
   "l": "Medicine name",
   "t": "medname",
   "r": 1,
   "min": 2,
   "max": 150
  },
  "genericId": {
   "l": "Generic",
   "t": "id"
  },
  "dosageForm": {
   "l": "Dosage form",
   "t": "enum",
   "r": 1,
   "vals": [
    "Tablet",
    "Capsule",
    "Syrup",
    "Suspension",
    "Injection",
    "Inhaler",
    "Ointment",
    "Cream",
    "Drops",
    "Other"
   ]
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "diagnosis": {
  "icd10Code": {
   "l": "ICD-10 code",
   "t": "icd10",
   "r": 1
  },
  "name": {
   "l": "Diagnosis name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 200,
   "letters": 1
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "labtest": {
  "testName": {
   "l": "Test name",
   "t": "title",
   "r": 1,
   "min": 2,
   "max": 150,
   "letters": 1
  },
  "normalRange": {
   "l": "Normal range",
   "t": "title",
   "max": 100
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 1000
  }
 },
 "appointment": {
  "patientId": {
   "l": "Patient",
   "t": "id",
   "r": 1
  },
  "userId": {
   "l": "Doctor",
   "t": "id",
   "r": 1
  },
  "appointmentAt": {
   "l": "Queue date",
   "t": "datetime",
   "r": 1,
   "np": 1
  },
  "reason": {
   "l": "Reason",
   "t": "text",
   "max": 255
  },
  "notes": {
   "l": "Notes",
   "t": "text",
   "max": 1000
  },
  "status": {
   "l": "Status",
   "t": "enum",
   "vals": [
    "Scheduled",
    "Completed",
    "Cancelled",
    "No-Show"
   ]
  }
 },
 "intake": {
  "reason": {
   "l": "Reason for visit",
   "t": "text",
   "max": 255
  },
  "chiefComplaint": {
   "l": "Chief complaint",
   "t": "text",
   "r": 1,
   "max": 1000
  },
  "symptoms": {
   "l": "Symptoms",
   "t": "text",
   "max": 1000
  }
 },
 "vitals": {
  "temperature": {
   "l": "Temperature",
   "t": "num",
   "min": 30,
   "max": 45,
   "dp": 1,
   "unit": "°C"
  },
  "bloodPressure": {
   "l": "Blood pressure",
   "t": "bp"
  },
  "heartRate": {
   "l": "Heart rate",
   "t": "int",
   "min": 20,
   "max": 300,
   "unit": "bpm"
  },
  "respiratoryRate": {
   "l": "Respiratory rate",
   "t": "int",
   "min": 4,
   "max": 80,
   "unit": "breaths/min"
  },
  "oxygenSaturation": {
   "l": "O₂ saturation",
   "t": "int",
   "min": 50,
   "max": 100,
   "unit": "%"
  },
  "weight": {
   "l": "Weight",
   "t": "num",
   "min": 0.5,
   "max": 500,
   "dp": 2,
   "unit": "kg"
  },
  "height": {
   "l": "Height",
   "t": "num",
   "min": 20,
   "max": 300,
   "dp": 1,
   "unit": "cm"
  }
 },
 "consultation": {
  "consultationDate": {
   "l": "Consultation date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "treatment": {
   "l": "Treatment notes",
   "t": "text",
   "max": 4000
  },
  "notes": {
   "l": "Notes",
   "t": "text",
   "max": 2000
  }
 },
 "prescription": {
  "medicineId": {
   "l": "Medicine",
   "t": "id",
   "r": 1
  },
  "prescriptionDate": {
   "l": "Prescription date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "dosage": {
   "l": "Dosage",
   "t": "text",
   "max": 100
  },
  "frequency": {
   "l": "Frequency",
   "t": "text",
   "max": 100
  },
  "duration": {
   "l": "Duration",
   "t": "text",
   "max": 100
  },
  "instructions": {
   "l": "Instructions",
   "t": "text",
   "max": 1000
  }
 },
 "lab": {
  "testId": {
   "l": "Laboratory test",
   "t": "id",
   "r": 1
  },
  "testDate": {
   "l": "Test date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "result": {
   "l": "Result",
   "t": "text",
   "max": 2000
  },
  "referenceRange": {
   "l": "Reference range",
   "t": "text",
   "max": 100
  }
 },
 "bill": {
  "consultationId": {
   "l": "Consultation",
   "t": "id",
   "r": 1
  },
  "billDate": {
   "l": "Bill date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "status": {
   "l": "Status",
   "t": "enum",
   "vals": [
    "Pending",
    "Paid",
    "Cancelled"
   ]
  }
 },
 "fee": {
  "userId": {
   "l": "Doctor",
   "t": "id",
   "r": 1
  },
  "feeAmount": {
   "l": "Fee amount",
   "t": "money",
   "r": 1,
   "min": 0.01,
   "max": 99999999.99
  },
  "description": {
   "l": "Description",
   "t": "text",
   "max": 255
  }
 },
 "doctor_update": {
  "firstName": {
   "l": "First name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "lastName": {
   "l": "Last name",
   "t": "name",
   "max": 100,
   "r": 1
  },
  "username": {
   "l": "Username",
   "t": "username",
   "r": 1
  },
  "password": {
   "l": "Password",
   "t": "password"
  },
  "phone": {
   "l": "Phone",
   "t": "phone"
  },
  "specializationIds": {
   "l": "Specializations",
   "t": "ids"
  },
  "dailyPatientLimit": {
   "l": "Daily patient limit",
   "t": "int",
   "min": 1,
   "max": 100,
   "unit": "patients"
  }
 },
 "bill_update": {
  "billDate": {
   "l": "Bill date",
   "t": "date",
   "r": 1,
   "nf": 1,
   "my": 2000
  },
  "status": {
   "l": "Status",
   "t": "enum",
   "vals": [
    "Pending",
    "Paid",
    "Cancelled"
   ]
  }
 }
};

  const todayStr = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };

  // Right now as YYYY-MM-DDTHH:MM (browser local time, the format <input type="datetime-local"> uses).
  const nowLocalStr = () => {
    const d = new Date();
    return `${todayStr()}T${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  };

  const range = (def, unit) => {
    const u = unit ? " " + unit : "";
    if (def.min !== undefined && def.max !== undefined) return `between ${def.min} and ${def.max}${u}`;
    if (def.min !== undefined) return `at least ${def.min}${u}`;
    return `at most ${def.max}${u}`;
  };

  // returns an error message or null
  const checkField = (def, raw, data = {}, relax = []) => {
    const l = def.l, t = def.t;
    let required = !!def.r;
    if (!required && def.reqIf) required = String(data[def.reqIf[0]] ?? "") === def.reqIf[1];

    if (t === "ids") {
      const arr = raw == null || raw === "" ? [] : raw;
      if (!Array.isArray(arr)) return `${l} is not valid.`;
      if (arr.some((x) => !/^[0-9]+$/.test(String(x)) || Number(x) < 1)) return `${l} contains an item that is not valid.`;
      if (required && arr.length === 0) return `${l} is required.`;
      return null;
    }

    let v = raw == null ? "" : String(raw);
    if (t !== "password" && t !== "rawtext") v = v.trim();
    if (v === "") return required ? `${l} is required.` : null;

    switch (t) {
      case "name": {
        const max = def.max || 100;
        if ([...v].length > max) return `${l} must be ${max} characters or fewer.`;
        if (def.min && [...v].length < def.min) return `${l} must be at least ${def.min} characters.`;
        if (!/^\p{L}[\p{L}\p{M} .'\-]*$/u.test(v)) return `${l} must contain only letters, spaces, apostrophes, periods and hyphens.`;
        return null;
      }
      case "medname": {
        const max = def.max || 150, min = def.min || 2;
        if ([...v].length > max) return `${l} must be ${max} characters or fewer.`;
        if ([...v].length < min) return `${l} must be at least ${min} characters.`;
        if (!/^\p{L}[\p{L}\p{M} .'\-()\/&,]*$/u.test(v)) return `${l} must contain letters only - no numbers. Spaces and . ' - ( ) / & , are allowed.`;
        return null;
      }
      case "title": case "text": case "rawtext": {
        const max = def.max || 255, min = def.min || 0;
        if ([...v].length > max) return `${l} must be ${max} characters or fewer.`;
        if (min && [...v].length < min) return `${l} must be at least ${min} characters.`;
        if (t === "rawtext") return null;
        if (/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/.test(v)) return `${l} must not contain control characters.`;
        if (/<\s*\/?\s*[a-zA-Z!]/.test(v)) return `${l} must not contain HTML tags.`;
        if (t === "title" && !/[\p{L}\p{N}]/u.test(v)) return `${l} must contain at least one letter or number.`;
        if (def.letters && !/\p{L}/u.test(v)) return `${l} must contain at least one letter (it cannot be numbers only).`;
        return null;
      }
      case "phone":
        return /^[0-9]{7,15}$/.test(v) ? null : `${l} must be 7 to 15 digits only (no spaces, +, - or letters).`;
      case "username":
        if (!/^[A-Za-z0-9_]{3,50}$/.test(v)) return `${l} must be 3 to 50 characters: letters, numbers and underscores only.`;
        if (def.startLetter && !/^[A-Za-z]/.test(v)) return `${l} must start with a letter.`;
        return null;
      case "password":
        if (v.length < 6) return `${l} must be at least 6 characters.`;
        if (v.length > 72) return `${l} must be 72 characters or fewer.`;
        if (v.trim() === "") return `${l} must not be only spaces.`;
        if (def.mix && !(/[A-Za-z]/.test(v) && /[0-9]/.test(v))) return `${l} must include at least one letter and one number.`;
        if (def.notSameAs && String(data[def.notSameAs] ?? "").trim() !== "" &&
            v.toLowerCase() === String(data[def.notSameAs]).trim().toLowerCase()) return `${l} must not be the same as the username.`;
        return null;
      case "id":
        return /^[0-9]+$/.test(v) && Number(v) >= 1 ? null : `${l} is not valid. Please select one.`;
      case "enum":
        return def.vals.includes(v) ? null : `${l} must be one of: ${def.vals.join(", ")}.`;
      case "date": {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        const d = m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null;
        if (!d || d.getFullYear() !== Number(m[1]) || d.getMonth() !== Number(m[2]) - 1 || d.getDate() !== Number(m[3])) return `${l} must be a real date (YYYY-MM-DD).`;
        if (def.my && Number(m[1]) < def.my) return `${l} must not be earlier than the year ${def.my}.`;
        const today = todayStr();
        if (def.nf && v > today) return `${l} must not be in the future.`;
        if (def.np && !relax.includes("notPast") && v < today) return `${l} must not be in the past.`;
        return null;
      }
      case "datetime": {
        // One timestamp (browser datetime-local gives YYYY-MM-DDTHH:MM). Only the DATE is checked for "not in the past" (any time today is fine).
        const m = /^(\d{4})-(\d{2})-(\d{2})[T ]([01][0-9]|2[0-3]):([0-5][0-9])(:[0-5][0-9])?$/.exec(v);
        const d = m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null;
        if (!d || d.getFullYear() !== Number(m[1]) || d.getMonth() !== Number(m[2]) - 1 || d.getDate() !== Number(m[3])) return `${l} must be a valid date and time.`;
        if (def.np && !relax.includes("notPast") && `${m[1]}-${m[2]}-${m[3]}` < todayStr()) return `${l} must not be in the past. Please choose today or a later date.`;
        return null;
      }
      case "time":
        return /^([01][0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$/.test(v) ? null : `${l} must be a valid time (HH:MM).`;
      case "int": {
        if (!/^-?[0-9]+$/.test(v)) return `${l} must be a whole number.`;
        const n = Number(v);
        if ((def.min !== undefined && n < def.min) || (def.max !== undefined && n > def.max)) return `${l} must be ${range(def, def.unit)}.`;
        return null;
      }
      case "num": case "money": {
        const dp = def.dp ?? 2;
        if (!/^-?[0-9]+(\.[0-9]+)?$/.test(v)) return `${l} must be a valid number.`;
        const frac = v.includes(".") ? v.split(".")[1].length : 0;
        if (frac > dp) return `${l} must have at most ${dp} decimal place${dp === 1 ? "" : "s"}.`;
        const n = Number(v);
        if ((def.min !== undefined && n < def.min) || (def.max !== undefined && n > def.max)) return `${l} must be ${range(def, def.unit)}.`;
        return null;
      }
      case "icd10":
        return /^[A-Z][0-9][0-9AB](\.[0-9A-Z]{1,4})?$/.test(v.toUpperCase()) ? null : `${l} must look like J02.9 or U07.1 (a letter, two characters, optionally a dot and up to 4 more).`;
      case "bp": {
        const s = v.replace(/\s+/g, "");
        const m = /^([0-9]{2,3})\/([0-9]{2,3})$/.exec(s);
        if (!m) return `${l} must look like 120/80.`;
        const sys = Number(m[1]), dia = Number(m[2]);
        if (sys < 50 || sys > 260 || dia < 30 || dia > 160) return `${l} is out of range (systolic 50-260, diastolic 30-160).`;
        if (sys <= dia) return `${l} must have a systolic value higher than the diastolic value.`;
        return null;
      }
    }
    return null;
  };

  const Validate = {
    schemas: SCHEMAS,
    todayStr,
    nowLocalStr,
    check(schemaName, data, opts = {}) {
      const schema = SCHEMAS[schemaName] || {};
      for (const [field, def] of Object.entries(schema)) {
        const err = checkField(def, data ? data[field] : null, data || {}, opts.relax || []);
        if (err) return err;
      }
      return null;
    },
    field(schemaName, field, value, data = {}, opts = {}) {
      const def = (SCHEMAS[schemaName] || {})[field];
      return def ? checkField(def, value, data, opts.relax || []) : null;
    },
    // Booking for TODAY at a time that has already passed is not allowed.
    timePassedToday(date, time) {
      if (!date || !time) return null;
      const n = new Date();
      const hhmm = `${String(n.getHours()).padStart(2, "0")}:${String(n.getMinutes()).padStart(2, "0")}`;
      return date === todayStr() && String(time).slice(0, 5) < hhmm
        ? "That time has already passed today. Please choose a later time."
        : null;
    },
    // Check, and show the message in a popup. Returns true when the data is OK.
    ok(schemaName, data, opts) {
      const err = Validate.check(schemaName, data, opts);
      if (err) { window.alert(err); return false; }
      return true;
    },
  };
  window.Validate = Validate;

  // ── Auto-enhance inputs that carry data-v="schema.field" ───────────────────
  const MAXLEN = { phone: 15, username: 50, password: 72, icd10: 10, bp: 9 };

  const enhance = (el) => {
    if (el.dataset.vReady) return;
    const [schema, field] = (el.dataset.v || "").split(".");
    const def = (SCHEMAS[schema] || {})[field];
    if (!def) return;
    el.dataset.vReady = "1";
    const t = def.t;

    if (["name", "medname", "title", "text", "rawtext"].includes(t)) el.maxLength = def.max || 255;
    else if (MAXLEN[t]) el.maxLength = MAXLEN[t];

    if (t === "phone") {
      el.inputMode = "numeric";
      el.addEventListener("input", () => {
        const clean = el.value.replace(/\D+/g, "");
        if (clean !== el.value) el.value = clean;
      });
    }
    if (t === "name" || t === "medname") {
      // Letters only - digits and other symbols are removed as they are typed or pasted.
      const BAD = t === "medname" ? /[^\p{L}\p{M} .'\-()\/&,]+/gu : /[^\p{L}\p{M} .'\-]+/gu;
      el.addEventListener("input", () => {
        const pos = el.selectionStart;
        const before = el.value;
        let clean = before.replace(BAD, "").replace(/^[^\p{L}]+/u, "");
        if (clean !== before) {
          const removed = before.slice(0, pos ?? before.length).length - before.slice(0, pos ?? before.length).replace(BAD, "").length;
          el.value = clean;
          try { const p = Math.max(0, (pos ?? clean.length) - removed); el.setSelectionRange(p, p); } catch (e) {}
        }
      });
    }
    if (t === "icd10") el.addEventListener("input", () => { el.value = el.value.toUpperCase(); });
    if (t === "int" || t === "num" || t === "money") {
      if (el.type === "number") {
        if (def.min !== undefined) el.min = def.min;
        if (def.max !== undefined) el.max = def.max;
        const dp = t === "int" ? 0 : def.dp ?? 2;
        el.step = dp === 0 ? "1" : String(Math.pow(10, -dp));
        el.addEventListener("keydown", (e) => { if (e.key === "e" || e.key === "E" || e.key === "+") e.preventDefault(); });
      }
    }
    if (t === "datetime" && def.np) el.min = `${todayStr()}T00:00`;
    if (t === "date") {
      if (def.nf) el.max = todayStr();
      if (def.np) el.min = todayStr();
      if (def.my) el.min = `${def.my}-01-01`;
    }

    const show = (msg) => {
      let box = el.parentElement.querySelector(`:scope > .v-msg[data-for="${el.id}"]`);
      if (msg) {
        el.classList.add("is-invalid");
        if (!box) {
          box = document.createElement("div");
          box.className = "invalid-feedback d-block v-msg";
          box.dataset.for = el.id;
          el.insertAdjacentElement("afterend", box);
        }
        box.textContent = msg;
      } else {
        el.classList.remove("is-invalid");
        box?.remove();
      }
    };
    const run = () => {
      // An existing value that has not been changed (e.g. an old appointment date) is never flagged.
      const relax = el.dataset.vOriginal !== undefined && el.value === el.dataset.vOriginal ? ["notPast"] : [];
      show(checkField(def, el.value, {}, relax));
    };
    el.addEventListener("blur", run);
    el.addEventListener("change", run);
    el.addEventListener("input", () => { if (el.classList.contains("is-invalid")) run(); });
  };

  const scan = (root) => {
    if (root.nodeType !== 1) return;
    if (root.matches?.("[data-v]")) enhance(root);
    root.querySelectorAll?.("[data-v]").forEach(enhance);
  };
  const start = () => {
    scan(document.body);
    new MutationObserver((muts) => muts.forEach((m) => m.addedNodes.forEach(scan))).observe(document.body, { childList: true, subtree: true });
  };
  if (document.body) start(); else document.addEventListener("DOMContentLoaded", start);

  // ── Server-side validation messages ────────────────────────────────────────
  // The API answers { error: "validation", message } when a value is rejected. Show that message
  // once, and swallow the generic "ERROR" popup that most handlers raise right after.
  if (window.axios && typeof window.showAlert === "function") {
    axios.interceptors.response.use((res) => {
      const d = res && res.data;
      if (d && typeof d === "object" && d.error === "validation" && d.message) {
        window.__validationShownAt = Date.now();
        window.alert(d.message);
      }
      return res;
    });
    const baseAlert = window.alert;
    window.alert = function (msg) {
      if (/^ERROR\b/.test(String(msg)) && Date.now() - (window.__validationShownAt || 0) < 2500) return;
      return baseAlert.apply(this, arguments);
    };
  }
})();
