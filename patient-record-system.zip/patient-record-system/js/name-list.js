// js/name-list.js — turns a finished list table into a "names only" table.
//
// Only the name column stays visible. Clicking a name opens a popup with every other column's
// information, and the row's action buttons (View / Edit / Cancel / ...) move into the popup
// footer. The original buttons stay in the (hidden) row, so each popup button simply clicks the
// real one and all existing handlers keep working untouched.
//
// Usage (after thead and tbody are built):
//   NameList.apply(table, { nameHeader: "PATIENT" });   // find the column by its header text
//   NameList.apply(table, { nameCols: [4] });           // or by index (first one is the link)
window.NameList = (() => {
  const esc = (v) =>
    String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  let modalEl = null;
  let modal = null;

  const ensureModal = () => {
    if (modalEl) return;
    modalEl = document.createElement("div");
    modalEl.className = "modal fade";
    modalEl.id = "name-list-modal";
    modalEl.setAttribute("tabindex", "-1");
    modalEl.innerHTML = `
      <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="name-list-title">Details</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body" id="name-list-body"></div>
          <div class="modal-footer" id="name-list-footer"></div>
        </div>
      </div>`;
    document.body.appendChild(modalEl);
    modal = new bootstrap.Modal(modalEl);
  };

  const open = (tr, labels, nameCols, opts) => {
    ensureModal();
    const cells = [...tr.children];

    document.getElementById("name-list-title").textContent =
      nameCols.map((i) => cells[i]?.textContent.trim()).filter(Boolean).join(", ") || opts.title || "Details";

    // Every other column as "label: value" (action buttons are taken out of the values)
    const rows = [];
    cells.forEach((td, i) => {
      if (nameCols.includes(i)) return;
      const copy = td.cloneNode(true);
      copy.querySelectorAll(".btn, button").forEach((b) => b.remove());
      const html = copy.innerHTML.trim();
      if (!html && !copy.textContent.trim()) return;
      rows.push(`<tr><td class="text-muted text-nowrap pe-3">${esc(labels[i] || "")}</td><td>${html}</td></tr>`);
    });
    document.getElementById("name-list-body").innerHTML =
      `<table class="table table-sm mb-0"><tbody>${rows.join("")}</tbody></table>`;

    // Footer buttons: one clear main action (solid), the other actions outlined, the destructive one
    // (Cancel / Deactivate / Delete) last in red, and Close on the far right. Each proxy still clicks
    // the real button in the hidden row, so every existing handler keeps working.
    const footer = document.getElementById("name-list-footer");
    footer.innerHTML = `<div class="d-flex flex-wrap gap-2 me-auto" id="name-list-actions"></div>
      <button type="button" class="btn btn-light border btn-sm px-3" data-bs-dismiss="modal">Close</button>`;
    const actions = footer.querySelector("#name-list-actions");

    const hide = opts.hideButtons || [];
    const origs = [...tr.querySelectorAll("button, a.btn")].filter((b) => !hide.some((sel) => b.matches(sel)));
    const isDanger = (b) => /\bbtn-(outline-)?danger\b/.test(b.className);
    const ordered = [...origs.filter((b) => !isDanger(b)), ...origs.filter(isDanger)];
    const outline = (cls) => cls.replace(/\bbtn-(primary|secondary|success|danger|warning|info)\b/g, "btn-outline-$1");

    let mainUsed = false;
    ordered.forEach((orig) => {
      const proxy = document.createElement("button");
      proxy.type = "button";
      const danger = isDanger(orig);
      const solid = !danger && !mainUsed && !/\bbtn-outline-/.test(orig.className);
      if (solid) mainUsed = true;
      proxy.className = ("btn btn-sm px-3 " + (solid ? orig.className : outline(orig.className)))
        .replace(/\b(me|ms)-\d\b/g, "").replace(/\s+/g, " ").trim();
      proxy.innerHTML = orig.innerHTML;
      if (orig.title) proxy.title = orig.title;
      if (orig.disabled || orig.classList.contains("disabled")) proxy.disabled = true;
      proxy.addEventListener("click", () => {
        // Close this popup first so the real action can open its own popup / confirm
        modalEl.addEventListener("hidden.bs.modal", () => orig.click(), { once: true });
        modal.hide();
      });
      actions.appendChild(proxy);
    });

    modal.show();
  };

  const apply = (table, opts = {}) => {
    const heads = [...table.querySelectorAll("thead th")];
    const labels = heads.map((h) => h.textContent.trim());
    let nameCols = opts.nameCols;
    if (!nameCols && opts.nameHeader) {
      const i = labels.findIndex((l) => l.toUpperCase() === opts.nameHeader.toUpperCase());
      if (i >= 0) nameCols = [i];
    }
    nameCols = nameCols ?? [0];
    const keep = new Set(nameCols);

    heads.forEach((th, i) => { if (!keep.has(i)) th.style.display = "none"; });

    table.querySelectorAll("tbody tr").forEach((tr) => {
      const tds = [...tr.children];
      if (tds.length !== heads.length) return;   // e.g. a single "no records" row
      tds.forEach((td, i) => { if (!keep.has(i)) td.style.display = "none"; });

      const cell = tds[nameCols[0]];
      const link = document.createElement("a");
      link.href = "#";
      link.className = "name-link fw-semibold text-decoration-none";
      link.innerHTML = cell.innerHTML;
      cell.innerHTML = "";
      cell.appendChild(link);
      link.addEventListener("click", (e) => {
        e.preventDefault();
        open(tr, labels, nameCols, opts);
      });
    });
  };

  return { apply };
})();
