import { historyTableHtml, wireHistoryTable, sortNewestFirst, visitNumbers } from "./history-table.js?v=20261223";
const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

// Staff open this page from Patients > View with ?patientId=3.
// A Patient login always sees ONLY their own record: the URL value is ignored for them
// (and the server also refuses any other patient for a Patient account).
const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");
const isPatientUser = currentUser?.RoleName === "Patient";
const params    = new URLSearchParams(window.location.search);
const patientId = isPatientUser ? currentUser.PatientID : params.get("patientId");
const actingUserId = currentUser?.UserID;

const accessDenied = () => {
  document.getElementById("history-loading").style.display = "none";
  const box = document.getElementById("history-empty");
  box.textContent = "You don't have access to this record.";
  box.style.display = "block";
};

document.addEventListener("DOMContentLoaded", async () => {
  if (isPatientUser) {
    document.getElementById("back-link")?.remove();
    document.getElementById("history-heading").textContent = "My Medical Records";
  }
  if (!patientId) {
    document.getElementById("history-loading").style.display = "none";
    document.getElementById("history-empty").style.display   = "block";
    document.getElementById("history-empty").textContent     = "No patient specified.";
    return;
  }
  try {
    await loadPatientInfo();
  } catch (err) {
    if (err.message === "forbidden") return;
    console.error("Could not load patient info:", err);
  }
  await loadMedicalHistory();
});

// ── Patient info ────────────────────────────────────────────────────────────
const loadPatientInfo = async () => {
  const res = await axios.get(`${baseApiUrl}/patients.php`, {
    params: { operation: "getPatient", json: JSON.stringify({ patientId, actingUserId }) },
  });
  if (res.data?.error === "forbidden") { accessDenied(); throw new Error("forbidden"); }
  if (!res.data || res.data.length === 0) return;
  const p = res.data[0];

  document.getElementById("history-heading").textContent  = isPatientUser
    ? "My Medical Records"
    : `${p.LastName}, ${p.FirstName} — Medical History`;
  document.getElementById("history-subtext").textContent  = `Patient ID #${p.PatientID} · ${p.Gender} · DOB: ${p.DateOfBirth}`;

  const card = document.getElementById("patient-info-card");
  card.style.display = "block";
  document.getElementById("patient-info-body").innerHTML = `
    <div class="row g-2" style="font-size:.875rem;">
      <div class="col-sm-4"><span class="text-muted">Full Name</span><br/><strong>${p.LastName}, ${p.FirstName}</strong></div>
      <div class="col-sm-2"><span class="text-muted">Gender</span><br/><strong>${p.Gender}</strong></div>
      <div class="col-sm-3"><span class="text-muted">Date of Birth</span><br/><strong>${p.DateOfBirth}</strong></div>
      <div class="col-sm-3"><span class="text-muted">Phone</span><br/><strong>${p.Phone ?? "—"}</strong></div>
      <div class="col-12"><span class="text-muted">Address</span><br/><strong>${p.Address ?? "—"}</strong></div>
    </div>
  `;
};

// ── Empty / error states ─────────────────────────────────────────────────────
const showEmptyBox = (html) => {
  const box = document.getElementById("history-empty");
  box.innerHTML = html;
  box.style.display = "block";
};

// When a patient has no consultations yet, still show the appointments on
// record so the page is never just blank.
const showNoConsultations = async () => {
  let appointments = [];
  try {
    const res = await axios.get(`${baseApiUrl}/patients.php`, {
      params: { operation: "getPatientAppointments", json: JSON.stringify({ patientId, actingUserId }) },
    });
    if (Array.isArray(res.data)) appointments = res.data;
  } catch (err) {
    console.error("Could not load queue entries:", err);
  }

  if (appointments.length === 0) {
    showEmptyBox("No consultation records found for this patient.");
    return;
  }

  showEmptyBox(`
    <div class="mb-3">No consultation records found for this patient yet.</div>
    <div class="text-start">
      <div class="text-muted mb-1" style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;"><i data-icon='calendar'></i> Queuing on Record</div>
      <table class="table table-sm mb-0" style="font-size:.85rem;">
        <thead><tr><th>Date</th><th>Time</th><th>Doctor</th><th>Reason</th><th>Status</th></tr></thead>
        <tbody>
          ${appointments.map(a => `
            <tr>
              <td>${a.AppointmentDate}</td>
              <td>${a.AppointmentTime}</td>
              <td>${a.DoctorName}</td>
              <td>${a.Reason ?? "—"}</td>
              <td><span class="badge bg-secondary">${a.Status}</span></td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>
  `);
};

// ── Medical History timeline ─────────────────────────────────────────────────
const loadMedicalHistory = async () => {
  let history;
  try {
    const res = await axios.get(`${baseApiUrl}/patients.php`, {
      params: { operation: "getPatientMedicalHistory", json: JSON.stringify({ patientId, actingUserId }) },
    });
    history = res.data;
  } catch (err) {
    console.error("Could not load medical history:", err);
    document.getElementById("history-loading").style.display = "none";
    showEmptyBox("Could not load the medical history. Please check that the server and database are running.");
    return;
  }

  document.getElementById("history-loading").style.display = "none";

  // The API returns a JSON array. Anything else (e.g. a PHP warning/error
  // printed before the JSON) means the request did not work.
  if (!Array.isArray(history)) {
    console.error("Unexpected medical history response:", history);
    showEmptyBox("Could not load the medical history (unexpected response from the server).");
    return;
  }

  if (history.length === 0) {
    await showNoConsultations();
    return;
  }

  // Newest first (descending) - consultation date, then appointment date/time, then ID.
  history = sortNewestFirst(history);

  document.getElementById("history-search-wrap").style.display = "block";
  document.getElementById("history-search").addEventListener("input", () => renderHistory(history));
  renderHistory(history);
};

const renderHistory = (history) => {
  const term = document.getElementById("history-search").value.trim().toLowerCase();
  const matches = (con) => !term || JSON.stringify(Object.values(con)).toLowerCase().includes(term);

  const timeline = document.getElementById("history-timeline");
  const shown = history.filter(matches);
  const label = `${term ? `${shown.length} of ${history.length}` : history.length} Consultation${history.length > 1 ? "s" : ""} ${term ? "match" : "on Record"} · newest first`;
  const header = `
    <div class="d-flex align-items-center gap-2 mb-3">
      <span style="font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--text-muted);">${label}</span>
    </div>`;
  if (shown.length === 0) {
    timeline.innerHTML = header + `<div class="form-card text-center text-muted py-4">No records match "${term.replace(/</g, "&lt;")}".</div>`;
    return;
  }
  // Visit numbers are worked out on the full list so they stay the same while searching.
  timeline.innerHTML = header + `<div class="section-card p-2">${historyTableHtml(shown, visitNumbers(history))}</div>`;
  wireHistoryTable(timeline);
};
