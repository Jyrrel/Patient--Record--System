// theme.js — appearance settings for every page (including login).
//   Mode : Light / Auto (follows the device) / Dark
//   Accent: Green (default) / Blue / Teal / Purple / Slate
//   Text size: Normal / Large
// Saved in this browser's localStorage, so the choice survives page changes and logins.
// Loaded as a plain (non-module) <script> in <head> so the saved theme is applied
// BEFORE the page paints — no white flash on dark mode.
// Status colours (Paid / Pending / Cancelled …) are deliberately NOT affected by the accent.
(function () {
  const KEY = "prs-theme";
  const MODES = ["light", "auto", "dark"];
  const ACCENTS = { blue: "#1d4f91", slate: "#334155", teal: "#0f6b63", green: "#1f6b43", purple: "#5b3fa8" };
  const SIZES = ["normal", "large"];
  const DEFAULTS = { mode: "auto", accent: "blue", size: "normal" };

  const media = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;

  const load = () => {
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { /* private mode etc. */ }
    return {
      mode:   MODES.includes(saved.mode) ? saved.mode : DEFAULTS.mode,
      accent: saved.accent in ACCENTS ? saved.accent : DEFAULTS.accent,
      size:   SIZES.includes(saved.size) ? saved.size : DEFAULTS.size,
    };
  };
  const save = (p) => { try { localStorage.setItem(KEY, JSON.stringify(p)); } catch (e) { /* ignore */ } };

  let prefs = load();
  const resolvedMode = () => (prefs.mode === "auto" ? (media && media.matches ? "dark" : "light") : prefs.mode);

  const apply = (notify) => {
    const root = document.documentElement;
    root.setAttribute("data-bs-theme", resolvedMode());
    root.setAttribute("data-accent", prefs.accent);
    root.setAttribute("data-size", prefs.size);
    if (notify) document.dispatchEvent(new CustomEvent("prs-theme-change", { detail: { ...prefs, resolved: resolvedMode() } }));
  };

  apply(false); // runs immediately, before first paint

  if (media) {
    const onSystemChange = () => { if (prefs.mode === "auto") apply(true); };
    media.addEventListener ? media.addEventListener("change", onSystemChange) : media.addListener(onSystemChange);
  }

  // ── Picker UI ─────────────────────────────────────────────────────────────
  const seg = (group, items) =>
    `<div class="theme-seg" data-group="${group}">` +
    items.map(([value, label]) => `<button type="button" data-value="${value}" aria-pressed="false">${label}</button>`).join("") +
    `</div>`;

  const build = () => {
    const wrap = document.createElement("div");
    wrap.className = "theme-menu";
    wrap.innerHTML = `
      <button type="button" class="theme-btn" aria-label="Appearance settings" aria-haspopup="dialog"
              aria-expanded="false" title="Appearance"><i data-icon='palette'></i></button>
      <div class="theme-panel" role="dialog" aria-label="Appearance settings" hidden>
        <div class="tp-group"><h6>Mode</h6>
          ${seg("mode", [["light", "<i data-icon='sun'></i> Light"], ["auto", "<i data-icon='monitor'></i> Auto"], ["dark", "<i data-icon='moon'></i> Dark"]])}
        </div>
        <div class="tp-group"><h6>Accent color</h6>
          <div class="theme-swatches" data-group="accent">
            ${Object.entries(ACCENTS).map(([name, hex]) =>
              `<button type="button" data-value="${name}" style="background:${hex}" aria-pressed="false"
                       aria-label="${name[0].toUpperCase() + name.slice(1)}" title="${name[0].toUpperCase() + name.slice(1)}"></button>`).join("")}
          </div>
        </div>
        <div class="tp-group"><h6>Text size</h6>
          ${seg("size", [["normal", "Normal"], ["large", "Large"]])}
        </div>
        <button type="button" class="tp-reset">Reset to default</button>
      </div>`;
    return wrap;
  };

  const mount = () => {
    const wrap = build();
    const topRight = document.querySelector(".prs-topbar .topbar-right");
    if (topRight) {
      // Sibling BEFORE .topbar-right: auth-guard.js rewrites that element's innerHTML.
      topRight.parentNode.insertBefore(wrap, topRight);
    } else {
      wrap.classList.add("floating"); // login page: no top bar
      document.body.appendChild(wrap);
    }

    const btn = wrap.querySelector(".theme-btn");
    const panel = wrap.querySelector(".theme-panel");

    const refresh = () => {
      wrap.querySelectorAll("[data-group]").forEach((g) => {
        const key = g.getAttribute("data-group");
        g.querySelectorAll("button").forEach((b) =>
          b.setAttribute("aria-pressed", String(b.getAttribute("data-value") === prefs[key])));
      });
    };
    const setOpen = (open) => {
      panel.hidden = !open;
      btn.setAttribute("aria-expanded", String(open));
      if (open) panel.querySelector("button[aria-pressed='true']")?.focus();
    };

    btn.addEventListener("click", (e) => { e.stopPropagation(); setOpen(panel.hidden); });
    panel.addEventListener("click", (e) => {
      e.stopPropagation();
      const b = e.target.closest("button");
      if (!b) return;
      if (b.classList.contains("tp-reset")) {
        prefs = { ...DEFAULTS };
      } else {
        const key = b.closest("[data-group]")?.getAttribute("data-group");
        if (!key) return;
        prefs[key] = b.getAttribute("data-value");
      }
      save(prefs); apply(true); refresh();
    });
    document.addEventListener("click", () => { if (!panel.hidden) setOpen(false); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !panel.hidden) { setOpen(false); btn.focus(); }
    });
    refresh();
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();

  window.PRS_THEME = { get: () => ({ ...prefs, resolved: resolvedMode() }) };
})();
