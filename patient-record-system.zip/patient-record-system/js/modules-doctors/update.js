// Phone is optional, but if typed in it must be 7-15 digits only -
// no "-" (so no negative numbers), "+", letters, or spaces.
const isValidPhone = (phone) => phone.trim() === "" || /^[0-9]{7,15}$/.test(phone.trim());

export const updateModal = async (userId, refreshDisplay) => {
  document.getElementById("blank-modal-title").innerText = "Edit Doctor";

  const doctor = await getDoctorDetails(userId);
  const d = doctor[0];
  const specializations = await getSpecializations();
  const selectedIds = d.specializations.map((s) => String(s.SpecializationID));

  const checkboxes = specializations
    .filter((s) => s.Status !== "Inactive" || selectedIds.includes(String(s.SpecializationID)))
    .map(
      (s) => `
        <div class="form-check">
          <input
            type="checkbox"
            class="form-check-input"
            id="upd-spec-${s.SpecializationID}"
            value="${s.SpecializationID}"
            ${selectedIds.includes(String(s.SpecializationID)) ? "checked" : ""}
          />
          <label class="form-check-label" for="upd-spec-${s.SpecializationID}">
            ${s.SpecializationName}${s.Status === "Inactive" ? " (inactive)" : ""}
          </label>
        </div>
      `
    )
    .join("");

  const myHtml = `
    <div class="col-12 mb-2">
      <label class="form-label">Last Name</label>
      <input type="text" class="form-control" id="upd-last-name" data-v="doctor_update.lastName" value="${d.LastName}" />
    </div>
    <div class="col-12 mb-2">
      <label class="form-label">First Name</label>
      <input type="text" class="form-control" id="upd-first-name" data-v="doctor_update.firstName" value="${d.FirstName}" />
    </div>
    <div class="col-12 mb-2">
      <label class="form-label">Username</label>
      <input type="text" class="form-control" id="upd-username" data-v="doctor_update.username" value="${d.Username}" />
    </div>
    <div class="col-12 mb-2">
      <label class="form-label">Password</label>
      <input type="password" class="form-control" id="upd-password" data-v="doctor_update.password" placeholder="Leave blank to keep current password" />
    </div>
    <div class="col-12 mb-2">
      <label class="form-label">Phone</label>
      <input type="text" class="form-control" id="upd-phone" data-v="doctor_update.phone" value="${d.Phone ?? ""}" />
    </div>
    <div class="col-12 mb-2">
      <label class="form-label">Daily patient limit</label>
      <input type="number" class="form-control" id="upd-daily-limit" data-v="doctor_update.dailyPatientLimit" min="1" max="100" value="${d.DailyPatientLimit ?? 20}" />
      <div class="form-text">Most patients this doctor accepts per day. Booking is blocked once it is reached; existing queue entries are not cancelled if you lower it.</div>
    </div>
    <div class="col-12 mb-2">
      <label class="form-label">Specializations</label>
      <div
        id="upd-specializations"
        class="border rounded p-2"
        style="max-height: 140px; overflow-y: auto;"
      >${checkboxes}</div>
      <div class="form-text">Check all specializations that apply.</div>
    </div>
  `;

  document.getElementById("blank-main-div").innerHTML = myHtml;

  const modalFooter = document.getElementById("blank-modal-footer");
  modalFooter.innerHTML = `
    <div class="btn-group w-100" role="group">
      <button type="button" class="btn btn-success btn-sm w-100 me-2 btn-save">Save Changes</button>
      <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
    </div>
  `;

  const myModal = new bootstrap.Modal(document.getElementById("blank-modal"), {
    keyboard: true,
    backdrop: "static",
  });

  modalFooter.querySelector(".btn-save").addEventListener("click", async () => {
    const specContainer = document.getElementById("upd-specializations");
    const jsonData = {
      userId: d.UserID,
      lastName: document.getElementById("upd-last-name").value,
      firstName: document.getElementById("upd-first-name").value,
      username: document.getElementById("upd-username").value,
      password: document.getElementById("upd-password").value, // blank = keep current
      phone: document.getElementById("upd-phone").value,
      dailyPatientLimit: document.getElementById("upd-daily-limit").value,
      specializationIds: [
        ...specContainer.querySelectorAll("input[type='checkbox']:checked"),
      ].map((checkbox) => checkbox.value),
    };
    if (!Validate.ok("doctor_update", jsonData)) return;

    if (!isValidPhone(jsonData.phone)) {
      alert("Phone must contain digits only (7-15 digits), with no negative sign or letters.");
      return;
    }

    const result = await updateDoctor(jsonData);
    if (result == 1) {
      refreshDisplay();
      alert("Doctor updated!");
      myModal.hide();
    } else {
      const messages = {
        invalid_phone: "Phone must contain digits only (7-15 digits), with no negative sign or letters.",
        missing_fields: "Please fill in the first name, last name and username.",
        invalid_username: "Username must be 3-50 characters: letters, numbers, and underscore only.",
        weak_password: "Password must be at least 6 characters.",
        username_taken: "That username is already taken.",
        not_found: "That doctor no longer exists.",
      };
      alert(messages[result?.error] || "ERROR");
    }
  });

  myModal.show();
};

const getDoctorDetails = async (userId) => {
  const params = {
    operation: "getDoctor",
    json: JSON.stringify({ userId: userId }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/doctors.php`, {
    params: params,
  });
  return response.data;
};

const getSpecializations = async () => {
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/specializations.php`, {
    params: { operation: "getSpecializations" },
  });
  return response.data;
};

const updateDoctor = async (jsonData) => {
  const formData = new FormData();
  formData.append("operation", "updateDoctor");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({
    url: `${sessionStorage.baseAPIUrl}/doctors.php`,
    method: "POST",
    data: formData,
  });
  return response.data;
};
