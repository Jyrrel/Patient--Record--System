<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";

class Appointment {

    // Queue number = this appointment's place in the doctor's line-up for that DAY (1, 2, 3 ...),
    // counting the doctor's NON-cancelled appointments ordered by their QUEUE KEY: the moment they BOOKED
    // (CreatedAt) - or, when the patient was skipped / requeued, the moment they were sent to the back
    // of the line (RequeuedAt). Ties are broken by AppointmentID. Calculated when read, so it stays
    // correct when someone cancels (the others move up).
    private $queueSql = "(CASE WHEN a.Status = 'Cancelled' THEN NULL ELSE (
                SELECT COUNT(*) + 1 FROM APPOINTMENT q
                WHERE q.UserID = a.UserID AND q.AppointmentDate = a.AppointmentDate
                  AND q.Status <> 'Cancelled' AND q.AppointmentID <> a.AppointmentID
                  AND (COALESCE(q.RequeuedAt, q.CreatedAt, '1970-01-01 00:00:00') < COALESCE(a.RequeuedAt, a.CreatedAt, '1970-01-01 00:00:00')
                       OR (COALESCE(q.RequeuedAt, q.CreatedAt, '1970-01-01 00:00:00') = COALESCE(a.RequeuedAt, a.CreatedAt, '1970-01-01 00:00:00')
                           AND q.AppointmentID < a.AppointmentID))
              ) END)";

    // All appointments — Admin/Staff view (full list, all doctors)
    function getAllAppointments() {
        include "connection-pdo.php";
        $sql = "SELECT
                    a.AppointmentID,
                    a.AppointmentDate,
                    a.AppointmentTime,
                    a.Reason,
                    a.Status,
                    a.Notes,
                    a.ChiefComplaint,
                    a.Symptoms,
                    a.CreatedAt,
                    {$this->queueSql} AS QueueNumber,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    p.PatientID,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                    u.UserID,
                    (SELECT COUNT(*) FROM VITAL_SIGN v
                      WHERE v.AppointmentID = a.AppointmentID AND v.Status = 'Active') AS HasVitals,
                    (a.ChiefComplaint IS NOT NULL AND a.ChiefComplaint <> '') AS HasIntake
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                ORDER BY a.AppointmentDate DESC, QueueNumber ASC";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Appointments for a specific doctor (Doctor view)
    function getAppointmentsByDoctor($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT
                    a.AppointmentID,
                    a.AppointmentDate,
                    a.AppointmentTime,
                    a.Reason,
                    a.Status,
                    a.Notes,
                    a.ChiefComplaint,
                    a.Symptoms,
                    a.CreatedAt,
                    {$this->queueSql} AS QueueNumber,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    p.PatientID,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                    u.UserID,
                    (SELECT COUNT(*) FROM VITAL_SIGN v
                      WHERE v.AppointmentID = a.AppointmentID AND v.Status = 'Active') AS HasVitals,
                    (a.ChiefComplaint IS NOT NULL AND a.ChiefComplaint <> '') AS HasIntake
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                WHERE a.UserID = :userId
                ORDER BY a.AppointmentDate DESC, QueueNumber ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":userId", $json['userId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Single appointment detail
    function getAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT
                    a.*,
                    {$this->queueSql} AS QueueNumber,
                    CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                    CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                FROM APPOINTMENT a
                JOIN PATIENT p ON a.PatientID = p.PatientID
                JOIN USERS   u ON a.UserID    = u.UserID
                WHERE a.AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Next patient in line for the SAME doctor on the SAME day as the given (just finished) appointment:
    // the first still-Scheduled appointment by queue number (who booked first).
    // Used by the Doctor's "Call Next Patient" button on the consultation page.
    function getNextPatient($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!empty($json['appointmentId'])) {
            $cur = $conn->prepare("SELECT UserID, AppointmentDate FROM APPOINTMENT WHERE AppointmentID = :id");
            $cur->bindValue(":id", $json['appointmentId']);
            $cur->execute();
            $c = $cur->fetch(PDO::FETCH_ASSOC);
            if (!$c) return json_encode(null);
            $currentId = $json['appointmentId'];
        } elseif (!empty($json['userId'])) {
            // No finished appointment to start from: this doctor's queue for today
            $c = ['UserID' => $json['userId'], 'AppointmentDate' => Validator::today()];
            $currentId = 0;
        } else {
            return json_encode(null);
        }

        $sql = "SELECT * FROM (
                    SELECT
                        a.AppointmentID,
                        a.AppointmentDate,
                        a.AppointmentTime,
                        a.Reason,
                        {$this->queueSql} AS QueueNumber,
                        CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                        CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                    FROM APPOINTMENT a
                    JOIN PATIENT p ON a.PatientID = p.PatientID
                    JOIN USERS   u ON a.UserID    = u.UserID
                    WHERE a.UserID = :userId
                      AND a.AppointmentDate = :apptDate
                      AND a.Status = 'Scheduled'
                      AND a.AppointmentID <> :currentId
                ) n
                ORDER BY n.QueueNumber ASC, n.AppointmentID ASC
                LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(":userId",    $c['UserID']);
        $stmt->bindValue(":apptDate",  $c['AppointmentDate']);
        $stmt->bindValue(":currentId", $currentId);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return json_encode($row ? $row : null);
    }

    // Get all active doctors for the doctor dropdown
    function getActiveDoctors() {
        include "connection-pdo.php";
        $sql = "SELECT u.UserID, u.DailyPatientLimit,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                       GROUP_CONCAT(s.SpecializationName ORDER BY s.SpecializationName SEPARATOR ', ') AS Specializations
                FROM USERS u
                JOIN ROLE r ON u.RoleID = r.RoleID
                LEFT JOIN DOCTOR_SPECIALIZATION ds ON ds.UserID = u.UserID
                LEFT JOIN SPECIALIZATION s ON s.SpecializationID = ds.SpecializationID
                WHERE r.RoleName = 'Doctor' AND u.Status = 'Active'
                GROUP BY u.UserID, u.DailyPatientLimit, u.LastName, u.FirstName
                ORDER BY u.LastName, u.FirstName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // The PATIENT record a logged-in Patient account is linked to (null for anyone else).
    // The patient is ALWAYS taken from the account on the server - never from the request.
    private function myPatientId($conn, $actingUserId) {
        if (empty($actingUserId)) return null;
        $st = $conn->prepare("SELECT u.PatientID FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Patient'
                                AND u.PatientID IS NOT NULL");
        $st->bindValue(":id", $actingUserId);
        $st->execute();
        $pid = $st->fetchColumn();
        return $pid === false ? null : (int)$pid;
    }

    // Patient: my own appointments (all statuses)
    function getMyAppointments($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $pid = $this->myPatientId($conn, $json['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);

        $st = $conn->prepare("SELECT a.AppointmentID, a.AppointmentDate, a.AppointmentTime, a.Reason, a.Status, a.CreatedAt,
                                     {$this->queueSql} AS QueueNumber,
                                     CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                              FROM APPOINTMENT a JOIN USERS u ON a.UserID = u.UserID
                              WHERE a.PatientID = :pid
                              ORDER BY a.AppointmentDate DESC, QueueNumber ASC");
        $st->bindValue(":pid", $pid);
        $st->execute();
        return json_encode($st->fetchAll(PDO::FETCH_ASSOC));
    }

    // Patient: book an appointment for myself online (same validation + the same-patient
    // guard as staff booking, because it goes through insertAppointment).
    function bookMyAppointment($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $pid = $this->myPatientId($conn, $in['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);
        if (trim($in['reason'] ?? '') === '') return Validator::fail("Please tell us the reason for your visit.");

        return $this->insertAppointment(json_encode([
            "patientId"       => $pid,
            "userId"          => $in['userId'] ?? null,
            "appointmentAt"   => $in['appointmentAt'] ?? null,
            "appointmentDate" => $in['appointmentDate'] ?? null,
            "appointmentTime" => $in['appointmentTime'] ?? null,
            "reason"          => $in['reason'] ?? null,
            "notes"           => $in['notes'] ?? null,
        ]));
    }

    // Patient: cancel one of MY appointments. Only a still-Scheduled one.
    function cancelMyAppointment($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $pid = $this->myPatientId($conn, $in['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);
        if ($e = Validator::badId($in, ['appointmentId'])) return Validator::fail($e);

        $st = $conn->prepare("SELECT Status FROM APPOINTMENT WHERE AppointmentID = :id AND PatientID = :pid");
        $st->bindValue(":id", $in['appointmentId']);
        $st->bindValue(":pid", $pid);
        $st->execute();
        $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) return Validator::fail("That queue was not found.");
        if ($a['Status'] !== 'Scheduled') return Validator::fail("Only a scheduled queue can be cancelled.");

        $up = $conn->prepare("UPDATE APPOINTMENT SET Status = 'Cancelled' WHERE AppointmentID = :id AND PatientID = :pid AND Status = 'Scheduled'");
        $up->bindValue(":id", $in['appointmentId']);
        $up->bindValue(":pid", $pid);
        $up->execute();
        return json_encode($up->rowCount() > 0 ? 1 : 0);
    }

    // Create — available to Staff, Doctor, and Patient (all roles)
    // Many patients MAY book the same doctor at the same date and time - they are put in a queue by
    // who submitted first (see $queueSql). The guard: the same PATIENT can't have more than one
    // appointment on the same DAY. Scheduled and Completed ones count; Cancelled and No-Show don't.
    private function findConflict($conn, $json, $excludeId = null) {
        $sql = "SELECT COUNT(*) FROM APPOINTMENT
                WHERE PatientID = :who AND AppointmentDate = :d AND Status IN ('Scheduled', 'Completed')";
        if ($excludeId !== null) $sql .= " AND AppointmentID != :id";
        $st = $conn->prepare($sql);
        $st->bindValue(":who", $json['patientId']);
        $st->bindValue(":d", $json['appointmentDate']);
        if ($excludeId !== null) $st->bindValue(":id", $excludeId);
        $st->execute();
        if ((int)$st->fetchColumn() > 0) {
            return "That patient already has a queue on {$json['appointmentDate']}. A patient can only have one queue per day.";
        }
        return null;
    }

    // The patient/staff choose only the DATE. The time is recorded automatically: it is the moment the
    // appointment was booked (server clock, Asia/Manila), so appointmentAt = chosen date + booking time.
    // When $keepTime is given (an update) the time recorded at booking is kept instead.
    private function stampDate($json, $keepTime = null) {
        if (!is_array($json)) return [];
        $date = !empty($json['appointmentDate']) ? $json['appointmentDate'] : substr((string)($json['appointmentAt'] ?? ''), 0, 10);
        if ($date === '' || $date === false) { $json['appointmentAt'] = ''; return $json; }
        $time = $keepTime ?: (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('H:i');
        $json['appointmentAt'] = $date . ' ' . $time;
        return $json;
    }

    // After validation appointmentAt is 'YYYY-MM-DD HH:MM:00'; the Date and Time columns are kept in step.
    private function splitTimestamp($json) {
        $json['appointmentDate'] = substr($json['appointmentAt'], 0, 10);
        $json['appointmentTime'] = substr($json['appointmentAt'], 11, 5);
        return $json;
    }

    // Locks the doctor's row so two bookings made at the same moment are checked one after the other
    // (otherwise both could take the doctor's last slot of the day). Use inside a transaction.
    private function lockDoctor($conn, $userId) {
        $st = $conn->prepare("SELECT UserID FROM USERS WHERE UserID = :id FOR UPDATE");
        $st->bindValue(":id", $userId);
        $st->execute();
    }

    function insertAppointment($json) {
        include "connection-pdo.php";
        $json = $this->stampDate(json_decode($json, true));

        list($err, $json) = Validator::run("appointment", $json);
        if ($err) return Validator::fail($err);
        $json = $this->splitTimestamp($json);

        // The patient must exist and be Active; the doctor must be an Active user with the Doctor role.
        $pc = $conn->prepare("SELECT COUNT(*) FROM PATIENT WHERE PatientID = :id AND Status = 'Active'");
        $pc->bindValue(":id", $json['patientId']); $pc->execute();
        if ((int)$pc->fetchColumn() === 0) return Validator::fail("That patient is not available. Please select an active patient.");
        $dc = $conn->prepare("SELECT COUNT(*) FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Doctor'");
        $dc->bindValue(":id", $json['userId']); $dc->execute();
        if ((int)$dc->fetchColumn() === 0) return Validator::fail("That doctor is not available. Please select an active doctor.");

        // Conflict + daily-limit checks and the INSERT happen in one transaction with the doctor locked.
        try {
            $conn->beginTransaction();
            $this->lockDoctor($conn, $json['userId']);
            if (($e = $this->findConflict($conn, $json)) || ($e = Validator::dailyLimitError($conn, $json['userId'], $json['appointmentDate']))) {
                $conn->rollBack();
                return Validator::fail($e);
            }

            // CreatedAt = the moment the request was submitted (shown as "Requested"; decides the queue order).
            $sql = "INSERT INTO APPOINTMENT
                        (PatientID, UserID, AppointmentAt, AppointmentDate, AppointmentTime, Reason, Notes, Status, CreatedAt)
                    VALUES
                        (:patientId, :userId, :appointmentAt, :appointmentDate, :appointmentTime, :reason, :notes, 'Scheduled', NOW())";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(":patientId",       $json['patientId']);
            $stmt->bindParam(":userId",          $json['userId']);
            $stmt->bindParam(":appointmentAt",   $json['appointmentAt']);
            $stmt->bindParam(":appointmentDate", $json['appointmentDate']);
            $stmt->bindParam(":appointmentTime", $json['appointmentTime']);
            $stmt->bindParam(":reason",          $json['reason']);
            $stmt->bindParam(":notes",           $json['notes']);
            $stmt->execute();
            $newId = (int)$conn->lastInsertId();
            $conn->commit();
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            return json_encode(0);
        }

        if (!empty($json['returnId'])) {
            // Lets the Staff UI go straight on to the intake
            return json_encode(["appointmentId" => $newId]);
        }
        return json_encode(1);
    }

    // Update — Admin and Staff only
    function updateAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!is_array($json)) $json = [];

        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $cur = $conn->prepare("SELECT UserID, Status, AppointmentDate, TIME_FORMAT(AppointmentTime, '%H:%i') AS T FROM APPOINTMENT WHERE AppointmentID = :id");
        $cur->bindParam(":id", $json['appointmentId']);
        $cur->execute();
        $old = $cur->fetch(PDO::FETCH_ASSOC);
        if (!$old) return Validator::fail("That queue no longer exists.");

        // Only the DATE can be changed; the time stays the one recorded when it was booked.
        // "Not in the past" is judged on the date and only when the date is being changed,
        // so an old appointment can still be marked Completed / No-Show.
        $json    = $this->stampDate($json, $old['T']);
        $changed = substr((string)($json['appointmentAt'] ?? ''), 0, 10) !== $old['AppointmentDate'];
        list($err, $json) = Validator::run("appointment", $json, ['relax' => $changed ? [] : ['notPast']]);
        if ($err) return Validator::fail($err);
        if (empty($json['status'])) return Validator::fail("Status is required.");
        $json = $this->splitTimestamp($json);

        try {
            $conn->beginTransaction();
            $this->lockDoctor($conn, $json['userId']);
            if ($json['status'] === 'Scheduled') {
                if ($e = $this->findConflict($conn, $json, $json['appointmentId'])) { $conn->rollBack(); return Validator::fail($e); }
                // The daily limit is only checked when this appointment is moving onto a doctor/day
                // (or coming back to Scheduled), so a day that is already full can still be edited.
                $moved = ((int)$json['userId'] !== (int)$old['UserID']) || $json['appointmentDate'] !== $old['AppointmentDate'] || $old['Status'] !== 'Scheduled';
                if ($moved && ($e = Validator::dailyLimitError($conn, $json['userId'], $json['appointmentDate'], $json['appointmentId']))) {
                    $conn->rollBack();
                    return Validator::fail($e);
                }
            }

            $sql = "UPDATE APPOINTMENT SET
                        PatientID       = :patientId,
                        UserID          = :userId,
                        AppointmentAt   = :appointmentAt,
                        AppointmentDate = :appointmentDate,
                        AppointmentTime = :appointmentTime,
                        Reason          = :reason,
                        Notes           = :notes,
                        Status          = :status
                    WHERE AppointmentID = :appointmentId";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(":patientId",       $json['patientId']);
            $stmt->bindParam(":userId",          $json['userId']);
            $stmt->bindParam(":appointmentAt",   $json['appointmentAt']);
            $stmt->bindParam(":appointmentDate", $json['appointmentDate']);
            $stmt->bindParam(":appointmentTime", $json['appointmentTime']);
            $stmt->bindParam(":reason",          $json['reason']);
            $stmt->bindParam(":notes",           $json['notes']);
            $stmt->bindParam(":status",          $json['status']);
            $stmt->bindParam(":appointmentId",   $json['appointmentId']);
            $stmt->execute();
            $conn->commit();
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            return json_encode(0);
        }

        return Validator::saved($conn, $stmt, 'APPOINTMENT', 'AppointmentID', $json['appointmentId']);
    }

    // Cancel — Admin and Staff only (soft status change)
    function cancelAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $sql = "UPDATE APPOINTMENT SET Status = 'Cancelled' WHERE AppointmentID = :appointmentId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":appointmentId", $json['appointmentId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Staff record the intake: Reason, Chief Complaint and Symptoms. The doctor sees
    // these automatically in the consultation and does not re-enter them.
    function saveIntake($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);

        $roleStmt = $conn->prepare("SELECT r.RoleName FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                                    WHERE u.UserID = :id AND u.Status = 'Active'");
        $roleStmt->bindValue(":id", $json['actingUserId'] ?? null);
        $roleStmt->execute();
        if ($roleStmt->fetchColumn() !== 'Staff') return json_encode(["error" => "forbidden"]);

                list($err, $json) = Validator::run("intake", $json, ['nullEmpty' => true]);
        if ($err) return Validator::fail($err);
$cur = $conn->prepare("SELECT Status FROM APPOINTMENT WHERE AppointmentID = :id");
        $cur->bindValue(":id", $json['appointmentId'] ?? null);
        $cur->execute();
        $status = $cur->fetchColumn();
        if ($status === false) return json_encode(["error" => "not_found"]);
        if ($status === 'Cancelled') return json_encode(["error" => "appointment_cancelled"]);

        $stmt = $conn->prepare("UPDATE APPOINTMENT SET
                                    Reason = :reason, ChiefComplaint = :cc, Symptoms = :symptoms
                                WHERE AppointmentID = :id");
        $stmt->bindValue(":reason",   $json['reason']         ?? null);
        $stmt->bindValue(":cc",       $json['chiefComplaint'] ?? null);
        $stmt->bindValue(":symptoms", $json['symptoms']       ?? null);
        $stmt->bindValue(":id",       $json['appointmentId']);
        $stmt->execute();
        return json_encode(1); // rowCount is 0 when nothing changed - still a success
    }

    // Restore a cancelled appointment back to Scheduled (Admin "Restore" button).
    // Only touches rows that are currently Cancelled.
    function restoreAppointment($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['appointmentId'])) return Validator::fail($e);
        $row = $conn->prepare("SELECT PatientID, UserID, AppointmentDate, TIME_FORMAT(AppointmentTime, '%H:%i') AS AppointmentTime
                               FROM APPOINTMENT WHERE AppointmentID = :id AND Status = 'Cancelled'");
        $row->bindValue(":id", $json['appointmentId']);
        $row->execute();
        $r = $row->fetch(PDO::FETCH_ASSOC);
        if (!$r) return json_encode(0);
        if ($r['AppointmentDate'] < Validator::today())
            return Validator::fail("This queue's date has already passed, so it can't be set back to Scheduled. Use Edit to change the date instead.");

        try {
            $conn->beginTransaction();
            $this->lockDoctor($conn, $r['UserID']);
            $data = ['patientId' => $r['PatientID'], 'userId' => $r['UserID'],
                     'appointmentDate' => $r['AppointmentDate'], 'appointmentTime' => $r['AppointmentTime']];
            if (($e = $this->findConflict($conn, $data, $json['appointmentId'])) || ($e = Validator::dailyLimitError($conn, $r['UserID'], $r['AppointmentDate'], $json['appointmentId']))) {
                $conn->rollBack();
                return Validator::fail($e);
            }
            $stmt = $conn->prepare("UPDATE APPOINTMENT SET Status = 'Scheduled'
                                    WHERE AppointmentID = :appointmentId AND Status = 'Cancelled'");
            $stmt->bindParam(":appointmentId", $json['appointmentId']);
            $stmt->execute();
            $conn->commit();
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            return json_encode(0);
        }
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // The patient did not show up when called: the doctor (for their OWN appointment) or Staff/Admin voids it
    // by marking it No-Show. Only a Scheduled appointment of today or an earlier day can be voided, and the
    // slot is freed (the daily limit counts Scheduled + Completed only).
    function markNoShow($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        if ($e = Validator::badId($in, ['appointmentId'])) return Validator::fail($e);
        $who = $conn->prepare("SELECT r.RoleName FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                               WHERE u.UserID = :id AND u.Status = 'Active'");
        $who->bindValue(":id", $in['actingUserId'] ?? null);
        $who->execute();
        $role = $who->fetchColumn();
        if (!in_array($role, ['Doctor', 'Staff', 'Admin'], true)) return json_encode(["error" => "forbidden"]);

        $st = $conn->prepare("SELECT UserID, Status, AppointmentDate FROM APPOINTMENT WHERE AppointmentID = :id");
        $st->bindValue(":id", $in['appointmentId']);
        $st->execute();
        $a = $st->fetch(PDO::FETCH_ASSOC);
        if (!$a) return Validator::fail("That queue was not found.");
        if ($role === 'Doctor' && (int)$a['UserID'] !== (int)$in['actingUserId']) return json_encode(["error" => "forbidden"]);
        if ($a['Status'] !== 'Scheduled') return Validator::fail("Only a scheduled queue can be marked as No-Show.");
        if ($a['AppointmentDate'] > Validator::today()) return Validator::fail("This queue is on a later day, so it can't be marked as No-Show yet.");

        $up = $conn->prepare("UPDATE APPOINTMENT SET Status = 'No-Show' WHERE AppointmentID = :id AND Status = 'Scheduled'");
        $up->bindValue(":id", $in['appointmentId']);
        $up->execute();
        return json_encode($up->rowCount() > 0 ? 1 : 0);
    }

    // Doctor (own queue) / Staff / Admin only. Returns [$role, null] or [null, errorJson].
    private function queueActor($conn, $in) {
        $who = $conn->prepare("SELECT r.RoleName FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                               WHERE u.UserID = :id AND u.Status = 'Active'");
        $who->bindValue(":id", $in['actingUserId'] ?? null);
        $who->execute();
        $role = $who->fetchColumn();
        if (!in_array($role, ['Doctor', 'Staff', 'Admin'], true)) return [null, json_encode(["error" => "forbidden"])];
        return [$role, null];
    }

    // The queue key that puts someone at the very END of the doctor's line for that day: now, or one
    // second after the latest key in the line (so it still works if two moves happen in the same second).
    private function backOfLine($conn, $userId, $date, $exceptId) {
        $st = $conn->prepare("SELECT GREATEST(NOW(), DATE_ADD(COALESCE(MAX(COALESCE(RequeuedAt, CreatedAt)), NOW()), INTERVAL 1 SECOND))
                              FROM APPOINTMENT
                              WHERE UserID = :u AND AppointmentDate = :d AND Status <> 'Cancelled' AND AppointmentID <> :x");
        $st->bindValue(":u", $userId);
        $st->bindValue(":d", $date);
        $st->bindValue(":x", $exceptId);
        $st->execute();
        return $st->fetchColumn();
    }

    // SKIP: pass over a waiting patient for now (not here yet, in the restroom, still at the lab ...).
    // They stay Scheduled - they keep their slot - but go to the back of today's line, so the next
    // patient is called instead. Only today's queue, and only when someone else is still waiting.
    function skipAppointment($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        if ($e = Validator::badId($in, ['appointmentId'])) return Validator::fail($e);
        list($role, $forbidden) = $this->queueActor($conn, $in);
        if ($forbidden) return $forbidden;

        try {
            $st = $conn->prepare("SELECT UserID, Status, AppointmentDate FROM APPOINTMENT WHERE AppointmentID = :id");
            $st->bindValue(":id", $in['appointmentId']);
            $st->execute();
            $a = $st->fetch(PDO::FETCH_ASSOC);
            if (!$a) return Validator::fail("That queue was not found.");
            if ($role === 'Doctor' && (int)$a['UserID'] !== (int)$in['actingUserId']) return json_encode(["error" => "forbidden"]);

            $conn->beginTransaction();
            $this->lockDoctor($conn, $a['UserID']);

            // Re-read inside the lock so two clicks at once can't both go through
            $st = $conn->prepare("SELECT Status FROM APPOINTMENT WHERE AppointmentID = :id");
            $st->bindValue(":id", $in['appointmentId']);
            $st->execute();
            if ($st->fetchColumn() !== 'Scheduled') { $conn->rollBack(); return Validator::fail("Only a scheduled queue can be skipped."); }
            if ($a['AppointmentDate'] !== Validator::today()) { $conn->rollBack(); return Validator::fail("Only today's queue can be skipped."); }

            $others = $conn->prepare("SELECT COUNT(*) FROM APPOINTMENT
                                      WHERE UserID = :u AND AppointmentDate = :d AND Status = 'Scheduled' AND AppointmentID <> :x");
            $others->bindValue(":u", $a['UserID']);
            $others->bindValue(":d", $a['AppointmentDate']);
            $others->bindValue(":x", $in['appointmentId']);
            $others->execute();
            if ((int)$others->fetchColumn() === 0) { $conn->rollBack(); return Validator::fail("No other patient is waiting, so there is nobody to skip to."); }

            $key = $this->backOfLine($conn, $a['UserID'], $a['AppointmentDate'], $in['appointmentId']);
            $up = $conn->prepare("UPDATE APPOINTMENT SET RequeuedAt = :k, SkipCount = SkipCount + 1
                                  WHERE AppointmentID = :id AND Status = 'Scheduled'");
            $up->bindValue(":k", $key);
            $up->bindValue(":id", $in['appointmentId']);
            $up->execute();
            $conn->commit();
            return json_encode($up->rowCount() > 0 ? 1 : 0);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            return json_encode(0);
        }
    }

    // REQUEUE: a patient who was marked No-Show turned up after all. They go back to Scheduled at the
    // END of today's line. Same rules as booking: the doctor's daily limit and the one-appointment-
    // per-patient-per-day guard are checked again, because No-Show had freed the slot.
    function requeueAppointment($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        if ($e = Validator::badId($in, ['appointmentId'])) return Validator::fail($e);
        list($role, $forbidden) = $this->queueActor($conn, $in);
        if ($forbidden) return $forbidden;

        try {
            $st = $conn->prepare("SELECT PatientID, UserID, Status, AppointmentDate FROM APPOINTMENT WHERE AppointmentID = :id");
            $st->bindValue(":id", $in['appointmentId']);
            $st->execute();
            $a = $st->fetch(PDO::FETCH_ASSOC);
            if (!$a) return Validator::fail("That queue was not found.");
            if ($role === 'Doctor' && (int)$a['UserID'] !== (int)$in['actingUserId']) return json_encode(["error" => "forbidden"]);
            if ($a['Status'] !== 'No-Show') return Validator::fail("Only a No-Show queue can be requeued.");
            if ($a['AppointmentDate'] !== Validator::today()) return Validator::fail("Only today's No-Show patients can be requeued.");

            $conn->beginTransaction();
            $this->lockDoctor($conn, $a['UserID']);
            $data = ['patientId' => $a['PatientID'], 'appointmentDate' => $a['AppointmentDate']];
            if (($e = $this->findConflict($conn, $data, $in['appointmentId']))
                || ($e = Validator::dailyLimitError($conn, $a['UserID'], $a['AppointmentDate'], $in['appointmentId']))) {
                $conn->rollBack();
                return Validator::fail($e);
            }

            $key = $this->backOfLine($conn, $a['UserID'], $a['AppointmentDate'], $in['appointmentId']);
            $up = $conn->prepare("UPDATE APPOINTMENT SET Status = 'Scheduled', RequeuedAt = :k
                                  WHERE AppointmentID = :id AND Status = 'No-Show'");
            $up->bindValue(":k", $key);
            $up->bindValue(":id", $in['appointmentId']);
            $up->execute();
            $conn->commit();
            return json_encode($up->rowCount() > 0 ? 1 : 0);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            return json_encode(0);
        }
    }

    // A Doctor sets how many patients THEY will see per day (their own limit only; Admin may set any doctor's).
    // Appointments already booked are never cancelled when the limit is lowered - it only blocks new bookings.
    function setDailyLimit($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $who = $conn->prepare("SELECT r.RoleName FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                               WHERE u.UserID = :id AND u.Status = 'Active'");
        $who->bindValue(":id", $in['actingUserId'] ?? null);
        $who->execute();
        $role = $who->fetchColumn();
        $target = $in['userId'] ?? ($in['actingUserId'] ?? null);
        if ($role === 'Doctor') { if ((int)$target !== (int)$in['actingUserId']) return json_encode(["error" => "forbidden"]); }
        elseif ($role !== 'Admin') return json_encode(["error" => "forbidden"]);

        $limit = trim((string)($in['limit'] ?? ''));
        if (!preg_match('/^[0-9]+$/', $limit) || (int)$limit < 1 || (int)$limit > 100)
            return Validator::fail("Daily patient limit must be a whole number between 1 and 100.");
        $up = $conn->prepare("UPDATE USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              SET u.DailyPatientLimit = :l WHERE u.UserID = :id AND r.RoleName = 'Doctor'");
        $up->bindValue(":l", (int)$limit);
        $up->bindValue(":id", $target);
        $up->execute();
        return json_encode(Validator::doctorLimit($conn, $target) === (int)$limit ? 1 : 0);
    }

    // How full is a doctor's day? Used by the booking screens to show "7 of 20 patients booked", the
    // doctor's queue for that day, and to stop booking once the daily limit is reached.
    // Patients get the numbers and queue positions only (never other patients' names or reasons).
    function getDoctorDayLoad($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        if ($e = Validator::badId($in, ['userId'])) return Validator::fail($e);
        $date = $in['date'] ?? '';
        $d = DateTime::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) return Validator::fail("Please choose a valid date.");

        $who = $conn->prepare("SELECT r.RoleName, u.PatientID FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                               WHERE u.UserID = :id AND u.Status = 'Active'");
        $who->bindValue(":id", $in['actingUserId'] ?? null);
        $who->execute();
        $me = $who->fetch(PDO::FETCH_ASSOC);
        if (!$me) return json_encode(["error" => "forbidden"]);
        if ($me['RoleName'] === 'Doctor' && (int)$in['actingUserId'] !== (int)$in['userId']) return json_encode(["error" => "forbidden"]);
        $isPatient = $me['RoleName'] === 'Patient';

        $doc = $conn->prepare("SELECT CONCAT(u.LastName, ', ', u.FirstName) FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                               WHERE u.UserID = :id AND r.RoleName = 'Doctor'");
        $doc->bindValue(":id", $in['userId']);
        $doc->execute();
        $doctorName = $doc->fetchColumn();
        if ($doctorName === false) return Validator::fail("That doctor was not found.");

        // Same order as the queue number / "Call Next Patient": booked-first, with skipped / requeued
        // patients behind everyone who was already waiting.
        $st = $conn->prepare("SELECT a.AppointmentID, a.PatientID, a.Status, a.Reason, a.SkipCount,
                                     (a.RequeuedAt IS NOT NULL) AS WasMoved,
                                     TIME_FORMAT(a.AppointmentTime, '%H:%i') AS T,
                                     CONCAT(p.LastName, ', ', p.FirstName) AS PatientName
                              FROM APPOINTMENT a JOIN PATIENT p ON p.PatientID = a.PatientID
                              WHERE a.UserID = :u AND a.AppointmentDate = :d AND a.Status IN ('Scheduled', 'Completed')
                              ORDER BY COALESCE(a.RequeuedAt, a.CreatedAt, '1970-01-01 00:00:00'), a.AppointmentID");
        $st->bindValue(":u", $in['userId']);
        $st->bindValue(":d", $date);
        $st->execute();

        $queue = []; $pos = 0;
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $pos++;
            $queue[] = [
                "position"      => $pos,
                "appointmentId" => (int)$r['AppointmentID'],
                "time"          => $r['T'],
                "status"        => $r['Status'],
                "mine"          => $isPatient && (int)$r['PatientID'] === (int)$me['PatientID'],
                "patientName"   => $isPatient ? null : $r['PatientName'],
                "reason"        => $isPatient ? null : $r['Reason'],
                "skips"         => (int)$r['SkipCount'],
                "moved"         => (bool)$r['WasMoved'],
            ];
        }

        // Patients who did not come when called (No-Show) can be requeued - staff/doctor view only.
        $noShows = [];
        if (!$isPatient) {
            $ns = $conn->prepare("SELECT a.AppointmentID, a.Reason, TIME_FORMAT(a.AppointmentTime, '%H:%i') AS T,
                                         CONCAT(p.LastName, ', ', p.FirstName) AS PatientName
                                  FROM APPOINTMENT a JOIN PATIENT p ON p.PatientID = a.PatientID
                                  WHERE a.UserID = :u AND a.AppointmentDate = :d AND a.Status = 'No-Show'
                                  ORDER BY a.AppointmentID");
            $ns->bindValue(":u", $in['userId']);
            $ns->bindValue(":d", $date);
            $ns->execute();
            foreach ($ns->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $noShows[] = ["appointmentId" => (int)$r['AppointmentID'], "time" => $r['T'],
                              "patientName" => $r['PatientName'], "reason" => $r['Reason']];
            }
        }

        $limit  = Validator::doctorLimit($conn, $in['userId']);
        $booked = count($queue);
        return json_encode([
            "userId" => (int)$in['userId'], "doctorName" => $doctorName, "date" => $date, "today" => Validator::today(),
            "limit" => $limit, "booked" => $booked, "remaining" => max(0, $limit - $booked),
            "full" => $booked >= $limit, "queue" => $queue, "noShows" => $noShows,
        ]);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$appt = new Appointment();
switch ($operation) {
    case "getAllAppointments":       echo $appt->getAllAppointments();           break;
    case "getAppointmentsByDoctor": echo $appt->getAppointmentsByDoctor($json); break;
    case "getAppointment":          echo $appt->getAppointment($json);          break;
    case "getActiveDoctors":        echo $appt->getActiveDoctors();             break;
    case "getNextPatient":           echo $appt->getNextPatient($json);          break;
    case "markNoShow":               echo $appt->markNoShow($json);              break;
    case "skipAppointment":          echo $appt->skipAppointment($json);         break;
    case "requeueAppointment":       echo $appt->requeueAppointment($json);      break;
    case "setDailyLimit":            echo $appt->setDailyLimit($json);           break;
    case "getDoctorDayLoad":         echo $appt->getDoctorDayLoad($json);        break;
    case "insertAppointment":       echo $appt->insertAppointment($json);       break;
    case "updateAppointment":       echo $appt->updateAppointment($json);       break;
    case "cancelAppointment":       echo $appt->cancelAppointment($json);       break;
    case "restoreAppointment":      echo $appt->restoreAppointment($json);      break;
    case "saveIntake":              echo $appt->saveIntake($json);              break;
    case "getMyAppointments":       echo $appt->getMyAppointments($json);       break;
    case "bookMyAppointment":       echo $appt->bookMyAppointment($json);       break;
    case "cancelMyAppointment":     echo $appt->cancelMyAppointment($json);     break;
}
?>
