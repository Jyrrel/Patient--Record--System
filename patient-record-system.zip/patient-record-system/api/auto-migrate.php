<?php
// Brings an older database up to the schema the current code expects.
// Safe to run repeatedly: each step only runs if its column/constraint is missing,
// and nothing is ever dropped or deleted. Called from connection-pdo.php.
if (!function_exists('ensureSchema')) {
    function ensureSchema($conn) {
        static $done = false;
        if ($done) return;
        $done = true;

        try {
            $db = $conn->query("SELECT DATABASE()")->fetchColumn();

            $has = function ($table, $column = null) use ($conn, $db) {
                if ($column === null) {
                    $q = $conn->prepare("SELECT COUNT(*) FROM information_schema.TABLES
                                         WHERE TABLE_SCHEMA = :db AND TABLE_NAME = :t");
                    $q->execute([":db" => $db, ":t" => $table]);
                } else {
                    $q = $conn->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS
                                         WHERE TABLE_SCHEMA = :db AND TABLE_NAME = :t AND COLUMN_NAME = :c");
                    $q->execute([":db" => $db, ":t" => $table, ":c" => $column]);
                }
                return $q->fetchColumn() > 0;
            };
            $run = function ($sql) use ($conn) {
                try { $conn->exec($sql); } catch (PDOException $e) { error_log("auto-migrate: " . $e->getMessage()); }
            };

            // 1. Staff intake: APPOINTMENT.ChiefComplaint / Symptoms
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "ChiefComplaint")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN ChiefComplaint TEXT NULL, ADD COLUMN Symptoms TEXT NULL");
                if ($has("CONSULTATION")) {
                    $run("UPDATE APPOINTMENT a JOIN CONSULTATION c ON c.AppointmentID = a.AppointmentID
                          SET a.ChiefComplaint = c.ChiefComplaint, a.Symptoms = c.Symptoms");
                }
            }

            // 2. First come, first served: remember WHEN each request was submitted.
            //    (NULL for old rows - their order is still known from AppointmentID.)
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "CreatedAt")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN CreatedAt DATETIME NULL DEFAULT NULL");
            }

            // 3. Vital signs belong to the appointment (recorded by Staff before the consultation)
            if ($has("VITAL_SIGN") && !$has("VITAL_SIGN", "AppointmentID")) {
                $run("ALTER TABLE VITAL_SIGN ADD COLUMN AppointmentID INT NULL AFTER VitalSignID");
                if ($has("CONSULTATION")) {
                    $run("UPDATE VITAL_SIGN v JOIN CONSULTATION c ON c.ConsultationID = v.ConsultationID
                          SET v.AppointmentID = c.AppointmentID");
                }
                $run("ALTER TABLE VITAL_SIGN MODIFY ConsultationID INT NULL");
                $run("ALTER TABLE VITAL_SIGN ADD CONSTRAINT uq_vital_appointment UNIQUE (AppointmentID)");
                $run("ALTER TABLE VITAL_SIGN ADD CONSTRAINT fk_vital_appointment
                      FOREIGN KEY (AppointmentID) REFERENCES APPOINTMENT(AppointmentID)");
            }

            // 4. Specializations are deactivated (soft delete) instead of permanently deleted
            if ($has("SPECIALIZATION") && !$has("SPECIALIZATION", "Status")) {
                $run("ALTER TABLE SPECIALIZATION ADD COLUMN Status VARCHAR(10) NOT NULL DEFAULT 'Active'");
            }

            // 5. Patient logins: a USERS row with the 'Patient' role is linked to the PATIENT
            //    record it may view (USERS.PatientID). One login per patient (UNIQUE).
            if ($has("USERS") && !$has("USERS", "PatientID")) {
                $run("ALTER TABLE USERS ADD COLUMN PatientID INT NULL DEFAULT NULL");
                if ($has("PATIENT")) {
                    $run("ALTER TABLE USERS ADD CONSTRAINT uq_users_patient UNIQUE (PatientID)");
                    $run("ALTER TABLE USERS ADD CONSTRAINT fk_users_patient
                          FOREIGN KEY (PatientID) REFERENCES PATIENT(PatientID)");
                }
            }
            if ($has("ROLE")) {
                $exists = $conn->query("SELECT COUNT(*) FROM ROLE WHERE RoleName = 'Patient'")->fetchColumn();
                if ($exists == 0) {
                    $run("INSERT INTO ROLE (RoleName, Description, Status)
                          VALUES ('Patient', 'Patients who can view their own medical records', 'Active')");
                }
            }

            // 6. Online payments by patients: one PAYMENT row per successful payment of a bill.
            //    (No card numbers are ever stored - only the method and a reference number.)
            if (!$has("PAYMENT") && $has("BILLING")) {
                $run("CREATE TABLE PAYMENT (
                        PaymentID INT AUTO_INCREMENT PRIMARY KEY,
                        BillID INT NOT NULL,
                        Amount DECIMAL(10,2) NOT NULL,
                        Method VARCHAR(30) NOT NULL,
                        ReferenceNo VARCHAR(40) NOT NULL,
                        Channel VARCHAR(10) NOT NULL DEFAULT 'Online',
                        PaidByUserID INT NULL,
                        PaidAt DATETIME NOT NULL,
                        UNIQUE KEY uq_payment_ref (ReferenceNo),
                        KEY idx_payment_bill (BillID),
                        CONSTRAINT fk_payment_bill FOREIGN KEY (BillID) REFERENCES BILLING(BillID)
                      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                if (!$has("PAYMENT")) {   // the foreign key was refused (older column types): keep going without it
                    $run("CREATE TABLE PAYMENT (
                            PaymentID INT AUTO_INCREMENT PRIMARY KEY, BillID INT NOT NULL, Amount DECIMAL(10,2) NOT NULL,
                            Method VARCHAR(30) NOT NULL, ReferenceNo VARCHAR(40) NOT NULL,
                            Channel VARCHAR(10) NOT NULL DEFAULT 'Online', PaidByUserID INT NULL, PaidAt DATETIME NOT NULL,
                            UNIQUE KEY uq_payment_ref (ReferenceNo), KEY idx_payment_bill (BillID)
                          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                }
            }

            // 7-8. (removed) Laboratory tests carry no price and are never billed; they are only suggested by the doctor.

            // 7b. Each doctor has a set consultation fee. It is copied onto a bill as a professional fee
            //     when the bill is created (the Admin sets it on the Billing page -> Doctor Fees tab).
            if ($has("USERS") && !$has("DOCTOR_FEE")) {
                $run("CREATE TABLE DOCTOR_FEE (
                          UserID    INT NOT NULL PRIMARY KEY,
                          FeeAmount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                          UpdatedAt DATETIME NULL,
                          CONSTRAINT fk_doctor_fee_user FOREIGN KEY (UserID) REFERENCES USERS(UserID)
                      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            // 9. (removed) USERS.ProfessionalFee is no longer used; professional fees live in PROFESSIONAL_FEE.

            // 10. Change requests: when a doctor is unavailable, Staff recommend another doctor with a
            //     similar specialization and/or a new date; the patient accepts or declines.
            if ($has("APPOINTMENT") && !$has("APPOINTMENT_CHANGE_REQUEST")) {
                $run("CREATE TABLE APPOINTMENT_CHANGE_REQUEST (
                          RequestID       INT AUTO_INCREMENT PRIMARY KEY,
                          AppointmentID   INT NOT NULL,
                          Reason          VARCHAR(255) NOT NULL,
                          SuggestedUserID INT NULL,
                          SuggestedDate   DATE NULL,
                          SuggestedTime   TIME NULL,
                          Status          VARCHAR(10) NOT NULL DEFAULT 'Pending',
                          ResponseChoice  VARCHAR(10) NULL,
                          CreatedBy       INT NULL,
                          CreatedAt       DATETIME NOT NULL,
                          RespondedAt     DATETIME NULL,
                          KEY idx_acr_appt (AppointmentID, Status)
                      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            // 11. Appointment time is ONE timestamp (APPOINTMENT.AppointmentAt, DATETIME).
            //     AppointmentDate / AppointmentTime stay as copies of its two halves so older
            //     screens, billing and reports keep working - the API always writes all three.
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "AppointmentAt")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN AppointmentAt DATETIME NULL DEFAULT NULL");
                $run("UPDATE APPOINTMENT SET AppointmentAt = TIMESTAMP(AppointmentDate, AppointmentTime) WHERE AppointmentAt IS NULL");
                $run("ALTER TABLE APPOINTMENT ADD KEY idx_appt_doctor_at (UserID, AppointmentAt)");
            }

            // 12. Each doctor has a limit on how many patients they see per day (default 20).
            if ($has("USERS") && !$has("USERS", "DailyPatientLimit")) {
                $run("ALTER TABLE USERS ADD COLUMN DailyPatientLimit INT NOT NULL DEFAULT 20");
            }

            // 13. Queue Skip / Requeue: RequeuedAt = the moment a patient was sent to the back of the line
            //     (it replaces CreatedAt when working out queue order); SkipCount = how many times they were skipped.
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "RequeuedAt")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN RequeuedAt DATETIME NULL DEFAULT NULL");
            }
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "SkipCount")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN SkipCount INT NOT NULL DEFAULT 0");
            }
        } catch (PDOException $e) {
            error_log("auto-migrate: " . $e->getMessage());
        }
    }
}
