<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";
require_once __DIR__ . "/billing-total.php";

// Billing & professional fees.
// A bill's total = the professional fees on it, calculated by the server (billing-total.php).
//   Admin : manages everything (bills, professional fees, deactivate/restore bills)
//   Staff : handles the bills for patients (create / edit / record payment)
//           and the professional fees (add / remove); cannot deactivate/restore bills
// NOTE: this app has no server-side sessions, so actingUserId comes from the
// client (same approach as users.php). It stops the UI/API being used casually
// by the wrong role, but it is not real authentication.
class Billing {

    private $allowedStatuses = ["Pending", "Paid", "Cancelled"];

    // Role name of an ACTIVE user, or null.
    private function roleOf($conn, $actingUserId) {
        if (empty($actingUserId)) return null;
        $stmt = $conn->prepare("SELECT r.RoleName FROM USERS u
                                JOIN ROLE r ON u.RoleID = r.RoleID
                                WHERE u.UserID = :id AND u.Status = 'Active'");
        $stmt->bindParam(":id", $actingUserId);
        $stmt->execute();
        $role = $stmt->fetchColumn();
        return $role === false ? null : $role;
    }

    private function canManageBills($conn, $actingUserId) {
        return in_array($this->roleOf($conn, $actingUserId), ["Admin", "Staff"], true);
    }

    private function isAdmin($conn, $actingUserId) {
        return $this->roleOf($conn, $actingUserId) === "Admin";
    }

    // Non-negative amount that fits DECIMAL(10,2)
    private function isValidAmount($v, $allowZero = true) {
        if (!is_numeric($v)) return false;
        $n = (float)$v;
        if ($n > 99999999.99) return false;
        return $allowZero ? $n >= 0 : $n > 0;
    }

    private function isValidDate($d) {
        $dt = DateTime::createFromFormat('Y-m-d', (string)$d);
        return $dt && $dt->format('Y-m-d') === $d;
    }

    // The PATIENT record a logged-in Patient account is linked to (null for anyone else).
    private function myPatientId($conn, $actingUserId) {
        if (empty($actingUserId)) return null;
        $st = $conn->prepare("SELECT u.PatientID FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                              WHERE u.UserID = :id AND u.Status = 'Active' AND r.RoleName = 'Patient'
                                AND u.PatientID IS NOT NULL");
        $st->bindValue(":id", $actingUserId);
        $st->execute();
        $pid = $st->fetchColumn();
        return $pid === false ? null : (int)$pid;
    }

    // Patient: MY bills only (bill -> consultation -> appointment -> my patient record),
    // each with its professional-fee lines and, once paid, the payment details.
    function getMyBills($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $pid = $this->myPatientId($conn, $json['actingUserId'] ?? null);
        if (!$pid) return json_encode(["error" => "forbidden"]);

        $st = $conn->prepare("SELECT b.BillID, b.BillDate, b.TotalAmount, b.Status,
                                     c.ConsultationDate, CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                                     (SELECT pay.PaidAt FROM PAYMENT pay WHERE pay.BillID = b.BillID ORDER BY pay.PaymentID DESC LIMIT 1) AS PaidAt,
                                     (SELECT pay.Method FROM PAYMENT pay WHERE pay.BillID = b.BillID ORDER BY pay.PaymentID DESC LIMIT 1) AS PaymentMethod,
                                     (SELECT pay.ReferenceNo FROM PAYMENT pay WHERE pay.BillID = b.BillID ORDER BY pay.PaymentID DESC LIMIT 1) AS ReferenceNo
                              FROM BILLING b
                              JOIN CONSULTATION c ON b.ConsultationID = c.ConsultationID
                              JOIN APPOINTMENT  a ON c.AppointmentID  = a.AppointmentID
                              JOIN USERS        u ON a.UserID         = u.UserID
                              WHERE a.PatientID = :pid
                              ORDER BY b.BillDate DESC, b.BillID DESC");
        $st->bindValue(":pid", $pid);
        $st->execute();
        $bills = $st->fetchAll(PDO::FETCH_ASSOC);

        $fs = $conn->prepare("SELECT pf.FeeAmount, pf.Description, CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                              FROM PROFESSIONAL_FEE pf JOIN USERS u ON pf.UserID = u.UserID
                              WHERE pf.BillID = :bid AND pf.Status = 'Active'");
        foreach ($bills as &$b) {
            $fs->bindValue(":bid", $b['BillID']);
            $fs->execute();
            $b['fees'] = $fs->fetchAll(PDO::FETCH_ASSOC);
        }
        return json_encode($bills);
    }

    // Patient: pay MY bill online.
    // DEMO CHECKOUT: no real payment gateway is called - this records the payment, makes a
    // reference number and marks the bill Paid. To go live, charge the patient through a gateway
    // (PayMongo / GCash / Maya / Stripe...) at the marked spot and only continue when it confirms.
    // Never store card numbers: only Method + ReferenceNo are kept.
    function payMyBill($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $actingUserId = $in['actingUserId'] ?? null;
        $pid = $this->myPatientId($conn, $actingUserId);
        if (!$pid) return json_encode(["error" => "forbidden"]);

        $methods = ["GCash", "Maya", "Credit/Debit Card", "Online Banking"];
        $method = $in['method'] ?? "";
        if (!in_array($method, $methods, true)) return json_encode(["error" => "invalid_method"]);
        if (!preg_match('/^[0-9]+$/', (string)($in['billId'] ?? ''))) return json_encode(["error" => "not_found"]);

        try {
            $conn->beginTransaction();
            // Lock the row so a double-click can't pay the same bill twice.
            $st = $conn->prepare("SELECT b.BillID, b.TotalAmount, b.Status
                                  FROM BILLING b
                                  JOIN CONSULTATION c ON b.ConsultationID = c.ConsultationID
                                  JOIN APPOINTMENT  a ON c.AppointmentID  = a.AppointmentID
                                  WHERE b.BillID = :bid AND a.PatientID = :pid
                                  FOR UPDATE");
            $st->bindValue(":bid", $in['billId']);
            $st->bindValue(":pid", $pid);
            $st->execute();
            $bill = $st->fetch(PDO::FETCH_ASSOC);
            if (!$bill) { $conn->rollBack(); return json_encode(["error" => "not_found"]); }
            if ($bill['Status'] === 'Paid')      { $conn->rollBack(); return json_encode(["error" => "already_paid"]); }
            if ($bill['Status'] !== 'Pending')   { $conn->rollBack(); return json_encode(["error" => "not_payable"]); }
            if ((float)$bill['TotalAmount'] <= 0) { $conn->rollBack(); return json_encode(["error" => "not_payable"]); }

            // >>> A real gateway charge would go here. The amount is always the server's TotalAmount. <<<

            $ref = "ONL-" . date("Ymd") . "-" . $bill['BillID'] . "-" . strtoupper(bin2hex(random_bytes(3)));
            $ins = $conn->prepare("INSERT INTO PAYMENT (BillID, Amount, Method, ReferenceNo, Channel, PaidByUserID, PaidAt)
                                   VALUES (:bid, :amt, :method, :ref, 'Online', :uid, NOW())");
            $ins->bindValue(":bid", $bill['BillID']);
            $ins->bindValue(":amt", $bill['TotalAmount']);
            $ins->bindValue(":method", $method);
            $ins->bindValue(":ref", $ref);
            $ins->bindValue(":uid", $actingUserId);
            $ins->execute();

            $up = $conn->prepare("UPDATE BILLING SET Status = 'Paid' WHERE BillID = :bid AND Status = 'Pending'");
            $up->bindValue(":bid", $bill['BillID']);
            $up->execute();

            $conn->commit();
            return json_encode(["paid" => true, "referenceNo" => $ref, "amount" => $bill['TotalAmount'], "method" => $method]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            return json_encode(["error" => "payment_failed"]);
        }
    }

    // ── Walk-in payment: staff collect payment at the counter (Admin + Staff) ─────
    // Input: { billId, method: Cash | Card | GCash | Maya, reference (needed unless Cash),
    //          amountReceived (Cash only: money handed over, to work out the change) }
    // Saved exactly like an online payment (one PAYMENT row, bill becomes Paid) but with Channel "Walk-in"
    // and the staff member who received it. The amount recorded is always the bill's TotalAmount.
    function recordWalkInPayment($json) {
        include "connection-pdo.php";
        $in = json_decode($json, true) ?: [];
        $actingUserId = $in['actingUserId'] ?? null;
        if (!$this->canManageBills($conn, $actingUserId)) return json_encode(["error" => "forbidden"]);

        $method = $in['method'] ?? "";
        if (!in_array($method, ["Cash", "Card", "GCash", "Maya"], true)) return json_encode(["error" => "invalid_method"]);
        if (!preg_match('/^[0-9]+$/', (string)($in['billId'] ?? ''))) return json_encode(["error" => "not_found"]);

        $ref = isset($in['reference']) ? trim((string)$in['reference']) : "";
        if ($method !== "Cash" && $ref === "") return json_encode(["error" => "reference_required"]);
        if ($ref !== "" && !preg_match('/^[A-Za-z0-9][A-Za-z0-9 _-]{2,39}$/', $ref)) return json_encode(["error" => "invalid_reference"]);

        try {
            $conn->beginTransaction();
            // Lock the bill so it can't be paid twice (e.g. the patient pays online while staff collect cash)
            $st = $conn->prepare("SELECT BillID, TotalAmount, Status FROM BILLING WHERE BillID = :bid FOR UPDATE");
            $st->bindValue(":bid", (int)$in['billId'], PDO::PARAM_INT);
            $st->execute();
            $bill = $st->fetch(PDO::FETCH_ASSOC);
            if (!$bill) { $conn->rollBack(); return json_encode(["error" => "not_found"]); }
            if ($bill['Status'] === 'Paid')    { $conn->rollBack(); return json_encode(["error" => "already_paid"]); }
            if ($bill['Status'] !== 'Pending' || (float)$bill['TotalAmount'] <= 0) { $conn->rollBack(); return json_encode(["error" => "not_payable"]); }

            $totalC  = (int)round(((float)$bill['TotalAmount']) * 100);
            $changeC = 0;
            if ($method === "Cash") {
                $recv = $in['amountReceived'] ?? "";
                if (!is_numeric($recv) || (float)$recv < 0) { $conn->rollBack(); return json_encode(["error" => "invalid_amount"]); }
                $receivedC = (int)round(((float)$recv) * 100);
                if ($receivedC < $totalC) { $conn->rollBack(); return json_encode(["error" => "amount_short"]); }
                $changeC = $receivedC - $totalC;
            }
            if ($ref === "") $ref = "WLK-" . date("Ymd") . "-" . $bill['BillID'] . "-" . strtoupper(bin2hex(random_bytes(3)));

            $ins = $conn->prepare("INSERT INTO PAYMENT (BillID, Amount, Method, ReferenceNo, Channel, PaidByUserID, PaidAt)
                                   VALUES (:bid, :amt, :method, :ref, 'Walk-in', :uid, NOW())");
            $ins->bindValue(":bid", $bill['BillID']);
            $ins->bindValue(":amt", $bill['TotalAmount']);
            $ins->bindValue(":method", $method);
            $ins->bindValue(":ref", $ref);
            $ins->bindValue(":uid", $actingUserId);
            $ins->execute();

            $up = $conn->prepare("UPDATE BILLING SET Status = 'Paid' WHERE BillID = :bid AND Status = 'Pending'");
            $up->bindValue(":bid", $bill['BillID']);
            $up->execute();

            $conn->commit();
            return json_encode([
                "paid" => true, "referenceNo" => $ref, "amount" => $bill['TotalAmount'],
                "method" => $method, "change" => number_format($changeC / 100, 2, '.', ''),
            ]);
        } catch (PDOException $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            if ($e->getCode() === '23000') return json_encode(["error" => "duplicate_reference"]);   // reference number already used
            return json_encode(["error" => "payment_failed"]);
        } catch (Exception $e) {
            if ($conn->inTransaction()) $conn->rollBack();
            return json_encode(["error" => "payment_failed"]);
        }
    }

    // Get ALL bills — overview page (Admin + Staff)
    function getAllBills($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->canManageBills($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

        $sql = "SELECT b.BillID, b.ConsultationID, b.BillDate, b.TotalAmount, b.Status,
                       CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                       a.AppointmentDate,
                       (SELECT COALESCE(SUM(pf.FeeAmount), 0) FROM PROFESSIONAL_FEE pf
                         WHERE pf.BillID = b.BillID AND pf.Status = 'Active') AS FeesTotal,
                       (SELECT COUNT(*) FROM PROFESSIONAL_FEE pf
                         WHERE pf.BillID = b.BillID AND pf.Status = 'Active') AS FeesCount
                FROM BILLING b
                JOIN CONSULTATION c  ON b.ConsultationID  = c.ConsultationID
                JOIN APPOINTMENT  a  ON c.AppointmentID   = a.AppointmentID
                JOIN PATIENT      p  ON a.PatientID       = p.PatientID
                JOIN USERS        u  ON a.UserID          = u.UserID
                ORDER BY b.BillDate DESC";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Active consultations that don't have a bill yet — feeds the "Create Bill" picker
    function getUnbilledConsultations($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->canManageBills($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

        $sql = "SELECT c.ConsultationID, c.ConsultationDate, a.UserID AS DoctorID,
                       CONCAT(p.LastName, ', ', p.FirstName) AS PatientName,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                FROM CONSULTATION c
                JOIN APPOINTMENT a ON c.AppointmentID = a.AppointmentID
                JOIN PATIENT     p ON a.PatientID     = p.PatientID
                JOIN USERS       u ON a.UserID        = u.UserID
                WHERE c.Status = 'Active'
                  AND NOT EXISTS (SELECT 1 FROM BILLING b WHERE b.ConsultationID = c.ConsultationID)
                ORDER BY c.ConsultationDate DESC, p.LastName, p.FirstName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Get billing record for a consultation (with professional fees)
    function getBillingByConsultation($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT b.BillID, b.ConsultationID, b.BillDate, b.TotalAmount, b.Status
                FROM BILLING b
                WHERE b.ConsultationID = :consultationId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":consultationId", $json['consultationId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Get professional fees for a bill
    function getProfessionalFees($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT pf.ProfessionalFeeID, pf.BillID, pf.UserID, pf.FeeAmount, pf.Description, pf.Status,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                FROM PROFESSIONAL_FEE pf
                JOIN USERS u ON pf.UserID = u.UserID
                WHERE pf.BillID = :billId AND pf.Status = 'Active'";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":billId", $json['billId']);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Create a bill for a consultation (Admin or Staff — one bill per consultation)
    function insertBilling($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->canManageBills($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

                list($err, $json) = Validator::run("bill", $json);
        if ($err) return Validator::fail($err);
$consultationId = $json['consultationId'] ?? "";
        $billDate       = $json['billDate'] ?? "";

        if ($consultationId === "" || $billDate === "") return json_encode(["error" => "missing_fields"]);
        if (!$this->isValidDate($billDate))      return json_encode(["error" => "invalid_date"]);

        // The consultation must exist and be Active
        $c = $conn->prepare("SELECT ConsultationID FROM CONSULTATION WHERE ConsultationID = :cid AND Status = 'Active'");
        $c->bindParam(":cid", $consultationId);
        $c->execute();
        if (!$c->fetch()) return json_encode(["error" => "consultation_not_found"]);

        // Guard: one bill per consultation
        $chk = $conn->prepare("SELECT BillID FROM BILLING WHERE ConsultationID = :cid");
        $chk->bindParam(":cid", $consultationId);
        $chk->execute();
        if ($chk->fetch()) {
            return json_encode(["error" => "already_billed"]);
        }

        // Starts at 0; the consultation doctor's set fee (DOCTOR_FEE) is added below, and more
        // professional fees can still be added by hand.
        $sql = "INSERT INTO BILLING (ConsultationID, BillDate, TotalAmount, Status)
                VALUES (:consultationId, :billDate, 0, 'Pending')";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":consultationId", $consultationId);
        $stmt->bindParam(":billDate",       $billDate);
        $stmt->execute();
        if ($stmt->rowCount() < 1) return json_encode(0);
        $billId = $conn->lastInsertId();

        // Billing per doctor: copy the consultation doctor's set fee onto the bill (skipped when it is 0 / not set)
        $df = $conn->prepare("SELECT a.UserID, df.FeeAmount
                              FROM CONSULTATION c
                              JOIN APPOINTMENT a ON a.AppointmentID = c.AppointmentID
                              JOIN DOCTOR_FEE df ON df.UserID = a.UserID
                              WHERE c.ConsultationID = :cid");
        $df->bindParam(":cid", $consultationId);
        $df->execute();
        $rate = $df->fetch(PDO::FETCH_ASSOC);
        if ($rate && (float)$rate['FeeAmount'] > 0) {
            $pf = $conn->prepare("INSERT INTO PROFESSIONAL_FEE (BillID, UserID, FeeAmount, Description, Status)
                                  VALUES (:bid, :uid, :amt, 'Consultation fee', 'Active')");
            $pf->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
            $pf->bindValue(":uid", (int)$rate['UserID'], PDO::PARAM_INT);
            $pf->bindValue(":amt", $rate['FeeAmount']);
            $pf->execute();
        }

        recalcBillTotal($conn, $billId);
        return json_encode(["billId" => $billId]);
    }

    // Update billing date and status (Admin or Staff). The total is calculated, not edited.
    function updateBilling($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->canManageBills($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

                if ($e = Validator::badId($json, ['billId'])) return Validator::fail($e);
        list($err, $json) = Validator::run("bill_update", $json);
        if ($err) return Validator::fail($err);
        if (empty($json['status'])) return Validator::fail("Status is required.");
$billId      = $json['billId'] ?? "";
        $billDate    = $json['billDate'] ?? "";
        $status      = $json['status'] ?? "";

        if ($billId === "" || $billDate === "") return json_encode(["error" => "missing_fields"]);
        if (!$this->isValidDate($billDate))      return json_encode(["error" => "invalid_date"]);
        if (!in_array($status, $this->allowedStatuses, true)) return json_encode(["error" => "invalid_status"]);

        $chk = $conn->prepare("SELECT BillID FROM BILLING WHERE BillID = :billId");
        $chk->bindParam(":billId", $billId);
        $chk->execute();
        if (!$chk->fetch()) return json_encode(["error" => "not_found"]);

        $sql = "UPDATE BILLING SET BillDate = :billDate, Status = :status
                WHERE BillID = :billId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":billDate",    $billDate);
        $stmt->bindParam(":status",      $status);
        $stmt->bindParam(":billId",      $billId);
        $stmt->execute();
        // A bill put back to Pending picks up any fees / lab tests changed while it was locked
        recalcBillTotal($conn, $billId);
        // MySQL reports 0 affected rows when nothing changed, which is still a successful save.
        return json_encode(1);
    }

    // Deactivate a bill (Admin only). Bills are never deleted - "deactivating"
    // sets Status = 'Cancelled', and restoreBilling puts it back to 'Pending'.
    function deactivateBilling($json) {
        return $this->setBillStatus($json, 'Cancelled');
    }

    function restoreBilling($json) {
        return $this->setBillStatus($json, 'Pending');
    }

    private function setBillStatus($json, $status) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->isAdmin($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

        $billId = $json['billId'] ?? "";
        if ($billId === "") return json_encode(["error" => "missing_fields"]);

        $chk = $conn->prepare("SELECT BillID FROM BILLING WHERE BillID = :billId");
        $chk->bindParam(":billId", $billId);
        $chk->execute();
        if (!$chk->fetch()) return json_encode(["error" => "not_found"]);

        $stmt = $conn->prepare("UPDATE BILLING SET Status = :status WHERE BillID = :billId");
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":billId", $billId);
        $stmt->execute();
        recalcBillTotal($conn, $billId);   // only acts when the bill is Pending again
        return json_encode(1);
    }

    // Add a professional fee line to a bill (Admin or Staff)
    function insertProfessionalFee($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->canManageBills($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

                if ($e = Validator::badId($json, ['billId'])) return Validator::fail($e);

        list($err, $json) = Validator::run("fee", $json);
        if ($err) return Validator::fail($err);
$billId    = $json['billId'] ?? "";
        $userId    = $json['userId'] ?? "";
        $feeAmount = $json['feeAmount'] ?? "";

        if ($billId === "" || $userId === "" || $feeAmount === "") return json_encode(["error" => "missing_fields"]);
        if (!$this->isValidAmount($feeAmount, false)) return json_encode(["error" => "invalid_amount"]);

        $chk = $conn->prepare("SELECT Status FROM BILLING WHERE BillID = :billId");
        $chk->bindParam(":billId", $billId);
        $chk->execute();
        $billStatus = $chk->fetchColumn();
        if ($billStatus === false) return json_encode(["error" => "not_found"]);
        // The total is calculated from the fees, so a Paid / Cancelled bill must not have its lines changed
        if ($billStatus !== 'Pending') return json_encode(["error" => "bill_locked"]);

        $sql = "INSERT INTO PROFESSIONAL_FEE (BillID, UserID, FeeAmount, Description, Status)
                VALUES (:billId, :userId, :feeAmount, :description, 'Active')";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":billId",      $billId);
        $stmt->bindParam(":userId",      $userId);
        $stmt->bindParam(":feeAmount",   $feeAmount);
        $stmt->bindValue(":description", $json['description'] ?? null);
        $stmt->execute();
        recalcBillTotal($conn, $billId);
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Remove a professional fee — soft delete (Admin or Staff)
    function removeProfessionalFee($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->canManageBills($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

        $q = $conn->prepare("SELECT pf.BillID, b.Status FROM PROFESSIONAL_FEE pf
                             JOIN BILLING b ON b.BillID = pf.BillID WHERE pf.ProfessionalFeeID = :id");
        $q->bindValue(":id", (int)($json['professionalFeeId'] ?? 0), PDO::PARAM_INT);
        $q->execute();
        $row = $q->fetch(PDO::FETCH_ASSOC);
        if (!$row) return json_encode(["error" => "not_found"]);
        if ($row['Status'] !== 'Pending') return json_encode(["error" => "bill_locked"]);

        $sql = "UPDATE PROFESSIONAL_FEE SET Status = 'Inactive' WHERE ProfessionalFeeID = :id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":id", $json['professionalFeeId']);
        $stmt->execute();
        recalcBillTotal($conn, $row['BillID']);
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // ── Receipt for a PAID bill ─────────────────────────────────────────────
    // Admin / Staff can open the receipt of any paid bill; a Patient only their own.
    // The receipt number comes from the bill number (a bill is always paid in full, so one receipt per bill).
    function getReceipt($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $actingUserId = $json['actingUserId'] ?? null;
        $billId = $json['billId'] ?? "";
        if (!preg_match('/^[0-9]+$/', (string)$billId)) return json_encode(["error" => "not_found"]);

        $isStaff = $this->canManageBills($conn, $actingUserId);
        $pid = $isStaff ? null : $this->myPatientId($conn, $actingUserId);
        if (!$isStaff && !$pid) return json_encode(["error" => "forbidden"]);

        $sql = "SELECT b.BillID, b.BillDate, b.TotalAmount, b.Status, c.ConsultationDate,
                       p.PatientID, CONCAT(p.FirstName, ' ', p.LastName) AS PatientName,
                       CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                FROM BILLING b
                JOIN CONSULTATION c ON b.ConsultationID = c.ConsultationID
                JOIN APPOINTMENT  a ON c.AppointmentID  = a.AppointmentID
                JOIN PATIENT      p ON a.PatientID      = p.PatientID
                JOIN USERS        u ON a.UserID         = u.UserID
                WHERE b.BillID = :bid" . ($isStaff ? "" : " AND a.PatientID = :pid");
        $st = $conn->prepare($sql);
        $st->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        if (!$isStaff) $st->bindValue(":pid", (int)$pid, PDO::PARAM_INT);
        $st->execute();
        $bill = $st->fetch(PDO::FETCH_ASSOC);
        if (!$bill) return json_encode(["error" => "not_found"]);   // also what a patient gets for someone else's bill
        if ($bill['Status'] !== 'Paid') return json_encode(["error" => "not_paid"]);

        $fs = $conn->prepare("SELECT pf.FeeAmount, pf.Description, CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName
                              FROM PROFESSIONAL_FEE pf JOIN USERS u ON pf.UserID = u.UserID
                              WHERE pf.BillID = :bid AND pf.Status = 'Active' ORDER BY pf.ProfessionalFeeID");
        $fs->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $fs->execute();

        // The online payment, if the patient paid through the portal (a bill marked Paid by staff has none)
        $py = $conn->prepare("SELECT pm.Amount, pm.Method, pm.ReferenceNo, pm.Channel, pm.PaidAt,
                                     CASE WHEN pm.Channel = 'Walk-in' THEN CONCAT(u.FirstName, ' ', u.LastName) ELSE NULL END AS ReceivedBy
                              FROM PAYMENT pm LEFT JOIN USERS u ON u.UserID = pm.PaidByUserID
                              WHERE pm.BillID = :bid ORDER BY pm.PaymentID DESC LIMIT 1");
        $py->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $py->execute();
        $payment = $py->fetch(PDO::FETCH_ASSOC);

        return json_encode([
            "receiptNo" => "OR-" . str_pad((string)$bill['BillID'], 6, "0", STR_PAD_LEFT),
            "bill"      => $bill,
            "fees"      => $fs->fetchAll(PDO::FETCH_ASSOC),
            "payment"   => $payment ?: null,
        ]);
    }

    // ── Admin only: manage the AMOUNTS on a bill ────────────────────────────
    // (Staff can still add / remove professional fees above; only Admin can change amounts.) Only a Pending bill can be changed.

    // "bill_locked" / "not_found" checks shared by the Admin operations below
    private function billLockError($status) {
        if ($status === false || $status === null) return "not_found";
        return $status === 'Pending' ? null : "bill_locked";
    }

    // Change the amount (and description) of a professional fee
    function updateProfessionalFee($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->isAdmin($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);

        $id     = (int)($json['professionalFeeId'] ?? 0);
        $amount = $json['feeAmount'] ?? "";
        $desc   = isset($json['description']) ? trim((string)$json['description']) : "";
        if ($id < 1 || $amount === "") return json_encode(["error" => "missing_fields"]);
        if (!$this->isValidAmount($amount, false)) return json_encode(["error" => "invalid_amount"]);
        if (mb_strlen($desc) > 1000) return json_encode(["error" => "invalid_description"]);

        $q = $conn->prepare("SELECT pf.BillID, b.Status FROM PROFESSIONAL_FEE pf
                             JOIN BILLING b ON b.BillID = pf.BillID
                             WHERE pf.ProfessionalFeeID = :id AND pf.Status = 'Active'");
        $q->bindValue(":id", $id, PDO::PARAM_INT);
        $q->execute();
        $row = $q->fetch(PDO::FETCH_ASSOC);
        if ($e = $this->billLockError($row ? $row['Status'] : false)) return json_encode(["error" => $e]);

        $u = $conn->prepare("UPDATE PROFESSIONAL_FEE SET FeeAmount = :a, Description = :d WHERE ProfessionalFeeID = :id");
        $u->bindValue(":a", number_format((float)$amount, 2, '.', ''));
        $u->bindValue(":d", $desc === "" ? null : $desc);
        $u->bindValue(":id", $id, PDO::PARAM_INT);
        $u->execute();
        recalcBillTotal($conn, $row['BillID']);
        return json_encode(1);
    }

    // Get all active doctors for the fee dropdown
    function getActiveDoctors() {
        include "connection-pdo.php";
        $sql = "SELECT u.UserID, CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName,
                       COALESCE(df.FeeAmount, 0) AS FeeAmount
                FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                LEFT JOIN DOCTOR_FEE df ON df.UserID = u.UserID
                WHERE r.RoleName = 'Doctor' AND u.Status = 'Active'
                ORDER BY u.LastName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // ── Doctor earnings for ONE day (Doctor sees only their own) ─────────────────
    // Input: { actingUserId, date: "YYYY-MM-DD" }
    // The day is the consultation date. Counts the doctor's active professional fees on bills that are
    // not Cancelled; Paid and Pending are shown separately. Also reports consultations not billed yet.
    function getDoctorEarnings($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $uid  = $json['actingUserId'] ?? null;
        if ($this->roleOf($conn, $uid) !== "Doctor") return json_encode(["error" => "forbidden"]);

        $date = $json['date'] ?? date('Y-m-d');
        if (!$this->isValidDate($date)) return json_encode(["error" => "invalid_date"]);

        $st = $conn->prepare("SELECT b.BillID, b.Status AS BillStatus, pf.FeeAmount, pf.Description,
                                     c.ConsultationID, c.ConsultationDate,
                                     CONCAT(p.LastName, ', ', p.FirstName) AS PatientName
                              FROM PROFESSIONAL_FEE pf
                              JOIN BILLING      b ON b.BillID         = pf.BillID
                              JOIN CONSULTATION c ON c.ConsultationID = b.ConsultationID
                              JOIN APPOINTMENT  a ON a.AppointmentID  = c.AppointmentID
                              JOIN PATIENT      p ON p.PatientID      = a.PatientID
                              WHERE pf.UserID = :u AND pf.Status = 'Active'
                                AND b.Status <> 'Cancelled' AND c.Status = 'Active'
                                AND c.ConsultationDate = :d
                              ORDER BY c.ConsultationID, pf.ProfessionalFeeID");
        $st->bindValue(":u", $uid);
        $st->bindValue(":d", $date);
        $st->execute();
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);

        $paid = 0.0; $pending = 0.0;
        foreach ($rows as $r) {
            if ($r['BillStatus'] === 'Paid') $paid += (float)$r['FeeAmount']; else $pending += (float)$r['FeeAmount'];
        }

        $ub = $conn->prepare("SELECT COUNT(*) FROM CONSULTATION c
                              JOIN APPOINTMENT a ON a.AppointmentID = c.AppointmentID
                              WHERE a.UserID = :u AND c.Status = 'Active' AND c.ConsultationDate = :d
                                AND NOT EXISTS (SELECT 1 FROM BILLING b WHERE b.ConsultationID = c.ConsultationID AND b.Status <> 'Cancelled')");
        $ub->bindValue(":u", $uid);
        $ub->bindValue(":d", $date);
        $ub->execute();

        return json_encode([
            "date"      => $date,
            "paid"      => round($paid, 2),
            "pending"   => round($pending, 2),
            "total"     => round($paid + $pending, 2),
            "unbilled"  => (int)$ub->fetchColumn(),
            "items"     => $rows,
        ]);
    }

    // ── Doctor Fees (Admin only): the set consultation fee of each doctor ────────
    function getDoctorFees($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->isAdmin($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);
        $stmt = $conn->prepare("SELECT u.UserID, CONCAT(u.LastName, ', ', u.FirstName) AS DoctorName, u.Status,
                                       COALESCE(df.FeeAmount, 0) AS FeeAmount
                                FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                                LEFT JOIN DOCTOR_FEE df ON df.UserID = u.UserID
                                WHERE r.RoleName = 'Doctor'
                                ORDER BY u.Status, u.LastName, u.FirstName");
        $stmt->execute();
        return json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    // Input: { actingUserId, userId, feeAmount }  (0 = no automatic fee). Only affects bills created afterwards.
    function updateDoctorFee($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if (!$this->isAdmin($conn, $json['actingUserId'] ?? null)) return json_encode(["error" => "forbidden"]);
        $userId = $json['userId'] ?? "";
        $amount = $json['feeAmount'] ?? "";
        if (!preg_match('/^[0-9]+$/', (string)$userId) || $amount === "") return json_encode(["error" => "missing_fields"]);
        if (!$this->isValidAmount($amount, true)) return json_encode(["error" => "invalid_amount"]);

        $d = $conn->prepare("SELECT u.UserID FROM USERS u JOIN ROLE r ON u.RoleID = r.RoleID
                             WHERE u.UserID = :id AND r.RoleName = 'Doctor'");
        $d->bindValue(":id", (int)$userId, PDO::PARAM_INT);
        $d->execute();
        if (!$d->fetch()) return json_encode(["error" => "not_found"]);

        $u = $conn->prepare("INSERT INTO DOCTOR_FEE (UserID, FeeAmount, UpdatedAt) VALUES (:id, :amt, NOW())
                             ON DUPLICATE KEY UPDATE FeeAmount = VALUES(FeeAmount), UpdatedAt = NOW()");
        $u->bindValue(":id", (int)$userId, PDO::PARAM_INT);
        $u->bindValue(":amt", number_format((float)$amount, 2, '.', ''));
        $u->execute();
        return json_encode(1);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else {
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$billing = new Billing();
switch ($operation) {
    case "getAllBills":              echo $billing->getAllBills($json);              break;
    case "getUnbilledConsultations": echo $billing->getUnbilledConsultations($json); break;
    case "getBillingByConsultation": echo $billing->getBillingByConsultation($json); break;
    case "getProfessionalFees":      echo $billing->getProfessionalFees($json);      break;
    case "getReceipt":               echo $billing->getReceipt($json);               break;
    case "recordWalkInPayment":      echo $billing->recordWalkInPayment($json);      break;
    case "updateProfessionalFee":    echo $billing->updateProfessionalFee($json);    break;
    case "insertBilling":            echo $billing->insertBilling($json);            break;
    case "updateBilling":            echo $billing->updateBilling($json);            break;
    case "deactivateBilling":        echo $billing->deactivateBilling($json);        break;
    case "restoreBilling":           echo $billing->restoreBilling($json);           break;
    case "insertProfessionalFee":    echo $billing->insertProfessionalFee($json);    break;
    case "removeProfessionalFee":    echo $billing->removeProfessionalFee($json);    break;
    case "getActiveDoctors":         echo $billing->getActiveDoctors();              break;
    case "getDoctorEarnings":        echo $billing->getDoctorEarnings($json);        break;
    case "getDoctorFees":            echo $billing->getDoctorFees($json);            break;
    case "updateDoctorFee":          echo $billing->updateDoctorFee($json);          break;
    case "getMyBills":               echo $billing->getMyBills($json);               break;
    case "payMyBill":                echo $billing->payMyBill($json);                break;
}
?>
