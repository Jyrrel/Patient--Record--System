<?php
// A bill's total is NEVER typed in. It is always:
//
//     total = active professional fees on the bill
//
// Laboratory tests are only suggested by the doctor; they carry no price and never affect a bill.
// recalcBillTotal() is called whenever a fee is added/removed or the bill is created. Only a Pending bill is recalculated: once a bill is
// Paid or Cancelled its amount is frozen.
if (!function_exists('billTotals')) {
    // [fees, total] for a bill, as numbers
    function billTotals($conn, $billId) {
        $f = $conn->prepare("SELECT COALESCE(SUM(FeeAmount), 0) FROM PROFESSIONAL_FEE
                             WHERE BillID = :bid AND Status = 'Active'");
        $f->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $f->execute();
        $fees = round((float)$f->fetchColumn(), 2);

        return [$fees, $fees];
    }
}

if (!function_exists('recalcBillTotal')) {
    function recalcBillTotal($conn, $billId) {
        $s = $conn->prepare("SELECT Status FROM BILLING WHERE BillID = :bid");
        $s->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $s->execute();
        if ($s->fetchColumn() !== 'Pending') return;

        list(, $total) = billTotals($conn, $billId);
        $u = $conn->prepare("UPDATE BILLING SET TotalAmount = :t WHERE BillID = :bid AND Status = 'Pending'");
        $u->bindValue(":t", number_format($total, 2, '.', ''));
        $u->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $u->execute();
    }
}

if (!function_exists('recalcBillForConsultation')) {
    // Used by the laboratory API: find the consultation's bill (if it has one) and refresh it.
    function recalcBillForConsultation($conn, $consultationId) {
        $s = $conn->prepare("SELECT BillID FROM BILLING WHERE ConsultationID = :cid");
        $s->bindValue(":cid", (int)$consultationId, PDO::PARAM_INT);
        $s->execute();
        $billId = $s->fetchColumn();
        if ($billId !== false) recalcBillTotal($conn, $billId);
    }
}
