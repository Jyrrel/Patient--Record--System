-- Appointment change requests (optional: api/auto-migrate.php creates this table automatically).
-- Staff recommend another doctor (similar specialization) and/or a new date when a doctor is
-- unavailable; the patient accepts or declines from "My Appointments".
CREATE TABLE IF NOT EXISTS APPOINTMENT_CHANGE_REQUEST (
    RequestID       INT AUTO_INCREMENT PRIMARY KEY,
    AppointmentID   INT NOT NULL,
    Reason          VARCHAR(255) NOT NULL,
    SuggestedUserID INT NULL,
    SuggestedDate   DATE NULL,
    SuggestedTime   TIME NULL,
    Status          VARCHAR(10) NOT NULL DEFAULT 'Pending',   -- Pending | Accepted | Declined | Withdrawn
    ResponseChoice  VARCHAR(10) NULL,                         -- doctor | date | decline
    CreatedBy       INT NULL,
    CreatedAt       DATETIME NOT NULL,
    RespondedAt     DATETIME NULL,
    KEY idx_acr_appt (AppointmentID, Status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
