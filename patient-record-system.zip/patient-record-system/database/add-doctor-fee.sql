-- Each doctor has a set consultation fee. When a bill is created, the consultation doctor's fee
-- is added to it automatically as a professional fee (0 = nothing added; staff can still use Add Fee).
-- api/auto-migrate.php creates this table by itself; this file is the manual equivalent.
CREATE TABLE IF NOT EXISTS DOCTOR_FEE (
    UserID    INT NOT NULL PRIMARY KEY,
    FeeAmount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    UpdatedAt DATETIME NULL,
    CONSTRAINT fk_doctor_fee_user FOREIGN KEY (UserID) REFERENCES USERS(UserID)
);
-- Example: UPDATE/INSERT your doctors' fees, or set them on Billing -> Doctor Fees (Admin).
-- INSERT INTO DOCTOR_FEE (UserID, FeeAmount, UpdatedAt) VALUES (2, 500.00, NOW());
