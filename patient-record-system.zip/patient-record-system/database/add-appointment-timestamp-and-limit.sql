-- Appointment timestamp + per-doctor daily patient limit.
-- Optional: api/auto-migrate.php applies the same changes automatically the first time the API runs.
-- Safe to run once on an existing database (back up first).

-- 1. One timestamp for the appointment. AppointmentDate / AppointmentTime remain as copies of its
--    two halves (the API writes all three) so billing, consultations and reports are unchanged.
ALTER TABLE APPOINTMENT ADD COLUMN AppointmentAt DATETIME NULL DEFAULT NULL;
UPDATE APPOINTMENT SET AppointmentAt = TIMESTAMP(AppointmentDate, AppointmentTime) WHERE AppointmentAt IS NULL;
ALTER TABLE APPOINTMENT ADD KEY idx_appt_doctor_at (UserID, AppointmentAt);

-- 2. How many patients each doctor accepts per day (Scheduled + Completed appointments count).
--    Change it per doctor from Doctors > Edit, or here:
ALTER TABLE USERS ADD COLUMN DailyPatientLimit INT NOT NULL DEFAULT 20;
-- Example: UPDATE USERS SET DailyPatientLimit = 12 WHERE Username = 'jramirez';
