-- Remove laboratory fees from billing.
-- Laboratory tests are only SUGGESTED by the doctor (request form / results); they are never priced or billed.
-- Optional: the application no longer reads or writes these, so skipping this file is harmless.
-- Back up first: the dropped columns/table hold old prices and lab fees.
--
-- 1. Bills that included lab fees keep the TotalAmount already saved on them.
--    Pending bills are recalculated (professional fees only) the next time a fee is added or removed.
-- 2. Run once. Skip any line that errors with "Unknown column" / "Unknown table" (already removed).

DROP TABLE IF EXISTS BILL_LAB_CHARGE;
ALTER TABLE LABORATORY      DROP COLUMN Price;
ALTER TABLE LABORATORY_TEST DROP COLUMN Price;

-- Optional: re-total the Pending bills from their professional fees only.
UPDATE BILLING b
SET b.TotalAmount = COALESCE((SELECT SUM(pf.FeeAmount) FROM PROFESSIONAL_FEE pf
                              WHERE pf.BillID = b.BillID AND pf.Status = 'Active'), 0)
WHERE b.Status = 'Pending';
