-- ============================================================
-- Remove USERS.ProfessionalFee
-- Professional fees now live only in the PROFESSIONAL_FEE table (one row per fee on a bill).
-- Run this ONCE in phpMyAdmin (it errors if the column is already gone).
-- ============================================================
ALTER TABLE users DROP COLUMN ProfessionalFee;
