-- Queue Skip / Requeue.
-- Optional: api/auto-migrate.php applies the same changes automatically the first time the API runs.
-- Safe to run once on an existing database (back up first).

-- RequeuedAt: when a patient was sent to the back of the line (Skip, or Requeue of a No-Show).
--             Queue order = COALESCE(RequeuedAt, CreatedAt), so NULL means "never moved".
-- SkipCount : how many times the patient was skipped that day.
ALTER TABLE APPOINTMENT ADD COLUMN RequeuedAt DATETIME NULL DEFAULT NULL;
ALTER TABLE APPOINTMENT ADD COLUMN SkipCount INT NOT NULL DEFAULT 0;
